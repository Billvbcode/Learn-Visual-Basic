﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCreate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCreate))
        Me.LblName = New System.Windows.Forms.Label()
        Me.BtnView = New System.Windows.Forms.Button()
        Me.BtnCreate = New System.Windows.Forms.Button()
        Me.BtnAttach = New System.Windows.Forms.Button()
        Me.LblCode = New System.Windows.Forms.Label()
        Me.RText = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cLblMouseMove = New System.Windows.Forms.Label()
        Me.cLblClick = New System.Windows.Forms.Label()
        Me.aLblClick = New System.Windows.Forms.Label()
        Me.aLblMouseMove = New System.Windows.Forms.Label()
        Me.BtnPicture = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LblName
        '
        Me.LblName.AutoSize = True
        Me.LblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblName.Location = New System.Drawing.Point(54, 36)
        Me.LblName.Name = "LblName"
        Me.LblName.Size = New System.Drawing.Size(0, 20)
        Me.LblName.TabIndex = 60
        '
        'BtnView
        '
        Me.BtnView.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnView.Location = New System.Drawing.Point(393, 3)
        Me.BtnView.Name = "BtnView"
        Me.BtnView.Size = New System.Drawing.Size(216, 34)
        Me.BtnView.TabIndex = 59
        Me.BtnView.Text = "ViewCrealedLabels"
        Me.BtnView.UseVisualStyleBackColor = True
        '
        'BtnCreate
        '
        Me.BtnCreate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCreate.Location = New System.Drawing.Point(230, 3)
        Me.BtnCreate.Name = "BtnCreate"
        Me.BtnCreate.Size = New System.Drawing.Size(135, 34)
        Me.BtnCreate.TabIndex = 58
        Me.BtnCreate.Text = "CreateLabels"
        Me.BtnCreate.UseVisualStyleBackColor = True
        '
        'BtnAttach
        '
        Me.BtnAttach.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAttach.Location = New System.Drawing.Point(102, 3)
        Me.BtnAttach.Name = "BtnAttach"
        Me.BtnAttach.Size = New System.Drawing.Size(122, 34)
        Me.BtnAttach.TabIndex = 57
        Me.BtnAttach.Text = "Attach"
        Me.BtnAttach.UseVisualStyleBackColor = True
        '
        'LblCode
        '
        Me.LblCode.AutoSize = True
        Me.LblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCode.Location = New System.Drawing.Point(8, 17)
        Me.LblCode.Name = "LblCode"
        Me.LblCode.Size = New System.Drawing.Size(56, 20)
        Me.LblCode.TabIndex = 56
        Me.LblCode.Text = " Code"
        '
        'RText
        '
        Me.RText.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RText.Location = New System.Drawing.Point(12, 59)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(597, 520)
        Me.RText.TabIndex = 55
        Me.RText.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(713, 76)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 16)
        Me.Label1.TabIndex = 61
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(713, 116)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 16)
        Me.Label2.TabIndex = 62
        Me.Label2.Text = "Label2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(713, 154)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 16)
        Me.Label3.TabIndex = 63
        Me.Label3.Text = "Label3"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(713, 195)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 16)
        Me.Label4.TabIndex = 64
        Me.Label4.Text = "Label4"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(713, 235)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 16)
        Me.Label5.TabIndex = 65
        Me.Label5.Text = "Label5"
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("Courier New", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(841, 76)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(91, 324)
        Me.ListBox1.TabIndex = 89
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel1.Controls.Add(Me.cLblMouseMove)
        Me.Panel1.Controls.Add(Me.cLblClick)
        Me.Panel1.Location = New System.Drawing.Point(615, 73)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(220, 455)
        Me.Panel1.TabIndex = 90
        '
        'cLblMouseMove
        '
        Me.cLblMouseMove.AutoSize = True
        Me.cLblMouseMove.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cLblMouseMove.Location = New System.Drawing.Point(0, 247)
        Me.cLblMouseMove.Name = "cLblMouseMove"
        Me.cLblMouseMove.Size = New System.Drawing.Size(75, 13)
        Me.cLblMouseMove.TabIndex = 1
        Me.cLblMouseMove.Text = "MouseMove"
        '
        'cLblClick
        '
        Me.cLblClick.AutoSize = True
        Me.cLblClick.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cLblClick.Location = New System.Drawing.Point(3, 214)
        Me.cLblClick.Name = "cLblClick"
        Me.cLblClick.Size = New System.Drawing.Size(35, 13)
        Me.cLblClick.TabIndex = 0
        Me.cLblClick.Text = "Click"
        '
        'aLblClick
        '
        Me.aLblClick.AutoSize = True
        Me.aLblClick.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.aLblClick.Location = New System.Drawing.Point(615, 286)
        Me.aLblClick.Name = "aLblClick"
        Me.aLblClick.Size = New System.Drawing.Size(35, 13)
        Me.aLblClick.TabIndex = 2
        Me.aLblClick.Text = "Click"
        '
        'aLblMouseMove
        '
        Me.aLblMouseMove.AutoSize = True
        Me.aLblMouseMove.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.aLblMouseMove.Location = New System.Drawing.Point(615, 317)
        Me.aLblMouseMove.Name = "aLblMouseMove"
        Me.aLblMouseMove.Size = New System.Drawing.Size(75, 13)
        Me.aLblMouseMove.TabIndex = 2
        Me.aLblMouseMove.Text = "MouseMove"
        '
        'BtnPicture
        '
        Me.BtnPicture.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPicture.Location = New System.Drawing.Point(633, 3)
        Me.BtnPicture.Name = "BtnPicture"
        Me.BtnPicture.Size = New System.Drawing.Size(135, 34)
        Me.BtnPicture.TabIndex = 91
        Me.BtnPicture.Text = "CreatePictures"
        Me.BtnPicture.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(817, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(62, 64)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 92
        Me.PictureBox1.TabStop = False
        '
        'FrmCreate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(944, 605)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.BtnPicture)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.LblName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.BtnView)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnCreate)
        Me.Controls.Add(Me.BtnAttach)
        Me.Controls.Add(Me.LblCode)
        Me.Controls.Add(Me.RText)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.aLblClick)
        Me.Controls.Add(Me.aLblMouseMove)
        Me.Name = "FrmCreate"
        Me.Text = "FrmCreate"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LblName As Label
    Friend WithEvents BtnView As Button
    Friend WithEvents BtnCreate As Button
    Friend WithEvents BtnAttach As Button
    Friend WithEvents LblCode As Label
    Friend WithEvents RText As RichTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents cLblMouseMove As Label
    Friend WithEvents cLblClick As Label
    Friend WithEvents aLblClick As Label
    Friend WithEvents aLblMouseMove As Label
    Friend WithEvents BtnPicture As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class

﻿Public Class FrmListBox
    Dim iSelect As Integer
    Dim sFileName As String
    Dim sMsg As String
    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click
        ListBox1.Items.Clear()
        TxtSelect.Text = ""
        BtnDelete.Enabled = False
        sMsg = "'Clear"
        RText.Text = sMsg & vbCrLf & " ListBox1.Items.Clear()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        sMsg = "'Add"
        ListBox1.Items.Clear()
        ListBox1.Items.Add("Egg")
        ListBox1.Items.Add("Cake")
        ListBox1.Items.Add("Apple")
        ListBox1.Items.Add("Fish")
        ListBox1.Sorted = False
        ListAddCnt.Text = ListBox1.Items.Count
        TxtSelect.Text = ""
        BtnDelete.Enabled = False
        sFileName = "Listadd.txt"
        rFile()
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnSort_Click(sender As Object, e As EventArgs) Handles BtnSort.Click
        sMsg = "'Sort"
        ListBox1.Items.Clear()
        ListBox1.Items.Add("Egg")
        ListBox1.Items.Add("Cake")
        ListBox1.Items.Add("Apple")
        ListBox1.Items.Add("Fish")
        ListBox1.Items.Add("Bear")
        ListBox1.Sorted = True
        ListSortCnt.Text = ListBox1.Items.Count
        TxtSelect.Text = ""
        BtnDelete.Enabled = False
        sFileName = "Listsort.txt"
        rFile()
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub

    Private Sub FrmListBox_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BtnLoop_Click(sender As Object, e As EventArgs) Handles BtnLoop.Click
        ListBox1.Items.Clear()
        ListBox1.Items.Add("Egg")
        ListBox1.Items.Add("Cake")
        ListBox1.Items.Add("Apple")
        ListBox1.Items.Add("Fish")
        ListBox1.Items.Add("Bear")
        Dim MyLabel(6) As Label
        Dim i As Integer
        MyLabel(0) = Label1
        MyLabel(1) = Label2
        MyLabel(2) = Label3
        MyLabel(3) = Label4
        MyLabel(4) = Label5
        For i = 0 To ListBox1.Items.Count - 1
            MyLabel(i).Text = ListBox1.Items(i).ToString
        Next
        TxtSelect.Text = ""
        BtnDelete.Enabled = False
        sMsg = "'Loop"
        sFileName = "ListLoop.txt"
        rFile()
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub ListBox1_Click(sender As Object, e As EventArgs) Handles ListBox1.Click
        sMsg = "'Click"
        TxtSelect.Text = ListBox1.Text
        BtnDelete.Enabled = True
        sFileName = "Listclick.txt"
        rFile()
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click
        sMsg = "'Delete"
        If TxtSelect.Text = "" Then Exit Sub
        ListBox1.Items.Remove(TxtSelect.Text)
        TxtSelect.Text = ""
        BtnDelete.Enabled = False
        sFileName = "Listdelete.txt"
        rFile()
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
End Class
﻿Public Class FrmColor
    Dim iCount As Integer ' Counter
    Dim sMsg As String
    Dim sMsg2 As String
    Dim sFileName As String
    Private Sub HSRed_Scroll(sender As Object, e As ScrollEventArgs) Handles HSRed.Scroll
        LblColor.BackColor = Color.FromArgb(HSRed.Value, HSGreen.Value, HSBlue.Value)
        LblRed.Text = HSRed.Value ' Red Scroll Value

        sMsg = "'Color.FromArgb(HSRed.Value, HSGreen.Value, HSBlue.Value)"
        RText.Text = "'Color.FromArgb(HSRed.Value, HSGreen.Value, HSBlue.Value)"
        sMsg2 = "LblColor.BackColor = Color.FromArgb(" & HSRed.Value & "," & HSGreen.Value & "," & HSBlue.Value & ")"
        RText.Text = RText.Text & vbCrLf & sMsg2
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub HSGreen_Scroll(sender As Object, e As ScrollEventArgs) Handles HSGreen.Scroll
        LblColor.BackColor = Color.FromArgb(HSRed.Value, HSGreen.Value, HSBlue.Value)
        LblGreen.Text = HSGreen.Value ' Green Scroll Value
        sMsg = "'Color.FromArgb(HSRed.Value, HSGreen.Value, HSBlue.Value)"
        RText.Text = "'Color.FromArgb(HSRed.Value, HSGreen.Value, HSBlue.Value)"
        sMsg2 = "LblColor.BackColor = Color.FromArgb(" & HSRed.Value & "," & HSGreen.Value & "," & HSBlue.Value & ")"
        RText.Text = RText.Text & vbCrLf & sMsg2
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub HSBlue_Scroll(sender As Object, e As ScrollEventArgs) Handles HSBlue.Scroll
        sMsg = "'Color.FromArgb(HSRed.Value, HSGreen.Value, HSBlue.Value)"
        RText.Text = "'Color.FromArgb(HSRed.Value, HSGreen.Value, HSBlue.Value)"
        sMsg2 = "LblColor.BackColor = Color.FromArgb(" & HSRed.Value & "," & HSGreen.Value & "," & HSBlue.Value & ")"
        RText.Text = RText.Text & vbCrLf & sMsg2
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        LblColor.BackColor = Color.FromArgb(HSRed.Value, HSGreen.Value, HSBlue.Value)
        LblBlue.Text = HSBlue.Value ' Blue Scroll Value
    End Sub

    Private Sub BtnSignL_Click(sender As Object, e As EventArgs) Handles BtnSignL.Click
        sMsg = "'Marquee     Move Text Left = All but First & First"
        RText.Text = "LblMarquee.Text = Mid(LblMarquee.Text, 2, Len(LblMarquee.Text) - 1) " & vbCrLf
        RText.Text = RText.Text & "LblMarquee.Text = LblMarquee.Text & Mid(LblMarquee.Text, 1, 1) " & vbCrLf
        RText.Text = RText.Text & "iCount += 1 " & vbCrLf & "If iCount = 1 Then LblMarquee.BackColor = Color.HotPink" & vbCrLf
        RText.Text = RText.Text & "If iCount = 20 Then LblMarquee.BackColor = Color.LawnGreen" & vbCrLf
        RText.Text = RText.Text & "If iCount = 40 Then LblMarquee.BackColor = Color.LightBlue" & vbCrLf
        RText.Text = RText.Text & "If iCount = 60 Then iCount = 0"
        RText.Text = sMsg & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub TimSign_Tick(sender As Object, e As EventArgs) Handles TimSign.Tick
        ' Move Text Left = All but first & First
        LblMarquee.Text = Mid(LblMarquee.Text, 2, Len(LblMarquee.Text) - 1) _
        & Mid(LblMarquee.Text, 1, 1)
        iCount += 1   ' Add one to counter
        ' Check counter to change Marquee color
        If iCount = 1 Then LblMarquee.BackColor = Color.HotPink
        If iCount = 20 Then LblMarquee.BackColor = Color.LawnGreen
        If iCount = 40 Then LblMarquee.BackColor = Color.LightBlue
        ' Reset counter when it reaches 60
        If iCount = 60 Then iCount = 0
    End Sub

    Private Sub FrmColor_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TimSign.Start() ' Start Timer
        sMsg = "'Color.FromArgb(HSRed.Value, HSGreen.Value, HSBlue.Value)"
        RText.Text = "'Color.FromArgb(HSRed.Value, HSGreen.Value, HSBlue.Value)"
        sMsg2 = "LblColor.BackColor = Color.FromArgb(" & HSRed.Value & "," & HSGreen.Value & "," & HSBlue.Value & ")"
        RText.Text = RText.Text & sMsg2
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        LblColor.BackColor = Color.FromArgb(HSRed.Value, HSGreen.Value, HSBlue.Value)
        Label1.BackColor = Color.Tomato
    End Sub

    Private Sub LblColor_Click(sender As Object, e As EventArgs) Handles LblColor.Click

    End Sub

    Private Sub BtnSignR_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label1_MouseEnter(sender As Object, e As EventArgs) Handles Label1.MouseEnter
        Label1.BackColor = Color.LightGreen
        sMsg = "'MouseEnter"
        sFileName = "MouseEnter.txt"
        rFile()
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub Label1_MouseLeave(sender As Object, e As EventArgs) Handles Label1.MouseLeave
        Label1.BackColor = Color.Tomato
        sMsg = "'MouseLeave"
        sFileName = "MouseLeave.txt"
        rFile()
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
End Class
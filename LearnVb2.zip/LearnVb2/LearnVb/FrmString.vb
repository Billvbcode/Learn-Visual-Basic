﻿Public Class FrmString
    Dim sMsg As String
    Private Sub FrmString_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim value As String = My.Application.Info.DirectoryPath & "\ascii2.jpg"
        PictureBox1.Image = Image.FromFile(value)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage

        ListBox1.Items.Clear()
        ListBox1.Items.Add(Chr(34) & Chr(34) & "           Erase the text   ")
        ListBox1.Items.Add("_             Underscore (Shift Minus) Extend Code to next line   ")
        ListBox1.Items.Add("&             Put Two Strings Together  ")
        ListBox1.Items.Add("Copy          Copy the string  ")
        ListBox1.Items.Add("Length        Len(String)  ")
        ListBox1.Items.Add("Space         Space(Number)	")
        ListBox1.Items.Add("Replace       Replace(String, search, replace)  ")
        ListBox1.Items.Add("Replace2      Replace(String, search, replace)  ")
        ListBox1.Items.Add("Trim          Trim(String)	")
        ListBox1.Items.Add("InStr         InStr(Start, String, Look For) ")
        ListBox1.Items.Add("InStr2        InStr(Start, String, Look For) ")
        ListBox1.Items.Add("Mid           Mid(String, Start, Length)    ")
        ListBox1.Items.Add("Mid6          Mid(String, 6, 10)    ")
        ListBox1.Items.Add("Mid16         Mid(String, 16, 12)    ")
        ListBox1.Items.Add("UCase         UCase(String) Upper Case")
        ListBox1.Items.Add("LCase         LCase(String) Lower Case")
        ListBox1.Items.Add("MidReplace    Just Replace ")
        ListBox1.Items.Add("First         Mid(String, 1, 1)")
        ListBox1.Items.Add("AllButFirst   Mid(String, 2, Len(string)-1) ")
        ListBox1.Items.Add("Last          Mid(String, Len(string), 1)  ")
        ListBox1.Items.Add("AllButLast    Mid(String, 1, Len(string)-1)  ")
        ListBox1.Items.Add("vbCrLf        Add a Carriage return and Linefeed  ")
        ListBox1.Items.Add("NOTE          Chr(#) Uses ASCII table to Convert # to a character ")
        ListBox1.Items.Add("Chr(34)       Double Quotes  ")
        ListBox1.Items.Add("Chr(48)       Zero ")
        ListBox1.Items.Add("Chr(65)       A ")
        ListBox1.Items.Add("Asc(" & Chr(34) & "A" & Chr(34) & ")" & "     Numeric Value of one character  A=65")
        ListBox1.Items.Add("Asc(" & Chr(34) & "0" & Chr(34) & ")" & "     Numeric Value of one character  0=48")
        ListBox1.Items.Add("ASCII Table   Each symbol is represented by a Decimal Number")
        LblLen.Text = Len(LblTest.Text)
        LblResult.Text = ""
        LblLenR.Text = Len(LblResult.Text)
    End Sub

    Private Sub ListBox1_Click(sender As Object, e As EventArgs) Handles ListBox1.Click
        Dim i As Integer
        LblLenR.Visible = True
        PictureBox1.Visible = False
        If Mid(ListBox1.Text, 1, 5) = "ASCII" Then
            PictureBox1.Visible = True
        End If
        If Mid(ListBox1.Text, 1, 1) = Chr(34) Then
            LblResult.Text = ""
            'Length
            sMsg = Chr(34) & Chr(34) & "           Erase the text   "
            RText.Text = "LblResult.Text = " & Chr(34) & Chr(34)
            i = Len(RText.Text)
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            LblLenR.Text = Len(LblResult.Text)
            Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 1) = "_" Then
            LblResult.Text = LblTest.Text _
                & "1234"
            'Length
            sMsg = "'_ Underscore (Shift Minus)  " & vbCrLf & "'Extend Code to the next line"
            RText.Text = "LblResult.Text = LblTest.Text _" & vbCrLf & "   " & Chr(34) & "1234" & Chr(34)
            i = Len(RText.Text)
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            ' Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 1) = "&" Then
            LblResult.Text = LblTest.Text & "1234"
            'Length
            sMsg = "'&  Put Two Strings Together "
            RText.Text = " LblResult.Text = LblTest.Text & " & Chr(34) & "1234" & Chr(34)
            i = Len(RText.Text)
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 4) = "Copy" Then
            LblResult.Text = LblTest.Text
            'Length
            sMsg = "'Copy the text srting "
            RText.Text = " LblResult.Text = LblTest.Text"
            i = Len(RText.Text)
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 6) = "vbCrLf" Then
            LblResult.Text = "Line1" & vbCrLf & LblTest.Text
            'Length
            sMsg = "'Add a Carriage return and Linefeed "
            RText.Text = "LblResult.Text = " & Chr(34) & "Line1" & Chr(34) & " & vbCrLf & LblTest.Text"
            i = Len(RText.Text)
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 3) = "Asc" And Mid(ListBox1.Text, 6, 1) = "0" Then
            LblResult.Text = Asc("0")
            'Length
            sMsg = "'Asc() Uses ASCII table to Convert a character into a number  " & vbCrLf
            sMsg = sMsg & "'Numeric Value of one character (The number zero = 48)"
            RText.Text = " LblResult.Text = Asc(" & Chr(34) & "0" & Chr(34) & ") "
            i = Len(RText.Text)
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 3) = "Asc" And Mid(ListBox1.Text, 6, 1) = "A" Then
            LblResult.Text = Asc("A")
            'Length
            sMsg = "'Asc() Uses ASCII table to Convert a character into a number  " & vbCrLf
            sMsg = sMsg & "'Numeric Value of one character (The letter A = 65)"
            RText.Text = " LblResult.Text = Asc(" & Chr(34) & "A" & Chr(34) & ") "
            i = Len(RText.Text)
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 6) = "Chr(48" Then
            LblResult.Text = Chr(48)
            sMsg = "'Chr(#) Uses ASCII table to Convert number into a character " & vbCrLf
            sMsg = sMsg & "'48 = Zero"
            RText.Text = " LblResult.Text = Chr(48) "
            i = Len(RText.Text)
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 6) = "Chr(65" Then
            LblResult.Text = Chr(65)
            'Length
            sMsg = "'Chr(#) Uses ASCII table to Convert number into a character " & vbCrLf
            sMsg = sMsg & "'65 = A"
            RText.Text = " LblResult.Text = Chr(65) "
            i = Len(RText.Text)
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 6) = "Chr(34" Then
            LblResult.Text = Chr(34)
            sMsg = "'Chr(#) Uses ASCII table to Convert number into a character " & vbCrLf
            sMsg = sMsg & "'34 = Double Quotes"
            RText.Text = " LblResult.Text = Chr(34) "
            i = Len(RText.Text)
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 7) = "AllButF" Then
            LblResult.Text = Mid(LblTest.Text, 2, Len(LblTest.Text) - 1)
            'Length
            sMsg = "'AllButFirst"
            RText.Text = "LblResult.Text = Mid(LblTest.Text, 2, Len(LblTest.Text) - 1)  "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 7) = "AllButL" Then
            LblResult.Text = Mid(LblTest.Text, 1, Len(LblTest.Text) - 1)
            'Length
            sMsg = "'AllButLast "
            RText.Text = "LblResult.Text = Mid(LblTest.Text, 1, Len(LblTest.Text) - 1)  "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 5) = "First" Then
            LblResult.Text = Mid(LblTest.Text, 1, 1)
            'Length
            sMsg = "'First Character"
            RText.Text = "LblResult.Text = Mid(LblTest.Text, 1, 1)  "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 4) = "Last" Then
            LblResult.Text = Mid(LblTest.Text, Len(LblTest.Text), 1)
            'Length
            sMsg = "'Last Character"
            RText.Text = "LblResult.Text = Mid(LblTest.Text, Len(LblTest.Text), 1)  "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 3) = "Len" Then
            LblResult.Text = Len(LblTest.Text)
            'Length
            sMsg = "'Length"
            RText.Text = "LblResult.Text = Len(LblTest.Text)  "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
            LblLenR.Visible = False
        End If
        If Mid(ListBox1.Text, 1, 5) = "UCase" Then
            LblResult.Text = UCase(LblTest.Text)
            'Upper Case
            sMsg = "'Upper Case"
            RText.Text = "LblResult.Text = UCase(LblTest.Text)  "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 5) = "LCase" Then
            LblResult.Text = LCase(LblTest.Text)
            'Lower Case
            sMsg = "'Lower Case"
            RText.Text = "LblResult.Text = LCase(LblTest.Text)  "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 8) = "Replace " Then
            LblResult.Text = Replace(LblTest.Text, "very", "")
            'Replace Very with blank
            sMsg = "'Find Very and replace with blank"
            RText.Text = "LblResult.Text = Replace(LblTest.Text, " & Chr(34) & "very" & Chr(34) & "," & Chr(34) & Chr(34) & ")  "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 8) = "Replace2" Then
            LblResult.Text = Replace(LblTest.Text, "string", "sentance")
            sMsg = "'Find string and replace with sentance"
            RText.Text = "LblResult.Text = Replace(LblTest.Text, " & Chr(34) & "string" & Chr(34) & "," & Chr(34) & "sentance" & Chr(34) & ")  "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 6) = "InStr " Then
            LblResult.Text = InStr(1, LblTest.Text, "string")
            LblLenR.Visible = False
            sMsg = "'Find location of the word string"
            RText.Text = "LblResult.Text = InStr(1, LblTest.Text, " & Chr(34) & "string" & Chr(34) & ")  "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 6) = "InStr2" Then
            LblResult.Text = InStr(1, LblTest.Text, "long")
            LblLenR.Visible = False
            sMsg = "'Find location of the word long"
            RText.Text = "LblResult.Text = InStr(1, LblTest.Text, " & Chr(34) & "long" & Chr(34) & ")  "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 4) = "Trim" Then
            LblResult.Text = Trim(LblTest.Text)
            'Trim Spaces
            sMsg = "'Trim Spaces"
            RText.Text = "LblResult.Text = Trim(LblTest.Text) "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 5) = "Space" Then
            LblResult.Text = LblTest.Text & Space(5)
            'Add 5 Spaces
            sMsg = "'Add 5 Spaces"
            RText.Text = "LblResult.Text = LblTest.Text & Space(5) "
            i = Len(RText.Text)
            RText.Text = RText.Text & sMsg
            RText.Select(i, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 4) = "Mid " Then
            LblResult.Text = Mid(LblTest.Text, 1, 7)
            'Mid
            sMsg = "'Mid(String, Start, Length)" & vbCrLf & "'LblResult.Text = Mid(LblTest.Text, 1, 7)"
            RText.Text = "LblResult.Text = Trim(LblTest.Text) "
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 5) = "Mid16" Then
            LblResult.Text = Mid(LblTest.Text, 16, 12)
            'Mid
            sMsg = "'Mid(String, Start, Length)" & vbCrLf & "'LblResult.Text = Mid(LblTest.Text, 16, 12)"
            RText.Text = "LblResult.Text = Trim(LblTest.Text) "
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 4) = "Mid6" Then
            LblResult.Text = Mid(LblTest.Text, 6, 10)
            'Mid
            sMsg = "'Mid(String, Start, Length)" & vbCrLf & "'LblResult.Text = Mid(LblTest.Text, 6, 10)"
            RText.Text = "LblResult.Text = Trim(LblTest.Text) "
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 4) = "MidR" Then
            LblResult.Text = LblTest.Text
            mid(LblResult.Text, 1, 5) = "1234"
            'MidReplace
            sMsg = "'Mid(String, Start, Length)" & vbCrLf & "'Just Replace"
            RText.Text = "LblResult.Text = LblTest.Text" & vbCrLf '&
            RText.Text = RText.Text & "mid(LblTest.Text,1,5) = " & Chr(34) & "1234" & Chr(34)
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        LblLenR.Text = Len(LblResult.Text)
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub RText_TextChanged(sender As Object, e As EventArgs) Handles RText.TextChanged

    End Sub
End Class
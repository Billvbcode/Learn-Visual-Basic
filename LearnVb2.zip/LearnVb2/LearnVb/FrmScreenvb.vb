﻿Public Class FrmScreenvb
    Dim sFolder As String ' Folder Name
    Dim sMsg As String
    Dim sFileName As String
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub GetFiles()
        Dim value As String = My.Application.Info.DirectoryPath & "\" & sFolder & "\"
        Dim di As IO.DirectoryInfo = New IO.DirectoryInfo(value)
        '
        ' Read all Jpgs
        '
        ListBox1.Items.Clear()  'Clear ListBox
        Dim diar1 As IO.FileInfo() = di.GetFiles("*.jpg")
        Dim dra As IO.FileInfo
        'list the names of all files in the specified directory
        For Each dra In diar1
            ListBox1.Items.Add(dra)
        Next
    End Sub
    Private Sub FrmScreenvb_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        sFolder = "Screen" 'Folder Name
        GetFiles()
    End Sub

    Private Sub ListBox1_Click(sender As Object, e As EventArgs) Handles ListBox1.Click
        'Load Picture from file
        Dim value As String = My.Application.Info.DirectoryPath & "\" & sFolder & "\"
        PictureBox1.Image = Image.FromFile(value & ListBox1.Text)
        LblPicture.Text = Mid(ListBox1.Text, 1, Len(ListBox1.Text) - 4)
        RText.Visible = False
        PictureBox1.Visible = True
        If ListBox1.Text = "AddSpeech - Code.jpg" Then
            '   RText.Width = 680
            RText.Visible = True
            PictureBox1.Visible = False
            sFileName = "TextToSpeech.txt"
            rFile()
            'Lblname.Text = "TextToSpeech"
            ' speaker.SpeakAsync(TxtSay.Text) 'Talk
            sMsg = "'1.	Click on PROJECT and then ADD REFERENCE" & vbCrLf
            sMsg = sMsg & "'2.	Under ASSEMBLY Click on FRAMEWORK" & vbCrLf
            sMsg = sMsg & "'3.  Check SYSTEM SPEECH" & vbCrLf
            sMsg = sMsg & "'4.  Then Press OK"

            RText.Text = sMsg & "     " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub
End Class
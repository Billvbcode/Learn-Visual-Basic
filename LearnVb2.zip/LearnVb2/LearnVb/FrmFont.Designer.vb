﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmFont
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.RBBoldU = New System.Windows.Forms.RadioButton()
        Me.RBU = New System.Windows.Forms.RadioButton()
        Me.RBBold = New System.Windows.Forms.RadioButton()
        Me.RBReg = New System.Windows.Forms.RadioButton()
        Me.ChkBorder = New System.Windows.Forms.CheckBox()
        Me.ChkVisible = New System.Windows.Forms.CheckBox()
        Me.ChkEnable = New System.Windows.Forms.CheckBox()
        Me.ChkAuto = New System.Windows.Forms.CheckBox()
        Me.LblTest = New System.Windows.Forms.Label()
        Me.TxtText = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BTNFBlack = New System.Windows.Forms.Button()
        Me.BTNBDefault = New System.Windows.Forms.Button()
        Me.BTNFBlue = New System.Windows.Forms.Button()
        Me.BTNFRed = New System.Windows.Forms.Button()
        Me.BTNFOrange = New System.Windows.Forms.Button()
        Me.BTNFGreen = New System.Windows.Forms.Button()
        Me.BTNFAqua = New System.Windows.Forms.Button()
        Me.BTNBBlue = New System.Windows.Forms.Button()
        Me.BTNBRed = New System.Windows.Forms.Button()
        Me.BTNBOrange = New System.Windows.Forms.Button()
        Me.BTNBGreen = New System.Windows.Forms.Button()
        Me.BTNBAqua = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RBStrike = New System.Windows.Forms.RadioButton()
        Me.RBItalic = New System.Windows.Forms.RadioButton()
        Me.RText = New System.Windows.Forms.RichTextBox()
        Me.LblCode = New System.Windows.Forms.Label()
        Me.CB10 = New System.Windows.Forms.CheckBox()
        Me.CB14 = New System.Windows.Forms.CheckBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'RBBoldU
        '
        Me.RBBoldU.AutoSize = True
        Me.RBBoldU.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RBBoldU.Location = New System.Drawing.Point(36, 298)
        Me.RBBoldU.Name = "RBBoldU"
        Me.RBBoldU.Size = New System.Drawing.Size(180, 24)
        Me.RBBoldU.TabIndex = 22
        Me.RBBoldU.TabStop = True
        Me.RBBoldU.Text = "Bold and Underline"
        Me.RBBoldU.UseVisualStyleBackColor = True
        '
        'RBU
        '
        Me.RBU.AutoSize = True
        Me.RBU.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RBU.Location = New System.Drawing.Point(342, 250)
        Me.RBU.Name = "RBU"
        Me.RBU.Size = New System.Drawing.Size(104, 24)
        Me.RBU.TabIndex = 21
        Me.RBU.TabStop = True
        Me.RBU.Text = "Underline"
        Me.RBU.UseVisualStyleBackColor = True
        '
        'RBBold
        '
        Me.RBBold.AutoSize = True
        Me.RBBold.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RBBold.Location = New System.Drawing.Point(153, 250)
        Me.RBBold.Name = "RBBold"
        Me.RBBold.Size = New System.Drawing.Size(63, 24)
        Me.RBBold.TabIndex = 20
        Me.RBBold.TabStop = True
        Me.RBBold.Text = "Bold"
        Me.RBBold.UseVisualStyleBackColor = True
        '
        'RBReg
        '
        Me.RBReg.AutoSize = True
        Me.RBReg.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RBReg.Location = New System.Drawing.Point(36, 250)
        Me.RBReg.Name = "RBReg"
        Me.RBReg.Size = New System.Drawing.Size(90, 24)
        Me.RBReg.TabIndex = 19
        Me.RBReg.TabStop = True
        Me.RBReg.Text = "Regular"
        Me.RBReg.UseVisualStyleBackColor = True
        '
        'ChkBorder
        '
        Me.ChkBorder.AutoSize = True
        Me.ChkBorder.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkBorder.Location = New System.Drawing.Point(421, 128)
        Me.ChkBorder.Name = "ChkBorder"
        Me.ChkBorder.Size = New System.Drawing.Size(82, 24)
        Me.ChkBorder.TabIndex = 18
        Me.ChkBorder.Text = "Border"
        Me.ChkBorder.UseVisualStyleBackColor = True
        '
        'ChkVisible
        '
        Me.ChkVisible.AutoSize = True
        Me.ChkVisible.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkVisible.Location = New System.Drawing.Point(276, 128)
        Me.ChkVisible.Name = "ChkVisible"
        Me.ChkVisible.Size = New System.Drawing.Size(81, 24)
        Me.ChkVisible.TabIndex = 17
        Me.ChkVisible.Text = "Visible"
        Me.ChkVisible.UseVisualStyleBackColor = True
        '
        'ChkEnable
        '
        Me.ChkEnable.AutoSize = True
        Me.ChkEnable.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkEnable.Location = New System.Drawing.Point(162, 128)
        Me.ChkEnable.Name = "ChkEnable"
        Me.ChkEnable.Size = New System.Drawing.Size(84, 24)
        Me.ChkEnable.TabIndex = 16
        Me.ChkEnable.Text = "Enable"
        Me.ChkEnable.UseVisualStyleBackColor = True
        '
        'ChkAuto
        '
        Me.ChkAuto.AutoSize = True
        Me.ChkAuto.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ChkAuto.Location = New System.Drawing.Point(36, 128)
        Me.ChkAuto.Name = "ChkAuto"
        Me.ChkAuto.Size = New System.Drawing.Size(98, 24)
        Me.ChkAuto.TabIndex = 15
        Me.ChkAuto.Text = "Autosize"
        Me.ChkAuto.UseVisualStyleBackColor = True
        '
        'LblTest
        '
        Me.LblTest.AutoSize = True
        Me.LblTest.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTest.Location = New System.Drawing.Point(46, 60)
        Me.LblTest.Name = "LblTest"
        Me.LblTest.Size = New System.Drawing.Size(116, 20)
        Me.LblTest.TabIndex = 14
        Me.LblTest.Text = "This is a  test"
        '
        'TxtText
        '
        Me.TxtText.Location = New System.Drawing.Point(310, 52)
        Me.TxtText.Name = "TxtText"
        Me.TxtText.Size = New System.Drawing.Size(320, 20)
        Me.TxtText.TabIndex = 25
        Me.TxtText.Text = "This is a  test"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(191, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 20)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "FONT"
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.BTNFBlack)
        Me.Panel1.Controls.Add(Me.BTNBDefault)
        Me.Panel1.Controls.Add(Me.BTNFBlue)
        Me.Panel1.Controls.Add(Me.BTNFRed)
        Me.Panel1.Controls.Add(Me.BTNFOrange)
        Me.Panel1.Controls.Add(Me.BTNFGreen)
        Me.Panel1.Controls.Add(Me.BTNFAqua)
        Me.Panel1.Controls.Add(Me.BTNBBlue)
        Me.Panel1.Controls.Add(Me.BTNBRed)
        Me.Panel1.Controls.Add(Me.BTNBOrange)
        Me.Panel1.Controls.Add(Me.BTNBGreen)
        Me.Panel1.Controls.Add(Me.BTNBAqua)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Location = New System.Drawing.Point(713, 29)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(189, 524)
        Me.Panel1.TabIndex = 27
        '
        'BTNFBlack
        '
        Me.BTNFBlack.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNFBlack.Location = New System.Drawing.Point(28, 460)
        Me.BTNFBlack.Name = "BTNFBlack"
        Me.BTNFBlack.Size = New System.Drawing.Size(75, 23)
        Me.BTNFBlack.TabIndex = 40
        Me.BTNFBlack.Text = "Black"
        Me.BTNFBlack.UseVisualStyleBackColor = True
        '
        'BTNBDefault
        '
        Me.BTNBDefault.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNBDefault.Location = New System.Drawing.Point(15, 222)
        Me.BTNBDefault.Name = "BTNBDefault"
        Me.BTNBDefault.Size = New System.Drawing.Size(75, 23)
        Me.BTNBDefault.TabIndex = 39
        Me.BTNBDefault.Text = "Default"
        Me.BTNBDefault.UseVisualStyleBackColor = True
        '
        'BTNFBlue
        '
        Me.BTNFBlue.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNFBlue.Location = New System.Drawing.Point(28, 335)
        Me.BTNFBlue.Name = "BTNFBlue"
        Me.BTNFBlue.Size = New System.Drawing.Size(75, 23)
        Me.BTNFBlue.TabIndex = 38
        Me.BTNFBlue.Text = "Blue"
        Me.BTNFBlue.UseVisualStyleBackColor = True
        '
        'BTNFRed
        '
        Me.BTNFRed.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNFRed.Location = New System.Drawing.Point(28, 422)
        Me.BTNFRed.Name = "BTNFRed"
        Me.BTNFRed.Size = New System.Drawing.Size(75, 23)
        Me.BTNFRed.TabIndex = 37
        Me.BTNFRed.Text = "Red"
        Me.BTNFRed.UseVisualStyleBackColor = True
        '
        'BTNFOrange
        '
        Me.BTNFOrange.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNFOrange.Location = New System.Drawing.Point(28, 393)
        Me.BTNFOrange.Name = "BTNFOrange"
        Me.BTNFOrange.Size = New System.Drawing.Size(75, 23)
        Me.BTNFOrange.TabIndex = 36
        Me.BTNFOrange.Text = "Orange"
        Me.BTNFOrange.UseVisualStyleBackColor = True
        '
        'BTNFGreen
        '
        Me.BTNFGreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNFGreen.Location = New System.Drawing.Point(28, 364)
        Me.BTNFGreen.Name = "BTNFGreen"
        Me.BTNFGreen.Size = New System.Drawing.Size(75, 23)
        Me.BTNFGreen.TabIndex = 35
        Me.BTNFGreen.Text = "Green"
        Me.BTNFGreen.UseVisualStyleBackColor = True
        '
        'BTNFAqua
        '
        Me.BTNFAqua.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNFAqua.Location = New System.Drawing.Point(28, 306)
        Me.BTNFAqua.Name = "BTNFAqua"
        Me.BTNFAqua.Size = New System.Drawing.Size(75, 23)
        Me.BTNFAqua.TabIndex = 34
        Me.BTNFAqua.Text = "Aqua"
        Me.BTNFAqua.UseVisualStyleBackColor = True
        '
        'BTNBBlue
        '
        Me.BTNBBlue.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNBBlue.Location = New System.Drawing.Point(15, 101)
        Me.BTNBBlue.Name = "BTNBBlue"
        Me.BTNBBlue.Size = New System.Drawing.Size(75, 23)
        Me.BTNBBlue.TabIndex = 33
        Me.BTNBBlue.Text = "Blue"
        Me.BTNBBlue.UseVisualStyleBackColor = True
        '
        'BTNBRed
        '
        Me.BTNBRed.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNBRed.Location = New System.Drawing.Point(15, 188)
        Me.BTNBRed.Name = "BTNBRed"
        Me.BTNBRed.Size = New System.Drawing.Size(75, 23)
        Me.BTNBRed.TabIndex = 32
        Me.BTNBRed.Text = "Red"
        Me.BTNBRed.UseVisualStyleBackColor = True
        '
        'BTNBOrange
        '
        Me.BTNBOrange.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNBOrange.Location = New System.Drawing.Point(15, 159)
        Me.BTNBOrange.Name = "BTNBOrange"
        Me.BTNBOrange.Size = New System.Drawing.Size(75, 23)
        Me.BTNBOrange.TabIndex = 31
        Me.BTNBOrange.Text = "Orange"
        Me.BTNBOrange.UseVisualStyleBackColor = True
        '
        'BTNBGreen
        '
        Me.BTNBGreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNBGreen.Location = New System.Drawing.Point(15, 130)
        Me.BTNBGreen.Name = "BTNBGreen"
        Me.BTNBGreen.Size = New System.Drawing.Size(75, 23)
        Me.BTNBGreen.TabIndex = 30
        Me.BTNBGreen.Text = "Green"
        Me.BTNBGreen.UseVisualStyleBackColor = True
        '
        'BTNBAqua
        '
        Me.BTNBAqua.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNBAqua.Location = New System.Drawing.Point(15, 69)
        Me.BTNBAqua.Name = "BTNBAqua"
        Me.BTNBAqua.Size = New System.Drawing.Size(75, 23)
        Me.BTNBAqua.TabIndex = 29
        Me.BTNBAqua.Text = "Aqua"
        Me.BTNBAqua.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(11, 268)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(134, 20)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "ForeColor(Text)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(91, 20)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "BackColor"
        '
        'RBStrike
        '
        Me.RBStrike.AutoSize = True
        Me.RBStrike.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RBStrike.Location = New System.Drawing.Point(500, 250)
        Me.RBStrike.Name = "RBStrike"
        Me.RBStrike.Size = New System.Drawing.Size(103, 24)
        Me.RBStrike.TabIndex = 28
        Me.RBStrike.TabStop = True
        Me.RBStrike.Text = "StrikeOut"
        Me.RBStrike.UseVisualStyleBackColor = True
        '
        'RBItalic
        '
        Me.RBItalic.AutoSize = True
        Me.RBItalic.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RBItalic.Location = New System.Drawing.Point(231, 250)
        Me.RBItalic.Name = "RBItalic"
        Me.RBItalic.Size = New System.Drawing.Size(66, 24)
        Me.RBItalic.TabIndex = 29
        Me.RBItalic.TabStop = True
        Me.RBItalic.Text = "Italic"
        Me.RBItalic.UseVisualStyleBackColor = True
        '
        'RText
        '
        Me.RText.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RText.Location = New System.Drawing.Point(13, 362)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(685, 283)
        Me.RText.TabIndex = 30
        Me.RText.Text = ""
        '
        'LblCode
        '
        Me.LblCode.AutoSize = True
        Me.LblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCode.Location = New System.Drawing.Point(12, 339)
        Me.LblCode.Name = "LblCode"
        Me.LblCode.Size = New System.Drawing.Size(51, 20)
        Me.LblCode.TabIndex = 31
        Me.LblCode.Text = "Code"
        '
        'CB10
        '
        Me.CB10.AutoSize = True
        Me.CB10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CB10.Location = New System.Drawing.Point(36, 188)
        Me.CB10.Name = "CB10"
        Me.CB10.Size = New System.Drawing.Size(90, 24)
        Me.CB10.TabIndex = 32
        Me.CB10.Text = "Font 10"
        Me.CB10.UseVisualStyleBackColor = True
        '
        'CB14
        '
        Me.CB14.AutoSize = True
        Me.CB14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CB14.Location = New System.Drawing.Point(177, 188)
        Me.CB14.Name = "CB14"
        Me.CB14.Size = New System.Drawing.Size(90, 24)
        Me.CB14.TabIndex = 33
        Me.CB14.Text = "Font 14"
        Me.CB14.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(307, 82)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(309, 16)
        Me.Label4.TabIndex = 34
        Me.Label4.Text = "(Enter text and press return to copy to label)"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(33, 85)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(180, 13)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "(Mouse Over To change color)"
        '
        'FrmFont
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(925, 670)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.CB14)
        Me.Controls.Add(Me.CB10)
        Me.Controls.Add(Me.LblCode)
        Me.Controls.Add(Me.RText)
        Me.Controls.Add(Me.RBItalic)
        Me.Controls.Add(Me.RBStrike)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtText)
        Me.Controls.Add(Me.RBBoldU)
        Me.Controls.Add(Me.RBU)
        Me.Controls.Add(Me.RBBold)
        Me.Controls.Add(Me.RBReg)
        Me.Controls.Add(Me.ChkBorder)
        Me.Controls.Add(Me.ChkVisible)
        Me.Controls.Add(Me.ChkEnable)
        Me.Controls.Add(Me.ChkAuto)
        Me.Controls.Add(Me.LblTest)
        Me.Name = "FrmFont"
        Me.Text = "v"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RBBoldU As RadioButton
    Friend WithEvents RBU As RadioButton
    Friend WithEvents RBBold As RadioButton
    Friend WithEvents RBReg As RadioButton
    Friend WithEvents ChkBorder As CheckBox
    Friend WithEvents ChkVisible As CheckBox
    Friend WithEvents ChkEnable As CheckBox
    Friend WithEvents ChkAuto As CheckBox
    Friend WithEvents LblTest As Label
    Friend WithEvents TxtText As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents BTNFBlue As Button
    Friend WithEvents BTNFRed As Button
    Friend WithEvents BTNFOrange As Button
    Friend WithEvents BTNFGreen As Button
    Friend WithEvents BTNFAqua As Button
    Friend WithEvents BTNBBlue As Button
    Friend WithEvents BTNBRed As Button
    Friend WithEvents BTNBOrange As Button
    Friend WithEvents BTNBGreen As Button
    Friend WithEvents BTNBAqua As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents RBStrike As RadioButton
    Friend WithEvents RBItalic As RadioButton
    Friend WithEvents RText As RichTextBox
    Friend WithEvents LblCode As Label
    Friend WithEvents BTNFBlack As Button
    Friend WithEvents BTNBDefault As Button
    Friend WithEvents CB10 As CheckBox
    Friend WithEvents CB14 As CheckBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
End Class

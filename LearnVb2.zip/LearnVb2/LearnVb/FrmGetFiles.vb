﻿Public Class FrmGetFiles
    Dim sFileName As String
    Dim sMsg As String
    Private Sub BtnGet_Click(sender As Object, e As EventArgs) Handles BtnGet.Click
        sFileName = "GetFiles.txt"
        rFile()
        LblName.Text = "GetFiles"
        sMsg = "'Get Files with .Map extension "
        RText.Text = sMsg & vbCrLf & RText.Text
        RText.Select(1, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub

    Private Sub BtnRead_Click(sender As Object, e As EventArgs) Handles BtnRead.Click
        sFileName = "ReadFile.txt"
        rFile()
        LblName.Text = "ReadFile"
        sMsg = "'Read one line only "
        RText.Text = sMsg & vbCrLf & RText.Text
        RText.Select(1, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnLine_Click(sender As Object, e As EventArgs) Handles BtnLine.Click
        sFileName = "ReadLine.txt"
        rFile()
        LblName.Text = "ReadbyLine"
        sMsg = "'Read line by line "
        RText.Text = sMsg & vbCrLf & RText.Text
        RText.Select(1, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        sFileName = "CheckDir.txt"
        rFile()
        LblName.Text = "CheckDir"
        sMsg = "'CheckDir and create a new directory if needed "
        RText.Text = sMsg & vbCrLf & RText.Text
        RText.Select(1, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnWrite_Click(sender As Object, e As EventArgs) Handles BtnWrite.Click
        sFileName = "WriteFile.txt"
        rFile()
        LblName.Text = "WriteFile"
        sMsg = "'Write to a file "
        RText.Text = sMsg & vbCrLf & RText.Text
        RText.Select(1, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
End Class
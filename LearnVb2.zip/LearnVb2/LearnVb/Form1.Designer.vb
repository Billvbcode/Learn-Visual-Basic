﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.LblCode = New System.Windows.Forms.Label()
        Me.RText = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BtnModule = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BtnScreen = New System.Windows.Forms.Button()
        Me.BtnDraw = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.BtnShow = New System.Windows.Forms.Button()
        Me.BtnFormat = New System.Windows.Forms.Button()
        Me.BtnCreate = New System.Windows.Forms.Button()
        Me.BtnTools = New System.Windows.Forms.Button()
        Me.BtnInput = New System.Windows.Forms.Button()
        Me.BtnMsg = New System.Windows.Forms.Button()
        Me.BtnVariable = New System.Windows.Forms.Button()
        Me.BtnClass = New System.Windows.Forms.Button()
        Me.BtnMath = New System.Windows.Forms.Button()
        Me.BtnIf = New System.Windows.Forms.Button()
        Me.BtnListbox = New System.Windows.Forms.Button()
        Me.BtnSounds = New System.Windows.Forms.Button()
        Me.BtnGetFiles = New System.Windows.Forms.Button()
        Me.BtnString = New System.Windows.Forms.Button()
        Me.BtnLoop = New System.Windows.Forms.Button()
        Me.BtnTimer = New System.Windows.Forms.Button()
        Me.BtnPicture = New System.Windows.Forms.Button()
        Me.BtnColor = New System.Windows.Forms.Button()
        Me.BtnFont = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'LblCode
        '
        Me.LblCode.AutoSize = True
        Me.LblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCode.Location = New System.Drawing.Point(7, 471)
        Me.LblCode.Name = "LblCode"
        Me.LblCode.Size = New System.Drawing.Size(51, 20)
        Me.LblCode.TabIndex = 34
        Me.LblCode.Text = "Code"
        '
        'RText
        '
        Me.RText.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RText.Location = New System.Drawing.Point(11, 494)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(710, 119)
        Me.RText.TabIndex = 33
        Me.RText.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(236, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(268, 20)
        Me.Label1.TabIndex = 39
        Me.Label1.Text = "What would you like to learn ???"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(226, 20)
        Me.Label2.TabIndex = 40
        Me.Label2.Text = "VB.Net 2019 (Visual Basic)"
        '
        'BtnModule
        '
        Me.BtnModule.BackgroundImage = CType(resources.GetObject("BtnModule.BackgroundImage"), System.Drawing.Image)
        Me.BtnModule.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnModule.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnModule.Location = New System.Drawing.Point(423, 396)
        Me.BtnModule.Name = "BtnModule"
        Me.BtnModule.Size = New System.Drawing.Size(145, 64)
        Me.BtnModule.TabIndex = 44
        Me.BtnModule.Text = "Module"
        Me.BtnModule.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnModule.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.BackgroundImage = CType(resources.GetObject("Button4.BackgroundImage"), System.Drawing.Image)
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(369, 326)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(94, 64)
        Me.Button4.TabIndex = 43
        Me.Button4.Text = "Shell"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), System.Drawing.Image)
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(240, 396)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(177, 64)
        Me.Button3.TabIndex = 42
        Me.Button3.Text = "Picture Transparent"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(12, 396)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(202, 64)
        Me.Button1.TabIndex = 41
        Me.Button1.Text = "Picture " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "SendBack/BringFront"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BtnScreen
        '
        Me.BtnScreen.BackgroundImage = CType(resources.GetObject("BtnScreen.BackgroundImage"), System.Drawing.Image)
        Me.BtnScreen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnScreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnScreen.Location = New System.Drawing.Point(469, 326)
        Me.BtnScreen.Name = "BtnScreen"
        Me.BtnScreen.Size = New System.Drawing.Size(252, 64)
        Me.BtnScreen.TabIndex = 38
        Me.BtnScreen.Text = "VB2019 Screen"
        Me.BtnScreen.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnScreen.UseVisualStyleBackColor = True
        '
        'BtnDraw
        '
        Me.BtnDraw.BackgroundImage = CType(resources.GetObject("BtnDraw.BackgroundImage"), System.Drawing.Image)
        Me.BtnDraw.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnDraw.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnDraw.Location = New System.Drawing.Point(240, 326)
        Me.BtnDraw.Name = "BtnDraw"
        Me.BtnDraw.Size = New System.Drawing.Size(123, 64)
        Me.BtnDraw.TabIndex = 37
        Me.BtnDraw.Text = "Draw"
        Me.BtnDraw.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnDraw.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), System.Drawing.Image)
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(110, 326)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(124, 64)
        Me.Button2.TabIndex = 36
        Me.Button2.Text = "ShowDialog"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button2.UseVisualStyleBackColor = True
        '
        'BtnShow
        '
        Me.BtnShow.BackgroundImage = CType(resources.GetObject("BtnShow.BackgroundImage"), System.Drawing.Image)
        Me.BtnShow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnShow.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnShow.Location = New System.Drawing.Point(11, 326)
        Me.BtnShow.Name = "BtnShow"
        Me.BtnShow.Size = New System.Drawing.Size(89, 64)
        Me.BtnShow.TabIndex = 35
        Me.BtnShow.Text = "Show"
        Me.BtnShow.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnShow.UseVisualStyleBackColor = True
        '
        'BtnFormat
        '
        Me.BtnFormat.BackgroundImage = CType(resources.GetObject("BtnFormat.BackgroundImage"), System.Drawing.Image)
        Me.BtnFormat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnFormat.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFormat.Location = New System.Drawing.Point(598, 238)
        Me.BtnFormat.Name = "BtnFormat"
        Me.BtnFormat.Size = New System.Drawing.Size(123, 64)
        Me.BtnFormat.TabIndex = 17
        Me.BtnFormat.Text = "Format"
        Me.BtnFormat.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnFormat.UseVisualStyleBackColor = True
        '
        'BtnCreate
        '
        Me.BtnCreate.BackgroundImage = CType(resources.GetObject("BtnCreate.BackgroundImage"), System.Drawing.Image)
        Me.BtnCreate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnCreate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCreate.Location = New System.Drawing.Point(469, 238)
        Me.BtnCreate.Name = "BtnCreate"
        Me.BtnCreate.Size = New System.Drawing.Size(123, 64)
        Me.BtnCreate.TabIndex = 16
        Me.BtnCreate.Text = "Create Tools"
        Me.BtnCreate.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnCreate.UseVisualStyleBackColor = True
        '
        'BtnTools
        '
        Me.BtnTools.BackgroundImage = CType(resources.GetObject("BtnTools.BackgroundImage"), System.Drawing.Image)
        Me.BtnTools.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnTools.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTools.Location = New System.Drawing.Point(369, 238)
        Me.BtnTools.Name = "BtnTools"
        Me.BtnTools.Size = New System.Drawing.Size(94, 64)
        Me.BtnTools.TabIndex = 15
        Me.BtnTools.Text = "Tools"
        Me.BtnTools.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnTools.UseVisualStyleBackColor = True
        '
        'BtnInput
        '
        Me.BtnInput.BackgroundImage = CType(resources.GetObject("BtnInput.BackgroundImage"), System.Drawing.Image)
        Me.BtnInput.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnInput.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnInput.Location = New System.Drawing.Point(240, 238)
        Me.BtnInput.Name = "BtnInput"
        Me.BtnInput.Size = New System.Drawing.Size(123, 64)
        Me.BtnInput.TabIndex = 14
        Me.BtnInput.Text = "InputBox"
        Me.BtnInput.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnInput.UseVisualStyleBackColor = True
        '
        'BtnMsg
        '
        Me.BtnMsg.BackgroundImage = CType(resources.GetObject("BtnMsg.BackgroundImage"), System.Drawing.Image)
        Me.BtnMsg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnMsg.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnMsg.Location = New System.Drawing.Point(106, 238)
        Me.BtnMsg.Name = "BtnMsg"
        Me.BtnMsg.Size = New System.Drawing.Size(128, 64)
        Me.BtnMsg.TabIndex = 13
        Me.BtnMsg.Text = "MsgBox"
        Me.BtnMsg.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnMsg.UseVisualStyleBackColor = True
        '
        'BtnVariable
        '
        Me.BtnVariable.BackgroundImage = CType(resources.GetObject("BtnVariable.BackgroundImage"), System.Drawing.Image)
        Me.BtnVariable.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnVariable.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnVariable.Location = New System.Drawing.Point(11, 238)
        Me.BtnVariable.Name = "BtnVariable"
        Me.BtnVariable.Size = New System.Drawing.Size(89, 64)
        Me.BtnVariable.TabIndex = 12
        Me.BtnVariable.Text = "Variable"
        Me.BtnVariable.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnVariable.UseVisualStyleBackColor = True
        '
        'BtnClass
        '
        Me.BtnClass.BackgroundImage = CType(resources.GetObject("BtnClass.BackgroundImage"), System.Drawing.Image)
        Me.BtnClass.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnClass.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClass.Location = New System.Drawing.Point(598, 138)
        Me.BtnClass.Name = "BtnClass"
        Me.BtnClass.Size = New System.Drawing.Size(123, 64)
        Me.BtnClass.TabIndex = 11
        Me.BtnClass.Text = "Class"
        Me.BtnClass.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnClass.UseVisualStyleBackColor = True
        '
        'BtnMath
        '
        Me.BtnMath.BackgroundImage = CType(resources.GetObject("BtnMath.BackgroundImage"), System.Drawing.Image)
        Me.BtnMath.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnMath.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnMath.Location = New System.Drawing.Point(469, 138)
        Me.BtnMath.Name = "BtnMath"
        Me.BtnMath.Size = New System.Drawing.Size(123, 64)
        Me.BtnMath.TabIndex = 10
        Me.BtnMath.Text = "Math"
        Me.BtnMath.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnMath.UseVisualStyleBackColor = True
        '
        'BtnIf
        '
        Me.BtnIf.BackgroundImage = CType(resources.GetObject("BtnIf.BackgroundImage"), System.Drawing.Image)
        Me.BtnIf.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnIf.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnIf.Location = New System.Drawing.Point(369, 138)
        Me.BtnIf.Name = "BtnIf"
        Me.BtnIf.Size = New System.Drawing.Size(94, 64)
        Me.BtnIf.TabIndex = 9
        Me.BtnIf.Text = "IF"
        Me.BtnIf.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnIf.UseVisualStyleBackColor = True
        '
        'BtnListbox
        '
        Me.BtnListbox.BackgroundImage = CType(resources.GetObject("BtnListbox.BackgroundImage"), System.Drawing.Image)
        Me.BtnListbox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnListbox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnListbox.Location = New System.Drawing.Point(240, 138)
        Me.BtnListbox.Name = "BtnListbox"
        Me.BtnListbox.Size = New System.Drawing.Size(123, 64)
        Me.BtnListbox.TabIndex = 8
        Me.BtnListbox.Text = "Listbox"
        Me.BtnListbox.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnListbox.UseVisualStyleBackColor = True
        '
        'BtnSounds
        '
        Me.BtnSounds.BackgroundImage = CType(resources.GetObject("BtnSounds.BackgroundImage"), System.Drawing.Image)
        Me.BtnSounds.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnSounds.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSounds.Location = New System.Drawing.Point(106, 138)
        Me.BtnSounds.Name = "BtnSounds"
        Me.BtnSounds.Size = New System.Drawing.Size(128, 64)
        Me.BtnSounds.TabIndex = 7
        Me.BtnSounds.Text = "Sounds"
        Me.BtnSounds.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnSounds.UseVisualStyleBackColor = True
        '
        'BtnGetFiles
        '
        Me.BtnGetFiles.BackgroundImage = CType(resources.GetObject("BtnGetFiles.BackgroundImage"), System.Drawing.Image)
        Me.BtnGetFiles.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnGetFiles.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnGetFiles.Location = New System.Drawing.Point(11, 138)
        Me.BtnGetFiles.Name = "BtnGetFiles"
        Me.BtnGetFiles.Size = New System.Drawing.Size(89, 64)
        Me.BtnGetFiles.TabIndex = 6
        Me.BtnGetFiles.Text = "Files"
        Me.BtnGetFiles.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnGetFiles.UseVisualStyleBackColor = True
        '
        'BtnString
        '
        Me.BtnString.BackgroundImage = CType(resources.GetObject("BtnString.BackgroundImage"), System.Drawing.Image)
        Me.BtnString.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnString.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnString.Location = New System.Drawing.Point(598, 46)
        Me.BtnString.Name = "BtnString"
        Me.BtnString.Size = New System.Drawing.Size(123, 64)
        Me.BtnString.TabIndex = 5
        Me.BtnString.Text = "String"
        Me.BtnString.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnString.UseVisualStyleBackColor = True
        '
        'BtnLoop
        '
        Me.BtnLoop.BackgroundImage = CType(resources.GetObject("BtnLoop.BackgroundImage"), System.Drawing.Image)
        Me.BtnLoop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnLoop.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLoop.Location = New System.Drawing.Point(469, 46)
        Me.BtnLoop.Name = "BtnLoop"
        Me.BtnLoop.Size = New System.Drawing.Size(123, 64)
        Me.BtnLoop.TabIndex = 4
        Me.BtnLoop.Text = "Loops"
        Me.BtnLoop.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnLoop.UseVisualStyleBackColor = True
        '
        'BtnTimer
        '
        Me.BtnTimer.BackgroundImage = CType(resources.GetObject("BtnTimer.BackgroundImage"), System.Drawing.Image)
        Me.BtnTimer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnTimer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTimer.Location = New System.Drawing.Point(369, 46)
        Me.BtnTimer.Name = "BtnTimer"
        Me.BtnTimer.Size = New System.Drawing.Size(94, 64)
        Me.BtnTimer.TabIndex = 3
        Me.BtnTimer.Text = "Timer"
        Me.BtnTimer.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnTimer.UseVisualStyleBackColor = True
        '
        'BtnPicture
        '
        Me.BtnPicture.BackgroundImage = CType(resources.GetObject("BtnPicture.BackgroundImage"), System.Drawing.Image)
        Me.BtnPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnPicture.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPicture.Location = New System.Drawing.Point(240, 46)
        Me.BtnPicture.Name = "BtnPicture"
        Me.BtnPicture.Size = New System.Drawing.Size(123, 64)
        Me.BtnPicture.TabIndex = 2
        Me.BtnPicture.Text = "Picture"
        Me.BtnPicture.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnPicture.UseVisualStyleBackColor = True
        '
        'BtnColor
        '
        Me.BtnColor.BackgroundImage = CType(resources.GetObject("BtnColor.BackgroundImage"), System.Drawing.Image)
        Me.BtnColor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnColor.Location = New System.Drawing.Point(106, 46)
        Me.BtnColor.Name = "BtnColor"
        Me.BtnColor.Size = New System.Drawing.Size(128, 64)
        Me.BtnColor.TabIndex = 1
        Me.BtnColor.Text = "Color"
        Me.BtnColor.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnColor.UseVisualStyleBackColor = True
        '
        'BtnFont
        '
        Me.BtnFont.BackgroundImage = CType(resources.GetObject("BtnFont.BackgroundImage"), System.Drawing.Image)
        Me.BtnFont.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.BtnFont.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFont.Location = New System.Drawing.Point(11, 46)
        Me.BtnFont.Name = "BtnFont"
        Me.BtnFont.Size = New System.Drawing.Size(89, 64)
        Me.BtnFont.TabIndex = 0
        Me.BtnFont.Text = "Fonts"
        Me.BtnFont.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BtnFont.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.BackgroundImage = CType(resources.GetObject("Button5.BackgroundImage"), System.Drawing.Image)
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(588, 396)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(133, 64)
        Me.Button5.TabIndex = 45
        Me.Button5.Text = "Search"
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(736, 612)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.BtnModule)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnScreen)
        Me.Controls.Add(Me.BtnDraw)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.BtnShow)
        Me.Controls.Add(Me.LblCode)
        Me.Controls.Add(Me.RText)
        Me.Controls.Add(Me.BtnFormat)
        Me.Controls.Add(Me.BtnCreate)
        Me.Controls.Add(Me.BtnTools)
        Me.Controls.Add(Me.BtnInput)
        Me.Controls.Add(Me.BtnMsg)
        Me.Controls.Add(Me.BtnVariable)
        Me.Controls.Add(Me.BtnClass)
        Me.Controls.Add(Me.BtnMath)
        Me.Controls.Add(Me.BtnIf)
        Me.Controls.Add(Me.BtnListbox)
        Me.Controls.Add(Me.BtnSounds)
        Me.Controls.Add(Me.BtnGetFiles)
        Me.Controls.Add(Me.BtnString)
        Me.Controls.Add(Me.BtnLoop)
        Me.Controls.Add(Me.BtnTimer)
        Me.Controls.Add(Me.BtnPicture)
        Me.Controls.Add(Me.BtnColor)
        Me.Controls.Add(Me.BtnFont)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "VB.net Code Examples"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BtnFont As Button
    Friend WithEvents BtnColor As Button
    Friend WithEvents BtnPicture As Button
    Friend WithEvents BtnTimer As Button
    Friend WithEvents BtnLoop As Button
    Friend WithEvents BtnString As Button
    Friend WithEvents BtnGetFiles As Button
    Friend WithEvents BtnSounds As Button
    Friend WithEvents BtnListbox As Button
    Friend WithEvents BtnIf As Button
    Friend WithEvents BtnMath As Button
    Friend WithEvents BtnClass As Button
    Friend WithEvents BtnVariable As Button
    Friend WithEvents BtnMsg As Button
    Friend WithEvents BtnInput As Button
    Friend WithEvents BtnTools As Button
    Friend WithEvents BtnCreate As Button
    Friend WithEvents BtnFormat As Button
    Friend WithEvents LblCode As Label
    Friend WithEvents RText As RichTextBox
    Friend WithEvents BtnShow As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents BtnDraw As Button
    Friend WithEvents BtnScreen As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents BtnModule As Button
    Friend WithEvents Button5 As Button
End Class

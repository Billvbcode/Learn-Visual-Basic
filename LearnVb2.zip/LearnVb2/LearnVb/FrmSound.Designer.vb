﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSound
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LblCode = New System.Windows.Forms.Label()
        Me.RText = New System.Windows.Forms.RichTextBox()
        Me.Lblname = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TxtSay = New System.Windows.Forms.TextBox()
        Me.BtnTextToSpeech = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BtnConsole = New System.Windows.Forms.Button()
        Me.BtnConsole2 = New System.Windows.Forms.Button()
        Me.BntConsole3 = New System.Windows.Forms.Button()
        Me.BtnWave = New System.Windows.Forms.Button()
        Me.BtnWaveStop = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LblCode
        '
        Me.LblCode.AutoSize = True
        Me.LblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCode.Location = New System.Drawing.Point(8, 103)
        Me.LblCode.Name = "LblCode"
        Me.LblCode.Size = New System.Drawing.Size(51, 20)
        Me.LblCode.TabIndex = 37
        Me.LblCode.Text = "Code"
        '
        'RText
        '
        Me.RText.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RText.Location = New System.Drawing.Point(12, 142)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(680, 469)
        Me.RText.TabIndex = 36
        Me.RText.Text = ""
        '
        'Lblname
        '
        Me.Lblname.AutoSize = True
        Me.Lblname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lblname.Location = New System.Drawing.Point(65, 103)
        Me.Lblname.Name = "Lblname"
        Me.Lblname.Size = New System.Drawing.Size(39, 20)
        Me.Lblname.TabIndex = 42
        Me.Lblname.Text = "123"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 20)
        Me.Label1.TabIndex = 43
        Me.Label1.Text = "Say"
        '
        'TxtSay
        '
        Me.TxtSay.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtSay.Location = New System.Drawing.Point(53, 58)
        Me.TxtSay.Name = "TxtSay"
        Me.TxtSay.Size = New System.Drawing.Size(172, 22)
        Me.TxtSay.TabIndex = 44
        Me.TxtSay.Text = "Hello How are you?"
        '
        'BtnTextToSpeech
        '
        Me.BtnTextToSpeech.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTextToSpeech.Location = New System.Drawing.Point(12, 12)
        Me.BtnTextToSpeech.Name = "BtnTextToSpeech"
        Me.BtnTextToSpeech.Size = New System.Drawing.Size(168, 34)
        Me.BtnTextToSpeech.TabIndex = 45
        Me.BtnTextToSpeech.Text = "TextToSpeech"
        Me.BtnTextToSpeech.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(707, 142)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(340, 452)
        Me.PictureBox1.TabIndex = 46
        Me.PictureBox1.TabStop = False
        '
        'BtnConsole
        '
        Me.BtnConsole.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnConsole.Location = New System.Drawing.Point(200, 12)
        Me.BtnConsole.Name = "BtnConsole"
        Me.BtnConsole.Size = New System.Drawing.Size(134, 34)
        Me.BtnConsole.TabIndex = 47
        Me.BtnConsole.Text = "Console"
        Me.BtnConsole.UseVisualStyleBackColor = True
        '
        'BtnConsole2
        '
        Me.BtnConsole2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnConsole2.Location = New System.Drawing.Point(340, 12)
        Me.BtnConsole2.Name = "BtnConsole2"
        Me.BtnConsole2.Size = New System.Drawing.Size(148, 34)
        Me.BtnConsole2.TabIndex = 48
        Me.BtnConsole2.Text = "Console2"
        Me.BtnConsole2.UseVisualStyleBackColor = True
        '
        'BntConsole3
        '
        Me.BntConsole3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BntConsole3.Location = New System.Drawing.Point(514, 12)
        Me.BntConsole3.Name = "BntConsole3"
        Me.BntConsole3.Size = New System.Drawing.Size(168, 34)
        Me.BntConsole3.TabIndex = 49
        Me.BntConsole3.Text = "Console3"
        Me.BntConsole3.UseVisualStyleBackColor = True
        '
        'BtnWave
        '
        Me.BtnWave.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWave.Location = New System.Drawing.Point(707, 12)
        Me.BtnWave.Name = "BtnWave"
        Me.BtnWave.Size = New System.Drawing.Size(152, 34)
        Me.BtnWave.TabIndex = 50
        Me.BtnWave.Text = "Wave"
        Me.BtnWave.UseVisualStyleBackColor = True
        '
        'BtnWaveStop
        '
        Me.BtnWaveStop.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWaveStop.Location = New System.Drawing.Point(789, 60)
        Me.BtnWaveStop.Name = "BtnWaveStop"
        Me.BtnWaveStop.Size = New System.Drawing.Size(168, 34)
        Me.BtnWaveStop.TabIndex = 51
        Me.BtnWaveStop.Text = "StopWave"
        Me.BtnWaveStop.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(865, 12)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(152, 34)
        Me.Button2.TabIndex = 52
        Me.Button2.Text = "BackGround"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'FrmSound
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1045, 623)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.BtnWaveStop)
        Me.Controls.Add(Me.BtnWave)
        Me.Controls.Add(Me.BntConsole3)
        Me.Controls.Add(Me.BtnConsole2)
        Me.Controls.Add(Me.BtnConsole)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.BtnTextToSpeech)
        Me.Controls.Add(Me.TxtSay)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Lblname)
        Me.Controls.Add(Me.LblCode)
        Me.Controls.Add(Me.RText)
        Me.Name = "FrmSound"
        Me.Text = "FrmSound"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LblCode As Label
    Friend WithEvents RText As RichTextBox
    Friend WithEvents Lblname As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TxtSay As TextBox
    Friend WithEvents BtnTextToSpeech As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents BtnConsole As Button
    Friend WithEvents BtnConsole2 As Button
    Friend WithEvents BntConsole3 As Button
    Friend WithEvents BtnWave As Button
    Friend WithEvents BtnWaveStop As Button
    Friend WithEvents Button2 As Button
End Class

﻿Public Class Form1
    Private Sub BtnFont_Click(sender As Object, e As EventArgs) Handles BtnFont.Click
        FrmFont.ShowDialog()
    End Sub

    Private Sub BtnColor_Click(sender As Object, e As EventArgs) Handles BtnColor.Click
        FrmColor.ShowDialog()
    End Sub

    Private Sub BtnPicture_Click(sender As Object, e As EventArgs) Handles BtnPicture.Click
        FrmPicture.ShowDialog()
    End Sub

    Private Sub BtnTimer_Click(sender As Object, e As EventArgs) Handles BtnTimer.Click
        FrmTimer.ShowDialog()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        bBtnImage = True
        bPicImage = True
        Dim sMsg As String
        Dim sMsg2 As String
        Dim i As Integer
        RText.Text = "FrmShowvb.Show()  "
        sMsg = "'FrmShowvb.Show()  Can Switch between the two forms"
        sMsg2 = "'FrmSelect.ShowDialog()  Can Only use FrmSelect"
        RText.Text = sMsg & "   " & vbCrLf & RText.Text & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg2)
        RText.Select(i, Len(sMsg2))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnLoop_Click(sender As Object, e As EventArgs) Handles BtnLoop.Click
        FrmLoop.ShowDialog()
    End Sub

    Private Sub BtnString_Click(sender As Object, e As EventArgs) Handles BtnString.Click
        FrmString.ShowDialog()
    End Sub

    Private Sub BtnGetFiles_Click(sender As Object, e As EventArgs) Handles BtnGetFiles.Click
        FrmGetFiles.ShowDialog()
    End Sub

    Private Sub BtnSounds_Click(sender As Object, e As EventArgs) Handles BtnSounds.Click
        FrmSound.ShowDialog()
    End Sub

    Private Sub BtnListbox_Click(sender As Object, e As EventArgs) Handles BtnListbox.Click
        FrmListBox.ShowDialog()
    End Sub

    Private Sub BtnIf_Click(sender As Object, e As EventArgs) Handles BtnIf.Click
        FrmIf.ShowDialog()
    End Sub

    Private Sub BtnMath_Click(sender As Object, e As EventArgs) Handles BtnMath.Click
        FrmMath.ShowDialog()
    End Sub

    Private Sub BtnClass_Click(sender As Object, e As EventArgs) Handles BtnClass.Click
        FrmClassvb.ShowDialog()
    End Sub

    Private Sub BtnVariable_Click(sender As Object, e As EventArgs) Handles BtnVariable.Click
        FrmVariable.ShowDialog()
    End Sub

    Private Sub BtnMsg_Click(sender As Object, e As EventArgs) Handles BtnMsg.Click
        FrmMsg.ShowDialog()
    End Sub

    Private Sub BtnInput_Click(sender As Object, e As EventArgs) Handles BtnInput.Click
        FrmMsg.ShowDialog()
    End Sub

    Private Sub BtnTools_Click(sender As Object, e As EventArgs) Handles BtnTools.Click
        FrmTools.ShowDialog()
    End Sub

    Private Sub BtnCreate_Click(sender As Object, e As EventArgs) Handles BtnCreate.Click
        FrmCreate.ShowDialog()
    End Sub

    Private Sub BtnFormat_Click(sender As Object, e As EventArgs) Handles BtnFormat.Click
        FrmFormat.ShowDialog()
    End Sub

    Private Sub BtnShow_Click(sender As Object, e As EventArgs) Handles BtnShow.Click
        sForm = "show"
        FrmSelect.Show()
        FrmSelect.Left = Me.Left - 150
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If sForm = "show" Then Exit Sub
        sForm = "?"
        FrmSelect.ShowDialog()
        FrmSelect.Left = Me.Left - 150
    End Sub

    Private Sub BtnDraw_Click(sender As Object, e As EventArgs) Handles BtnDraw.Click
        FrmDraw.ShowDialog()
    End Sub

    Private Sub BtnScreen_Click(sender As Object, e As EventArgs) Handles BtnScreen.Click
        FrmScreenvb.ShowDialog()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form2.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form3.ShowDialog()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        FrmShell.ShowDialog()
    End Sub

    Private Sub BtnModule_Click(sender As Object, e As EventArgs) Handles BtnModule.Click
        FrmModule.ShowDialog()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        FrmFile.ShowDialog()
    End Sub
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmPicture
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.LblPicture = New System.Windows.Forms.Label()
        Me.BtnUp = New System.Windows.Forms.Button()
        Me.BtnDown = New System.Windows.Forms.Button()
        Me.BtnRight = New System.Windows.Forms.Button()
        Me.BtnLeft = New System.Windows.Forms.Button()
        Me.LblCode = New System.Windows.Forms.Label()
        Me.RText = New System.Windows.Forms.RichTextBox()
        Me.BtnLarge = New System.Windows.Forms.Button()
        Me.BtnSmall = New System.Windows.Forms.Button()
        Me.BtnReset = New System.Windows.Forms.Button()
        Me.TxtTop = New System.Windows.Forms.TextBox()
        Me.TxtLeft = New System.Windows.Forms.TextBox()
        Me.TxtHeight = New System.Windows.Forms.TextBox()
        Me.TxtWidth = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.BtnSection = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.picResult = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.picResult, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(726, 58)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(189, 329)
        Me.ListBox1.TabIndex = 1
        '
        'LblPicture
        '
        Me.LblPicture.AutoSize = True
        Me.LblPicture.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblPicture.Location = New System.Drawing.Point(45, 18)
        Me.LblPicture.Name = "LblPicture"
        Me.LblPicture.Size = New System.Drawing.Size(55, 16)
        Me.LblPicture.TabIndex = 2
        Me.LblPicture.Text = "Label1"
        '
        'BtnUp
        '
        Me.BtnUp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnUp.Location = New System.Drawing.Point(88, 244)
        Me.BtnUp.Name = "BtnUp"
        Me.BtnUp.Size = New System.Drawing.Size(75, 23)
        Me.BtnUp.TabIndex = 3
        Me.BtnUp.Text = "Up"
        Me.BtnUp.UseVisualStyleBackColor = True
        '
        'BtnDown
        '
        Me.BtnDown.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnDown.Location = New System.Drawing.Point(88, 310)
        Me.BtnDown.Name = "BtnDown"
        Me.BtnDown.Size = New System.Drawing.Size(75, 23)
        Me.BtnDown.TabIndex = 4
        Me.BtnDown.Text = "Down"
        Me.BtnDown.UseVisualStyleBackColor = True
        '
        'BtnRight
        '
        Me.BtnRight.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRight.Location = New System.Drawing.Point(174, 279)
        Me.BtnRight.Name = "BtnRight"
        Me.BtnRight.Size = New System.Drawing.Size(75, 23)
        Me.BtnRight.TabIndex = 5
        Me.BtnRight.Text = "Right"
        Me.BtnRight.UseVisualStyleBackColor = True
        '
        'BtnLeft
        '
        Me.BtnLeft.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLeft.Location = New System.Drawing.Point(0, 279)
        Me.BtnLeft.Name = "BtnLeft"
        Me.BtnLeft.Size = New System.Drawing.Size(75, 23)
        Me.BtnLeft.TabIndex = 6
        Me.BtnLeft.Text = "Left"
        Me.BtnLeft.UseVisualStyleBackColor = True
        '
        'LblCode
        '
        Me.LblCode.AutoSize = True
        Me.LblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCode.Location = New System.Drawing.Point(12, 355)
        Me.LblCode.Name = "LblCode"
        Me.LblCode.Size = New System.Drawing.Size(51, 20)
        Me.LblCode.TabIndex = 33
        Me.LblCode.Text = "Code"
        '
        'RText
        '
        Me.RText.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RText.Location = New System.Drawing.Point(12, 393)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(811, 171)
        Me.RText.TabIndex = 32
        Me.RText.Text = ""
        '
        'BtnLarge
        '
        Me.BtnLarge.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLarge.Location = New System.Drawing.Point(291, 244)
        Me.BtnLarge.Name = "BtnLarge"
        Me.BtnLarge.Size = New System.Drawing.Size(75, 23)
        Me.BtnLarge.TabIndex = 34
        Me.BtnLarge.Text = "Large"
        Me.BtnLarge.UseVisualStyleBackColor = True
        '
        'BtnSmall
        '
        Me.BtnSmall.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSmall.Location = New System.Drawing.Point(291, 310)
        Me.BtnSmall.Name = "BtnSmall"
        Me.BtnSmall.Size = New System.Drawing.Size(75, 23)
        Me.BtnSmall.TabIndex = 35
        Me.BtnSmall.Text = "Small"
        Me.BtnSmall.UseVisualStyleBackColor = True
        '
        'BtnReset
        '
        Me.BtnReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnReset.Location = New System.Drawing.Point(405, 282)
        Me.BtnReset.Name = "BtnReset"
        Me.BtnReset.Size = New System.Drawing.Size(75, 23)
        Me.BtnReset.TabIndex = 36
        Me.BtnReset.Text = "Reset"
        Me.BtnReset.UseVisualStyleBackColor = True
        '
        'TxtTop
        '
        Me.TxtTop.Location = New System.Drawing.Point(320, 58)
        Me.TxtTop.Name = "TxtTop"
        Me.TxtTop.Size = New System.Drawing.Size(100, 20)
        Me.TxtTop.TabIndex = 5
        Me.TxtTop.Text = "20"
        '
        'TxtLeft
        '
        Me.TxtLeft.Location = New System.Drawing.Point(320, 95)
        Me.TxtLeft.Name = "TxtLeft"
        Me.TxtLeft.Size = New System.Drawing.Size(100, 20)
        Me.TxtLeft.TabIndex = 38
        Me.TxtLeft.Text = "30"
        '
        'TxtHeight
        '
        Me.TxtHeight.Location = New System.Drawing.Point(320, 166)
        Me.TxtHeight.Name = "TxtHeight"
        Me.TxtHeight.Size = New System.Drawing.Size(100, 20)
        Me.TxtHeight.TabIndex = 39
        Me.TxtHeight.Text = "80"
        '
        'TxtWidth
        '
        Me.TxtWidth.Location = New System.Drawing.Point(320, 137)
        Me.TxtWidth.Name = "TxtWidth"
        Me.TxtWidth.Size = New System.Drawing.Size(100, 20)
        Me.TxtWidth.TabIndex = 1
        Me.TxtWidth.Text = "90"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(278, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 16)
        Me.Label2.TabIndex = 42
        Me.Label2.Text = "Top"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(278, 96)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(33, 16)
        Me.Label3.TabIndex = 43
        Me.Label3.Text = "Left"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(267, 137)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 16)
        Me.Label4.TabIndex = 44
        Me.Label4.Text = "Width"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(261, 166)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 16)
        Me.Label5.TabIndex = 45
        Me.Label5.Text = "Height"
        '
        'BtnSection
        '
        Me.BtnSection.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSection.Location = New System.Drawing.Point(436, 32)
        Me.BtnSection.Name = "BtnSection"
        Me.BtnSection.Size = New System.Drawing.Size(95, 23)
        Me.BtnSection.TabIndex = 47
        Me.BtnSection.Text = "Section"
        Me.BtnSection.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(756, 32)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(140, 13)
        Me.Label6.TabIndex = 48
        Me.Label6.Text = "(Click to load a picture)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(288, 32)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(86, 13)
        Me.Label7.TabIndex = 49
        Me.Label7.Text = "(Section Size)"
        '
        'picResult
        '
        Me.picResult.Location = New System.Drawing.Point(436, 60)
        Me.picResult.Name = "picResult"
        Me.picResult.Size = New System.Drawing.Size(126, 125)
        Me.picResult.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picResult.TabIndex = 46
        Me.picResult.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(37, 60)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(126, 125)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'FrmPicture
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(927, 586)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.BtnSection)
        Me.Controls.Add(Me.picResult)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TxtWidth)
        Me.Controls.Add(Me.TxtHeight)
        Me.Controls.Add(Me.TxtLeft)
        Me.Controls.Add(Me.TxtTop)
        Me.Controls.Add(Me.BtnReset)
        Me.Controls.Add(Me.BtnSmall)
        Me.Controls.Add(Me.BtnLarge)
        Me.Controls.Add(Me.LblCode)
        Me.Controls.Add(Me.RText)
        Me.Controls.Add(Me.BtnLeft)
        Me.Controls.Add(Me.BtnRight)
        Me.Controls.Add(Me.BtnDown)
        Me.Controls.Add(Me.BtnUp)
        Me.Controls.Add(Me.LblPicture)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "FrmPicture"
        Me.Text = "FrmPicture"
        CType(Me.picResult, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents LblPicture As Label
    Friend WithEvents BtnUp As Button
    Friend WithEvents BtnDown As Button
    Friend WithEvents BtnRight As Button
    Friend WithEvents BtnLeft As Button
    Friend WithEvents LblCode As Label
    Friend WithEvents RText As RichTextBox
    Friend WithEvents BtnLarge As Button
    Friend WithEvents BtnSmall As Button
    Friend WithEvents BtnReset As Button
    Friend WithEvents TxtTop As TextBox
    Friend WithEvents TxtLeft As TextBox
    Friend WithEvents TxtHeight As TextBox
    Friend WithEvents TxtWidth As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents picResult As PictureBox
    Friend WithEvents BtnSection As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
End Class

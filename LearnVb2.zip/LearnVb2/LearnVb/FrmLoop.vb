﻿Public Class FrmLoop
    Dim sMsg As String
    Private Sub BtnFor_Click(sender As Object, e As EventArgs) Handles BtnFor.Click
        Dim iCnt As Integer
        Dim i As Integer
        iCnt = 0
        ListBox1.Items.Clear()
        For i = 0 To 8
            iCnt += 1
            ListBox1.Items.Add("Icnt= " & iCnt & "   I= " & i)
        Next
        sMsg = "'For i = 0 To 8"
        RText.Text = sMsg & vbCrLf & "Dim iCnt As Integer  " & vbCrLf & "Dim i As Integer" & vbCrLf
        RText.Text = RText.Text & "iCnt = 0" & vbCrLf & "ListBox1.Items.Clear()" & vbCrLf
        RText.Text = RText.Text & "For i = 0 To 8 " & vbCrLf & "  iCnt += 1" & vbCrLf
        RText.Text = RText.Text & "  ListBox1.Items.Add(" & Chr(34) & "Icnt=" & Chr(34) & " & iCnt & "
        RText.Text = RText.Text & "   I= " & Chr(34) & " & i)"
        RText.Text = RText.Text & vbCrLf & "Next"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnStep2_Click(sender As Object, e As EventArgs) Handles BtnStep2.Click
        Dim iCnt As Integer
        Dim i As Integer
        iCnt = 0
        ListBox1.Items.Clear()
        For i = 0 To 8 Step 2
            iCnt += 1
            ListBox1.Items.Add("Icnt= " & iCnt & "   I= " & i)
        Next
        sMsg = "'For i = 0 To 8 Step 2"
        RText.Text = sMsg & vbCrLf & "Dim iCnt As Integer  " & vbCrLf & "Dim i As Integer" & vbCrLf
        RText.Text = RText.Text & "iCnt = 0" & vbCrLf & "ListBox1.Items.Clear()" & vbCrLf
        RText.Text = RText.Text & "For i = 0 To 8 Step 2" & vbCrLf & "  iCnt += 1" & vbCrLf
        RText.Text = RText.Text & "  ListBox1.Items.Add(" & Chr(34) & "Icnt=" & Chr(34) & " & iCnt & "
        RText.Text = RText.Text & "   I= " & Chr(34) & " & i)"
        RText.Text = RText.Text & vbCrLf & "Next"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnStep4_Click(sender As Object, e As EventArgs) Handles BtnStep4.Click
        Dim iCnt As Integer
        Dim i As Integer
        iCnt = 0
        ListBox1.Items.Clear()
        For i = 0 To 8 Step 4
            iCnt += 1
            ListBox1.Items.Add("Icnt= " & iCnt & "   I= " & i)
        Next
        sMsg = "'For i = 0 To 8 Step 4"
        RText.Text = sMsg & vbCrLf & "Dim iCnt As Integer  " & vbCrLf & "Dim i As Integer" & vbCrLf
        RText.Text = RText.Text & "iCnt = 0" & vbCrLf & "ListBox1.Items.Clear()" & vbCrLf
        RText.Text = RText.Text & "For i = 0 To 8 Step 4" & vbCrLf & "  iCnt += 1" & vbCrLf
        RText.Text = RText.Text & "  ListBox1.Items.Add(" & Chr(34) & "Icnt=" & Chr(34) & " & iCnt & "
        RText.Text = RText.Text & "   I= " & Chr(34) & " & i)"
        RText.Text = RText.Text & vbCrLf & "Next"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnStep8_Click(sender As Object, e As EventArgs) Handles BtnStep8.Click
        Dim iCnt As Integer
        Dim i As Integer
        iCnt = 0
        ListBox1.Items.Clear()
        For i = 0 To 8 Step 8
            iCnt += 1
            ListBox1.Items.Add("Icnt= " & iCnt & "   I= " & i)
        Next
        sMsg = "'For i = 0 To 8 Step 8"
        RText.Text = sMsg & vbCrLf & "Dim iCnt As Integer  " & vbCrLf & "Dim i As Integer" & vbCrLf
        RText.Text = RText.Text & "iCnt = 0" & vbCrLf & "ListBox1.Items.Clear()" & vbCrLf
        RText.Text = RText.Text & "For i = 0 To 8 Step 8" & vbCrLf & "  iCnt += 1" & vbCrLf
        RText.Text = RText.Text & "  ListBox1.Items.Add(" & Chr(34) & "Icnt=" & Chr(34) & " & iCnt & "
        RText.Text = RText.Text & "   I= " & Chr(34) & " & i)"
        RText.Text = RText.Text & vbCrLf & "Next"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnLabel_Click(sender As Object, e As EventArgs) Handles BtnLabel.Click
        Dim cControl As Control
        ListBox1.Items.Clear()
        For Each cControl In Me.Controls
            If (TypeOf cControl Is Label) Then
                ListBox1.Items.Add(cControl.Text)
            End If
        Next cControl
        sMsg = "'Loop through four Labels (include Loop and Code)"
        RText.Text = sMsg & vbCrLf & "Dim cControl As Control  " & vbCrLf
        RText.Text = RText.Text & "ListBox1.Items.Clear()" & vbCrLf
        RText.Text = RText.Text & "For Each cControl In Me.Controls" & vbCrLf & "    If (TypeOf cControl Is label) Then" & vbCrLf
        RText.Text = RText.Text & "       ListBox1.Items.Add(cControl.Text)" & vbCrLf & "    End If" & vbCrLf
        RText.Text = RText.Text & "Next cControl"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnTxt_Click(sender As Object, e As EventArgs) Handles BtnTxt.Click
        Dim cControl As Control
        ListBox1.Items.Clear()
        For Each cControl In Me.Controls
            If (TypeOf cControl Is TextBox) Then
                ListBox1.Items.Add(cControl.Text)
            End If
        Next cControl
        sMsg = "'Loop through two TextBox"
        RText.Text = sMsg & vbCrLf & "Dim cControl As Control  " & vbCrLf
        RText.Text = RText.Text & "ListBox1.Items.Clear()" & vbCrLf
        RText.Text = RText.Text & "For Each cControl In Me.Controls" & vbCrLf & "    If (TypeOf cControl Is TextBox) Then" & vbCrLf
        RText.Text = RText.Text & "       ListBox1.Items.Add(cControl.Text)" & vbCrLf & "    End If" & vbCrLf
        RText.Text = RText.Text & "Next cControl"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
End Class
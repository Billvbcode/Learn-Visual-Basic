﻿Public Class FrmShell
    Dim sFileName As String
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim smsg As String
        smsg = "' Use the notepad program to open this text file."
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Shell("notepad " & value & "test.txt", AppWinStyle.NormalFocus)
        sFileName = "shell.txt"
        rFile()
        RText.Text = smsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(smsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub FrmShell_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
﻿Public Class FrmDraw
    Dim sMsg As String
    Dim sMsg2 As String
    Dim sMsg3 As String
    Dim sCar(200, 6) As String ' Array for a Car
    Dim sFileName As String
    Dim i As Integer
    Dim rect As Rectangle


    Dim icnt As Integer
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub FrmDraw_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        icnt = 0
    End Sub

    Private Sub BtnHLine_Click(sender As Object, e As EventArgs) Handles BtnHLine.Click
        Dim g As Graphics = Me.CreateGraphics
        sMsg = "'Horizontal Line   Vary X  20 to 150"
        sMsg2 = "' Create pen (Color, Width)   "
        sMsg3 = "'  DrawLine (X1 , Y1 , X2 , Y2)   "

        ' Create pen (Color, Width)
        Dim blackPen As New Pen(Color.Black, 3)
        ' DrawLine (X1 , Y1 , X2 , Y2)
        g.DrawLine(blackPen, 20, 96, 150, 96) 'Horz
        RText.Text = "Dim g As Graphics = Me.CreateGraphics" & vbCrLf
        RText.Text = RText.Text & sMsg2 & vbCrLf
        RText.Text = RText.Text & "Dim blackPen As New Pen(Color.Black, 3)" & vbCrLf
        RText.Text = RText.Text & sMsg3 & vbCrLf
        RText.Text = RText.Text & "g.DrawLine(blackPen, 20, 96, 150, 96) 'Horz"

        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg2)
        RText.Select(i, Len(sMsg2))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg3)
        RText.Select(i, Len(sMsg3))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnVLine_Click(sender As Object, e As EventArgs) Handles BtnVLine.Click
        Dim g As Graphics = Me.CreateGraphics

        sMsg = "'Verticle Line   Vary Y   86 to 186"
        sMsg2 = "' Create pen (Color, Width)   "
        sMsg3 = "'  DrawLine (X1 , Y1 , X2 , Y2)  "
        ' Create pen (Color, Width)
        Dim blackPen As New Pen(Color.Aqua, 3)
        ' DrawLine (X1 , Y1 , X2 , Y2)
        g.DrawLine(blackPen, 220, 86, 220, 186) 'Vert
        RText.Text = "Dim g As Graphics = Me.CreateGraphics" & vbCrLf
        RText.Text = RText.Text & sMsg2 & vbCrLf
        RText.Text = RText.Text & "Dim blackPen As New Pen(Color.Aqua, 3)" & vbCrLf
        RText.Text = RText.Text & sMsg3 & vbCrLf
        RText.Text = RText.Text & "g.DrawLine(blackPen,  220, 86, 220, 186) 'Vert"

        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg2)
        RText.Select(i, Len(sMsg2))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg3)
        RText.Select(i, Len(sMsg3))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnRectangle_Click(sender As Object, e As EventArgs) Handles BtnRectangle.Click
        sMsg = "'Rectangle"
        sMsg2 = "' Create pen (Color, Width)   "
        sMsg3 = "'  DrawRectangle(myPen, X, Y, width, height)   "
        Dim g As Graphics = Me.CreateGraphics
        ' Create pen (Color, Width)
        Dim blackPen As New Pen(Color.Red, 3)
        ' DrawRectangle(myPen, X, Y, width, height) 
        g.DrawRectangle(blackPen, 290, 86, 100, 100) 'Rectangle
        RText.Text = "Dim g As Graphics = Me.CreateGraphics" & vbCrLf
        RText.Text = RText.Text & sMsg2 & vbCrLf
        RText.Text = RText.Text & "Dim blackPen As New Pen(Color.Red, 3)" & vbCrLf
        RText.Text = RText.Text & sMsg3 & vbCrLf
        RText.Text = RText.Text & " g.DrawRectangle(blackPen, 290, 86, 100, 100) 'Rectangle"

        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg2)
        RText.Select(i, Len(sMsg2))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg3)
        RText.Select(i, Len(sMsg3))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim g As Graphics = Me.CreateGraphics
        '  Dim g4 As Graphics = Me.CreateGraphics
        ' Dim rect As Rectangle
        icnt = 4
        sMsg = "'Rectangle With Fill"
        sMsg2 = "' Create pen (Color, Width)   "
        sMsg3 = "'  DrawRectangle(myPen, X, Y, width, height)   "
        ' Create pen (Color, Width)
        Dim redPen As New Pen(Color.Red, 3)
        ' DrawRectangle(myPen, X, Y, width, height) 
        rect = New Rectangle(450, 86, 100, 100) 'Rectangle
        g.DrawRectangle(redPen, rect) 'Fill Rectangle
        g.FillRectangle(Brushes.LightGreen, rect)
        RText.Text = "Dim g As Graphics = Me.CreateGraphics" & vbCrLf
        RText.Text = RText.Text & "Dim rect As Rectangle" & vbCrLf
        RText.Text = RText.Text & sMsg2 & vbCrLf
        RText.Text = RText.Text & "Dim redPen As New Pen(Color.Red, 3)" & vbCrLf
        RText.Text = RText.Text & "rect = New Rectangle(450, 86, 100, 100) 'Rectangle" & vbCrLf
        RText.Text = RText.Text & sMsg3 & vbCrLf
        RText.Text = RText.Text & "g.DrawRectangle(redPen, rect) 'Rectangle " & vbCrLf
        RText.Text = RText.Text & "g.FillRectangle(Brushes.LightGreen, rect) 'Fill Rectangle"
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg2)
        RText.Select(i, Len(sMsg2))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg3)
        RText.Select(i, Len(sMsg3))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnCircle_Click(sender As Object, e As EventArgs) Handles BtnCircle.Click
        Dim g As Graphics = Me.CreateGraphics

        sMsg = "'Circle"
        sMsg2 = "' Create pen (Color, Width)   "
        sMsg3 = "'  DrawEllipse(myPen, X, Y, width, height)   "

        ' Create pen (Color, Width)
        Dim blackPen As New Pen(Color.Orange, 3)
        ' DrawRectangle(myPen, X, Y, width, height) 
        g.DrawEllipse(blackPen, 580, 86, 100, 100) 'Circle
        RText.Text = "Dim g As Graphics = Me.CreateGraphics" & vbCrLf
        RText.Text = RText.Text & sMsg2 & vbCrLf
        RText.Text = RText.Text & "Dim blackPen As New Pen(Color.Red, 3)" & vbCrLf
        RText.Text = RText.Text & sMsg3 & vbCrLf
        RText.Text = RText.Text & "g.DrawEllipse(blackPen, 580, 86, 100, 100) 'Circle"

        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg2)
        RText.Select(i, Len(sMsg2))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg3)
        RText.Select(i, Len(sMsg3))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnFillC_Click(sender As Object, e As EventArgs) Handles BtnFillC.Click
        Dim g As Graphics = Me.CreateGraphics

        '   Dim rect As Rectangle
        sMsg = "'Circle With Fill"
        sMsg2 = "' Create pen (Color, Width)   "
        sMsg3 = "'  DrawEllipse(myPen, X, Y, width, height)    "

        ' Create pen (Color, Width)
        Dim redPen As New Pen(Color.Red, 3)
        ' DrawRectangle(myPen, X, Y, width, height) 
        rect = New Rectangle(700, 86, 100, 100) 'Rectangle
        g.DrawEllipse(redPen, rect) 'Fill Rectangle
        g.FillEllipse(Brushes.LightGreen, rect)
        RText.Text = "Dim g As Graphics = Me.CreateGraphics" & vbCrLf
        RText.Text = RText.Text & "Dim rect As Rectangle" & vbCrLf
        RText.Text = RText.Text & sMsg2 & vbCrLf
        RText.Text = RText.Text & "Dim redPen As New Pen(Color.Red, 3)" & vbCrLf
        RText.Text = RText.Text & "rect = New Rectangle(700, 86, 100, 100) 'Rectangle" & vbCrLf
        RText.Text = RText.Text & sMsg3 & vbCrLf
        RText.Text = RText.Text & "g.DrawEllipse(redPen, rect) 'Circle " & vbCrLf
        RText.Text = RText.Text & "g.FillEllipse(Brushes.LightGreen, rect) 'Fill Circle"
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg2)
        RText.Select(i, Len(sMsg2))
        RText.SelectionColor = Color.Green
        i = InStr(1, RText.Text, sMsg3)
        RText.Select(i, Len(sMsg3))
        RText.SelectionColor = Color.Green
    End Sub




End Class
﻿Public Class FrmTimer
    Dim sMsg As String
    Dim sMsg2 As String
    Dim sFileName As String
    Dim j As Integer
    Private Sub BtnTimerOn_Click(sender As Object, e As EventArgs) Handles BtnTimerOn.Click
        sFileName = "Timer.txt"
        rFile()
        Timer1.Start()  'Start Timer
        sMsg = "'Start Timer  Timer1.Start()    or  Timer1.Enabled = True "
        RText.Text = RText.Text & vbCrLf & sMsg & vbCrLf & "Timer1.Start()  "

        j = InStr(1, RText.Text, "'S")
        RText.Select(j - 1, Len(sMsg))
        RText.SelectionColor = Color.Green
        LblTimer.Text = "Timer - On"
        LblTimer.BackColor = Color.LightGreen
        LblCheck.Visible = False
    End Sub

    Private Sub BtnTimerOn2_Click(sender As Object, e As EventArgs) Handles BtnTimerOn2.Click
        sFileName = "Timer.txt"

        rFile()
        Timer1.Enabled = True  'Start Timer
        sMsg = "'Start Timer  Timer1.Start()    or  Timer1.Enabled = True "
        RText.Text = RText.Text & vbCrLf & sMsg & vbCrLf & "Timer1.Enabled = True   " ' & sMsg
        j = InStr(1, RText.Text, "'S")
        RText.Select(j - 1, Len(sMsg))
        RText.SelectionColor = Color.Green
        LblTimer.Text = "Timer - On"
        LblTimer.BackColor = Color.LightGreen
        LblCheck.Visible = False
    End Sub

    Private Sub BtnTimerOff_Click(sender As Object, e As EventArgs) Handles BtnTimerOff.Click
        Timer1.Stop()  'Stop Timer
        sMsg = "'Stop Timer  Timer1.Stop()    or  Timer1.Enabled = False "
        RText.Text = sMsg & vbCrLf & "Timer1.Stop()  " '& vbCrLf & sMsg
        RText.Select(1, Len(sMsg))
        RText.SelectionColor = Color.Green
        LblTimer.Text = "Timer - Off"
        LblTimer.BackColor = Color.Tomato
        LblCheck.Visible = False
    End Sub

    Private Sub BtnTimerOff2_Click(sender As Object, e As EventArgs) Handles BtnTimerOff2.Click
        Timer1.Enabled = False  'Stop Timer
        sMsg = "'Stop Timer  Timer1.Stop()    or  Timer1.Enabled = False "
        RText.Text = sMsg & vbCrLf & "Timer1.Enabled = False   " '& vbCrLf & sMsg
        RText.Select(1, Len(sMsg))
        RText.SelectionColor = Color.Green
        LblTimer.Text = "Timer - Off"
        LblTimer.BackColor = Color.Tomato
        LblCheck.Visible = False
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        PictureBox1.Left += 10
        If PictureBox1.Left > 750 Then PictureBox1.Left = 0
        'Look fo a hit
        If PictureBox1.Bounds.IntersectsWith(PictureBox2.Bounds) Then
            LblHit.BackColor = Color.LightGreen
        Else
            LblHit.BackColor = Color.Tomato
        End If

    End Sub



    Private Sub BtnFast_Click(sender As Object, e As EventArgs) Handles BtnFast.Click
        Dim i As Integer
        Timer1.Start()  'Start Timer
        Timer1.Interval = 100
        sMsg = "'Start Timer"
        sMsg2 = "'Fast"
        RText.Text = "Timer1.Start()  " & sMsg & vbCrLf & "Timer1.Interval = 100  "
        i = Len(RText.Text)
        RText.Text = "Timer1.Start()  " & sMsg & vbCrLf & "Timer1.Interval = 100  " & sMsg2
        RText.Select(16, Len(sMsg))
        RText.SelectionColor = Color.Green
        RText.Select(i, Len(sMsg2))
        RText.SelectionColor = Color.Green
        LblTimer.Text = "Timer - On"
        LblTimer.BackColor = Color.LightGreen
        LblCheck.Visible = False
    End Sub
    Private Sub BtnSlow_Click(sender As Object, e As EventArgs) Handles BtnSlow.Click
        Dim i As Integer
        Timer1.Start()  'Start Timer
        Timer1.Interval = 400
        sMsg = "'Start Timer"
        sMsg2 = "'Slow"
        RText.Text = "Timer1.Start()  " & sMsg & vbCrLf & "Timer1.Interval = 400  "
        i = Len(RText.Text)
        RText.Text = "Timer1.Start()  " & sMsg & vbCrLf & "Timer1.Interval = 400  " & sMsg2
        RText.Select(16, Len(sMsg))
        RText.SelectionColor = Color.Green
        RText.Select(i, Len(sMsg2))
        RText.SelectionColor = Color.Green
        LblTimer.Text = "Timer - On"
        LblTimer.BackColor = Color.LightGreen
        LblCheck.Visible = False
    End Sub
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub FrmTimer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LblTimer.Text = "Timer - Off"
        LblTimer.BackColor = Color.Tomato
        LblCheck.Visible = False
    End Sub

    Private Sub CheckTimer_Click(sender As Object, e As EventArgs) Handles CheckTimer.Click
        'If Timer1.Enabled Then the timer is running
        sMsg = "'Timer1.Enabled = True (Timmer running)" & vbCrLf _
         & "'Timer1.Enabled = False (Timmer Stopped)"
        If Timer1.Enabled Then
            LblCheck.Text = "Timer - On"
            LblCheck.BackColor = Color.LightGreen
        Else
            LblCheck.Text = "Timer - Off"
            LblCheck.BackColor = Color.Tomato
        End If
        LblCheck.Visible = True
        RText.Text = sMsg & vbCrLf & "If Timer1.Enabled Then " & vbCrLf & "   LblCheck.Text = " & Chr(34) & "Timer - On  " & Chr(34)
        RText.Text = RText.Text & vbCrLf & "   LblCheck.BackColor = Color.LightGreen  " & vbCrLf
        RText.Text = RText.Text & "Else " & vbCrLf & "   LblCheck.Text = " & Chr(34) & "Timer - Off  " & Chr(34)
        RText.Text = RText.Text & vbCrLf & "   LblCheck.BackColor = Color.Tomato  " & vbCrLf
        RText.Text = RText.Text & "End If "
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub RText_TextChanged(sender As Object, e As EventArgs) Handles RText.TextChanged

    End Sub

    Private Sub FrmTimer_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Timer1.Stop()
    End Sub
End Class
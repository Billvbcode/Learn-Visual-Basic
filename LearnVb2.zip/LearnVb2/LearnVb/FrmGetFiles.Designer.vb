﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmGetFiles
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LblCode = New System.Windows.Forms.Label()
        Me.RText = New System.Windows.Forms.RichTextBox()
        Me.BtnGet = New System.Windows.Forms.Button()
        Me.BtnRead = New System.Windows.Forms.Button()
        Me.BtnLine = New System.Windows.Forms.Button()
        Me.BtnWrite = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.LblName = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'LblCode
        '
        Me.LblCode.AutoSize = True
        Me.LblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCode.Location = New System.Drawing.Point(8, 11)
        Me.LblCode.Name = "LblCode"
        Me.LblCode.Size = New System.Drawing.Size(56, 20)
        Me.LblCode.TabIndex = 39
        Me.LblCode.Text = " Code"
        '
        'RText
        '
        Me.RText.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RText.Location = New System.Drawing.Point(12, 78)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(682, 444)
        Me.RText.TabIndex = 38
        Me.RText.Text = ""
        '
        'BtnGet
        '
        Me.BtnGet.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnGet.Location = New System.Drawing.Point(171, 11)
        Me.BtnGet.Name = "BtnGet"
        Me.BtnGet.Size = New System.Drawing.Size(89, 34)
        Me.BtnGet.TabIndex = 40
        Me.BtnGet.Text = "GetFiles"
        Me.BtnGet.UseVisualStyleBackColor = True
        '
        'BtnRead
        '
        Me.BtnRead.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRead.Location = New System.Drawing.Point(277, 11)
        Me.BtnRead.Name = "BtnRead"
        Me.BtnRead.Size = New System.Drawing.Size(89, 34)
        Me.BtnRead.TabIndex = 41
        Me.BtnRead.Text = "ReadFiles"
        Me.BtnRead.UseVisualStyleBackColor = True
        '
        'BtnLine
        '
        Me.BtnLine.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLine.Location = New System.Drawing.Point(372, 9)
        Me.BtnLine.Name = "BtnLine"
        Me.BtnLine.Size = New System.Drawing.Size(117, 34)
        Me.BtnLine.TabIndex = 42
        Me.BtnLine.Text = "ReadbyLine"
        Me.BtnLine.UseVisualStyleBackColor = True
        '
        'BtnWrite
        '
        Me.BtnWrite.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnWrite.Location = New System.Drawing.Point(504, 9)
        Me.BtnWrite.Name = "BtnWrite"
        Me.BtnWrite.Size = New System.Drawing.Size(117, 34)
        Me.BtnWrite.TabIndex = 43
        Me.BtnWrite.Text = "WriteFile"
        Me.BtnWrite.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(627, 9)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(117, 34)
        Me.Button2.TabIndex = 44
        Me.Button2.Text = "CheckDir"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'LblName
        '
        Me.LblName.AutoSize = True
        Me.LblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblName.Location = New System.Drawing.Point(8, 42)
        Me.LblName.Name = "LblName"
        Me.LblName.Size = New System.Drawing.Size(0, 20)
        Me.LblName.TabIndex = 45
        '
        'FrmGetFiles
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(754, 534)
        Me.Controls.Add(Me.LblName)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.BtnWrite)
        Me.Controls.Add(Me.BtnLine)
        Me.Controls.Add(Me.BtnRead)
        Me.Controls.Add(Me.BtnGet)
        Me.Controls.Add(Me.LblCode)
        Me.Controls.Add(Me.RText)
        Me.Name = "FrmGetFiles"
        Me.Text = "FrmGetFiles"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LblCode As Label
    Friend WithEvents RText As RichTextBox
    Friend WithEvents BtnGet As Button
    Friend WithEvents BtnRead As Button
    Friend WithEvents BtnLine As Button
    Friend WithEvents BtnWrite As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents LblName As Label
End Class

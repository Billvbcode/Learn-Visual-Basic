﻿Public Class FrmSelect
    Private Sub BtnHide_Click(sender As Object, e As EventArgs) Handles BtnHide.Click
        sForm = "?"
        Me.Hide()
    End Sub

    Private Sub FrmSelect_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label4.Text = "ShowDialog()  Can Only use this form"
        If sForm = "show" Then Label4.Text = "Show()  Can switch between forms"
        Label1.Text = "Can NOT click on any button on the main form"
        If sForm = "show" Then Label1.Text = "Can click on any button on the main form"
        Dim sMsg As String
        RText.Text = "Me.Hide  "
        sMsg = "'Hide Form"
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
End Class
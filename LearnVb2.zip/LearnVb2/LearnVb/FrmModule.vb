﻿Public Class FrmModule
    Dim sFileName As String
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub FrmModule_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sMsg As String
        Label1.Text = "A module is used to store variables, subroutines or functions that " & vbCrLf & "can be used by EVERY form in your project."
        sFileName = "Module.txt"
        rFile()
        sMsg = "Note: use PUBLIC instead of DIM or PRIVATE" & vbCrLf
        Dim value As String = My.Application.Info.DirectoryPath & "\screen\"
        PictureBox1.Image = Image.FromFile(value & "AddModule.jpg")
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        RText.Enabled = False
        Timer1.Start()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        RText.Enabled = True
        Timer1.Stop()
    End Sub
End Class
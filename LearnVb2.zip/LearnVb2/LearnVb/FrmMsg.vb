﻿Public Class FrmMsg
    Dim sMsg As String
    Dim sFileName As String
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub FrmMsg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox1.Items.Clear()
        ListBox1.Items.Add("MsgBoxStyle.OkOnly  ")
        ListBox1.Items.Add("MsgBoxStyle.YesNo ")
        ListBox1.Items.Add("MsgBoxStyle.YesNoCancel ")
        ListBox1.Items.Add("MsgBoxStyle.Question  ")
        ListBox1.Items.Add("MsgBoxStyle.Exclamation  ")
        ListBox1.Items.Add("InputBox( Prompt,   Title ,  Default )	")
    End Sub

    Private Sub ListBox1_Click(sender As Object, e As EventArgs) Handles ListBox1.Click
        LblResult.Text = ""
        Dim result As DialogResult
        If Mid(ListBox1.Text, 13, 2) = "Ok" Then
            RText.Text = "MsgBox(TxtPrompt.Text, MsgBoxStyle.OkOnly, TxtTitle.Text)"
            sMsg = "'MsgBox(Prompt,Button OkOnly, Title)"
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            MsgBox(TxtPrompt.Text, MsgBoxStyle.OkOnly, TxtTitle.Text)
        End If
        If Mid(ListBox1.Text, 13, 6) = "YesNoC" Then
            sFileName = "YesNoCancel.txt"
            rFile()
            sMsg = "'MsgBox(Prompt,Button YesNoCancel, Title)"
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            result = MsgBox(TxtPrompt.Text, MsgBoxStyle.YesNoCancel, TxtTitle.Text)
            If result = DialogResult.Cancel Then
                LblResult.Text = "Cancel pressed"
            ElseIf result = DialogResult.No Then
                LblResult.Text = "No pressed"
            ElseIf result = DialogResult.Yes Then
                LblResult.Text = "Yes pressed"
            End If
            Exit Sub
        End If
        If Mid(ListBox1.Text, 13, 2) = "Ye" Then
            sFileName = "YesNo.txt"
            rFile()
            sMsg = "'MsgBox(Prompt,Button YesNo, Title)"
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            result = MsgBox(TxtPrompt.Text, MsgBoxStyle.YesNo, TxtTitle.Text)
            If result = DialogResult.No Then
                LblResult.Text = "No pressed"
            ElseIf result = DialogResult.Yes Then
                LblResult.Text = "Yes pressed"
            End If
        End If
        If Mid(ListBox1.Text, 13, 2) = "Qu" Then
            RText.Text = "MsgBox(TxtPrompt.Text, MsgBoxStyle.Question, TxtTitle.Text)"
            sMsg = "'MsgBox(Prompt,Button Question, Title)"
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            MsgBox(TxtPrompt.Text, MsgBoxStyle.Question, TxtTitle.Text)
        End If
        If Mid(ListBox1.Text, 13, 2) = "Ex" Then
            RText.Text = "MsgBox(TxtPrompt.Text, MsgBoxStyle.Exclamation, TxtTitle.Text)"
            sMsg = "'MsgBox(Prompt,Button .Exclamation, Title)"
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            MsgBox(TxtPrompt.Text, MsgBoxStyle.Exclamation, TxtTitle.Text)
        End If
        If Mid(ListBox1.Text, 1, 2) = "In" Then
            RText.Text = "LblResult.Text = InputBox(TxtPrompt.Text, TxtTitle.Text, TxtDefault.Text)"
            sMsg = "'InputBox( Prompt,   Title ,  Default )"
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            LblResult.Text = InputBox(TxtPrompt.Text, TxtTitle.Text, TxtDefault.Text)
        End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub
End Class
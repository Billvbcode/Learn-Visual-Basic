﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmFile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.DriveList = New System.Windows.Forms.ListBox()
        Me.FolderList = New System.Windows.Forms.ListBox()
        Me.FileList = New System.Windows.Forms.ListBox()
        Me.LblCode = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.LblSubFolders = New System.Windows.Forms.Label()
        Me.LblFile = New System.Windows.Forms.Label()
        Me.SubFolderList = New System.Windows.Forms.ListBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.RText = New System.Windows.Forms.RichTextBox()
        Me.SuspendLayout()
        '
        'DriveList
        '
        Me.DriveList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DriveList.FormattingEnabled = True
        Me.DriveList.ItemHeight = 16
        Me.DriveList.Location = New System.Drawing.Point(12, 73)
        Me.DriveList.Name = "DriveList"
        Me.DriveList.Size = New System.Drawing.Size(171, 260)
        Me.DriveList.TabIndex = 0
        '
        'FolderList
        '
        Me.FolderList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FolderList.FormattingEnabled = True
        Me.FolderList.ItemHeight = 16
        Me.FolderList.Location = New System.Drawing.Point(208, 73)
        Me.FolderList.Name = "FolderList"
        Me.FolderList.Size = New System.Drawing.Size(171, 260)
        Me.FolderList.TabIndex = 1
        '
        'FileList
        '
        Me.FileList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FileList.FormattingEnabled = True
        Me.FileList.ItemHeight = 16
        Me.FileList.Location = New System.Drawing.Point(599, 73)
        Me.FileList.Name = "FileList"
        Me.FileList.Size = New System.Drawing.Size(277, 260)
        Me.FileList.TabIndex = 2
        '
        'LblCode
        '
        Me.LblCode.AutoSize = True
        Me.LblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCode.Location = New System.Drawing.Point(12, 36)
        Me.LblCode.Name = "LblCode"
        Me.LblCode.Size = New System.Drawing.Size(59, 20)
        Me.LblCode.TabIndex = 35
        Me.LblCode.Text = "Drives"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(204, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 20)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "Folders"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(595, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 20)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "Files"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(672, 33)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 38
        Me.Button1.Text = "Back"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'LblSubFolders
        '
        Me.LblSubFolders.AutoSize = True
        Me.LblSubFolders.Location = New System.Drawing.Point(421, 346)
        Me.LblSubFolders.Name = "LblSubFolders"
        Me.LblSubFolders.Size = New System.Drawing.Size(39, 13)
        Me.LblSubFolders.TabIndex = 39
        Me.LblSubFolders.Text = "Label3"
        '
        'LblFile
        '
        Me.LblFile.AutoSize = True
        Me.LblFile.Location = New System.Drawing.Point(603, 346)
        Me.LblFile.Name = "LblFile"
        Me.LblFile.Size = New System.Drawing.Size(39, 13)
        Me.LblFile.TabIndex = 40
        Me.LblFile.Text = "Label4"
        '
        'SubFolderList
        '
        Me.SubFolderList.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SubFolderList.FormattingEnabled = True
        Me.SubFolderList.ItemHeight = 16
        Me.SubFolderList.Location = New System.Drawing.Point(413, 73)
        Me.SubFolderList.Name = "SubFolderList"
        Me.SubFolderList.Size = New System.Drawing.Size(171, 260)
        Me.SubFolderList.TabIndex = 41
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(420, 36)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(101, 20)
        Me.Label5.TabIndex = 42
        Me.Label5.Text = "SubFolders"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 365)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 20)
        Me.Label3.TabIndex = 44
        Me.Label3.Text = "Code"
        '
        'RText
        '
        Me.RText.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RText.Location = New System.Drawing.Point(12, 397)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(864, 313)
        Me.RText.TabIndex = 43
        Me.RText.Text = ""
        '
        'FrmFile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(922, 734)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.RText)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.SubFolderList)
        Me.Controls.Add(Me.LblFile)
        Me.Controls.Add(Me.LblSubFolders)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.LblCode)
        Me.Controls.Add(Me.FileList)
        Me.Controls.Add(Me.FolderList)
        Me.Controls.Add(Me.DriveList)
        Me.Name = "FrmFile"
        Me.Text = "FrmFile"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DriveList As ListBox
    Friend WithEvents FolderList As ListBox
    Friend WithEvents FileList As ListBox
    Friend WithEvents LblCode As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents LblSubFolders As Label
    Friend WithEvents LblFile As Label
    Friend WithEvents SubFolderList As ListBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents RText As RichTextBox
End Class

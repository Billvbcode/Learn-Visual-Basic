﻿Public Class FrmCreate
    Dim sMsg As String
    Dim sCar(200, 6) As String ' Array for a Car
    Dim sFileName As String
    Dim aList(20) As Label ' Array of labels
    Dim cList(20) As Label ' Array of labels
    Dim pPic(200) As PictureBox 'Array of PictureBoxes
    'Click Event
    Private Sub pPic_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim i As Integer
        i = Val(Mid(sender.name, 2, 3)) ' Picture Number
        cLblClick.Text = "Click  Name=" & sender.name & "   Tag=" & sender.tag & "   #=" & i
    End Sub
    'MouseMove Event 
    Private Sub pPic_MouseMove(sender As Object, e As System.Windows.Forms.MouseEventArgs)
        Dim i As Integer
        i = Val(Mid(sender.name, 2, 3)) ' Picture Number
        cLblMouseMove.Text = "Mouse  Name=" & sender.name & "   Tag=" & sender.tag & "   #=" & i
    End Sub
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub BtnAttach_Click(sender As Object, e As EventArgs) Handles BtnAttach.Click
        Dim i As Integer
        Label1.Visible = True
        Label2.Visible = True
        Label3.Visible = True
        Label4.Visible = True
        Label5.Visible = True
        Panel1.Visible = False
        ListBox1.Visible = True
        ListBox1.Items.Clear()
        ' View all the Labels in the list
        '  For i=1 To 
        For i = 1 To 5
            ListBox1.Items.Add(aList(i).Text)
        Next
        sFileName = "Attach.txt"
        rFile()
        sMsg = "'Attach predefined labels to an array"
        RText.Text = sMsg & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub FrmCreate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim i As Integer
        Dim j As Integer
        Dim Icnt As Integer
        Icnt = 1 ' Label counter
        For j = 1 To 3     ' Vertical
            For i = 1 To 3 ' Horizontal
                cList(Icnt) = New System.Windows.Forms.Label    'Label
                With cList(Icnt)
                    .Name = Icnt                                 'Label Name
                    .Location = New System.Drawing.Point(4 + (i - 1) * 32,
                                                         6 + (j - 1) * 32)
                    .Text = Icnt
                    .Font = New Font("Times New Roman", 12, FontStyle.Bold)
                    .AutoSize = True
                    .Tag = Chr(64 + Icnt)  'Tag=A,B,C ect
                End With
                Panel1.Controls.Add(cList(Icnt)) '  This is the create the label
                AddHandler cList(Icnt).Click, AddressOf cList_Click 'Click Event
                AddHandler cList(Icnt).MouseMove, AddressOf cList_MouseMove 'Mouse
                Icnt = Icnt + 1 ' Increase Label counter
            Next
        Next
        Panel1.Visible = False
        '
        Label1.Visible = True
        Label2.Visible = True
        Label3.Visible = True
        Label4.Visible = True
        Label5.Visible = True
        ListBox1.Visible = True
        aList(1) = Label1  'Attach Array(1) to Label1
        aList(2) = Label2  'Attach Array(2) to Label2
        aList(3) = Label3  'Attach Array(3) to Label3
        aList(4) = Label4  'Attach Array(4) to Label4
        aList(5) = Label5  'Attach Array(5) to Label5
        'Create ONE Click Event For all the labels
        For i = 1 To 5
            AddHandler aList(i).Click, AddressOf aList_Click 'Click Event
            AddHandler aList(i).MouseMove, AddressOf aList_MouseMove 'Mouse
            aList(i).Tag = Chr(64 + i)  'Tag=A,B,C ect
        Next
        '

        Icnt = 1 ' PictureBox counter
        For j = 1 To 3    ' Vertical
            For i = 1 To 3 ' Horizontal
                pPic(Icnt) = New System.Windows.Forms.PictureBox    'PictureBox
                With pPic(Icnt)
                    .Name = "P" & Format(Icnt, "000")                               'PictureBox Name
                    .Image = PictureBox1.Image
                    .Tag = Chr(64 + Icnt)  'Tag=A,B,C ect                       'G=Green Tag
                    .Size = New Size(22, 22)
                    .SizeMode = PictureBoxSizeMode.StretchImage
                    .Location = New System.Drawing.Point(4 + (i - 1) * 22,
                                                         6 + (j - 1) * 22)
                End With
                ' Me.Controls.Add(pPic(Icnt)) '  Add Picture to Form (commeted out)
                Panel1.Controls.Add(pPic(Icnt)) '  Add Picture to Panel1
                AddHandler pPic(Icnt).Click, AddressOf pPic_Click 'Click Event
                AddHandler pPic(Icnt).MouseMove, AddressOf pPic_MouseMove 'Mouse
                Icnt = Icnt + 1 ' Increase PictureBox counter
            Next
        Next
    End Sub
    Private Sub aList_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim i As Integer
        i = Val(sender.name) ' Location
        aLblClick.Text = "Click  Name=" & sender.name & "   Tag=" & sender.tag
    End Sub


    Private Sub aList_MouseMove(sender As Object, e As System.Windows.Forms.MouseEventArgs)
        aLblMouseMove.Text = "Mousemove  Name=" & sender.name & "   Tag=" & sender.tag
    End Sub
    Private Sub BtnCreate_Click(sender As Object, e As EventArgs) Handles BtnCreate.Click
        Dim i As Integer
        For i = 1 To 9
            cList(i).Visible = True
            pPic(i).Visible = False
        Next
        Panel1.Visible = True
        Label1.Visible = False
        Label2.Visible = False
        Label3.Visible = False
        Label4.Visible = False
        Label5.Visible = False
        ListBox1.Visible = False
        cLblClick.Text = "Click"
        'Panel1.Left = 570
        'LblMouseMove.Text = "Mousemove"
        'Dim i As Integer
        'Dim j As Integer
        'Dim Icnt As Integer
        'Icnt = 1 ' Label counter
        'ListBox1.Items.Clear()
        'For j = 1 To 3     ' Vertical
        '    For i = 1 To 3 ' Horizontal
        '        cList(Icnt) = New System.Windows.Forms.Label    'Label
        '        With cList(Icnt)
        '            .Name = Icnt                                 'Label Name
        '            .Location = New System.Drawing.Point(4 + (i - 1) * 32,
        '                                                 6 + (j - 1) * 32)
        '            .Text = Icnt
        '            .Font = New Font("Times New Roman", 12, FontStyle.Bold)
        '            .AutoSize = True
        '            .Tag = Chr(64 + Icnt)  'Tag=A,B,C ect
        '        End With
        '        Panel1.Controls.Add(cList(Icnt)) '  This is the create the label
        '        ListBox1.Items.Add(cList(Icnt).Top & " " & cList(Icnt).Left)
        '        AddHandler cList(Icnt).Click, AddressOf cList_Click 'Click Event
        '        AddHandler cList(Icnt).MouseMove, AddressOf cList_MouseMove 'Mouse
        '        Icnt = Icnt + 1 ' Increase Label counter
        '    Next
        'Next
        sFileName = "Create.txt"
        rFile()
        sMsg = "'Create an array of labels"
        RText.Text = sMsg & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub cList_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim i As Integer
        i = Val(sender.name) ' Location
        cLblClick.Text = "Click  Name=" & sender.name & "   Tag=" & sender.tag
    End Sub


    Private Sub cList_MouseMove(sender As Object, e As System.Windows.Forms.MouseEventArgs)
        cLblMouseMove.Text = "Mousemove  Name=" & sender.name & "   Tag=" & sender.tag
    End Sub

    Private Sub BtnView_Click(sender As Object, e As EventArgs) Handles BtnView.Click
        Panel1.Visible = True
        Label1.Visible = False
        Label2.Visible = False
        Label3.Visible = False
        Label4.Visible = False
        Label5.Visible = False
        ListBox1.Visible = True
        'Panel1.Left = 470
        Dim i As Integer
        For i = 1 To 9
            cList(i).Visible = True
            pPic(i).Visible = False
        Next
        ListBox1.Items.Clear()
        For i = 1 To 9
            ListBox1.Items.Add(cList(i).Name _
                & " " & cList(i).Tag)
        Next
        sFileName = "view.txt"
        rFile()
        sMsg = "'View the created array of labels"
        RText.Text = sMsg & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnPicture_Click(sender As Object, e As EventArgs) Handles BtnPicture.Click
        Dim i As Integer
        For i = 1 To 9
            cList(i).Visible = False
            pPic(i).Visible = True
        Next
        Panel1.Visible = True
        Label1.Visible = False
        Label2.Visible = False
        Label3.Visible = False
        Label4.Visible = False
        Label5.Visible = False
        ListBox1.Visible = False
        sFileName = "picture.txt"
        rFile()
        sMsg = "'Create an array of pictureboxes"
        RText.Text = sMsg & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
End Class
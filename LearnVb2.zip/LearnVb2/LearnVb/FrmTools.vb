﻿Public Class FrmTools
    Dim sMsg As String
    Dim sMsgR As String
    Dim sMsgC As String
    Private Sub FrmTools_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox2.Items.Clear()
        ListBox2.Items.Add("Button1 ")
        ListBox2.Items.Add("Label1 ")
        ListBox2.Items.Add("Panel1 ")
        ListBox2.Items.Add("RadioButton1")
        ListBox2.Items.Add("CheckBox1")
        ListBox2.Items.Add("HScrollBar1")
        ListBox2.Items.Add("Picture1 ")
        ListBox2.Items.Add("TextBox1 ")
        LblTool.Text = "Button"
        LblTool1.Text = "Button1"
        ListTag()
        ' Button1.BackgroundImage = Nothing
        sMsgR = "Radio button allows only one option to be selected."
        sMsgC = "Check box allows one or many options to be selected. "
    End Sub
    Private Sub ToolList()
        Label6.Visible = False
        TxtText.Visible = False
        LblCheck.Visible = False
        TxtValue.Visible = False
        ListBox1.Items.Clear()
        If LblTool.Text <> "Picture" And LblTool.Text <> "HScrollBar" And LblTool.Text <> "Button" Then
            ListBox1.Items.Add("BackColor (Cyan)   Background color")
            ListBox1.Items.Add("BackColor (Yellow) Background color")
        End If
        If LblTool.Text = "Button" And bBtnImage = False Then
            ListBox1.Items.Add("BackColor (Cyan)   Background color")
            ListBox1.Items.Add("BackColor (Yellow) Background color")
        End If
        'If LblTool.Text <> "Picture" And LblTool.Text <> "HScrollBar" And LblTool.Text <> "Button" Then
        '    ListBox1.Items.Add("BackColor (Cyan)   Background color")
        '    ListBox1.Items.Add("BackColor (Yellow) Background color")
        'End If
        ListBox1.Items.Add("Enabled            True Can use")
        ListBox1.Items.Add("Enabled            False Not able use")
        ListBox1.Items.Add("Tag                Invisible Tool Text")
        If LblTool.Text = "Button" Or LblTool.Text = "Label" _
            Or LblTool.Text = "Text" Or LblTool.Text = "RadioButton" Or LblTool.Text = "CheckBox" Then
            ListBox1.Items.Add("ForeColor (Red)	Text color  ")
            ListBox1.Items.Add("ForeColor (Green) Text color  ")
            ListBox1.Items.Add("Text              Visible Tool Text  ")
            Label6.Visible = True
            TxtText.Visible = True
        End If
        If LblTool.Text = "Button" Then
            ListBox1.Items.Add("BackGroundImage = BtnImage.Image")
            ListBox1.Items.Add("BackGroundImage = Nothing")
        End If
        If LblTool.Text = "Label" Or LblTool.Text = "Panel" Then
            ListBox1.Items.Add("BorderStyle  (None)  ") 'Fixed3D
            ListBox1.Items.Add("BorderStyle  (Fixed3D)  ")
            Label6.Visible = True
            TxtText.Visible = True
        End If
        If LblTool.Text = "RadioButton" Or LblTool.Text = "CheckBox" Then
            ListBox1.Items.Add("Checked True")
            ListBox1.Items.Add("Checked False  ")
            '      ListBox1.Items.Add("Text    Visible Tool Text  ")
            LblCheck.Visible = True
            TxtValue.Visible = True
            If LblTool.Text = "RadioButton" Then
                TxtValue.Text = RadioButton1.Checked
                '  ListBox3.Items.Add("Checked   " & RadioButton1.Checked)
            End If
            If LblTool.Text = "CheckBox" Then
                TxtValue.Text = CheckBox1.Checked
                '  ListBox3.Items.Add("Checked   " & CheckBox1.Checked)
            End If
        End If
        ListBox1.Items.Add("Visible  True  Tool Visible")
        ListBox1.Items.Add("Visible  False Tool Not Visible")
        If LblTool.Text = "HScrollBar" Then
            ListBox1.Items.Add("SmallChange 1  Change value by 1")
            ListBox1.Items.Add("SmallChange 5  Change value by 5")
        End If
        '  ListTag()
        ' ListText()
    End Sub

    Private Sub ListBox2_Click(sender As Object, e As EventArgs) Handles ListBox2.Click
        If ListBox2.Text <> "" Then
            LblTool.Text = Mid(Trim(ListBox2.Text), 1, Len(Trim(ListBox2.Text)) - 1)
            ListTag()
            If ListBox2.Text = "Label1 " Then
                sMsg = "'Blank out the Label Text"
                RText.Text = sMsg & "   " & vbCrLf & "Label1.Text=" & Chr(34) & Chr(34)
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
        End If
        If LblTool.Text = "RadioButton" Then
            RText.Text = "RadioButton1" & vbCrLf & sMsgR & vbCrLf & "RadioButton1.Checked = " & RadioButton1.Checked
        End If
        If LblTool.Text = "CheckBox" Then
            RText.Text = "CheckBox1" & vbCrLf & sMsgC & vbCrLf & "CheckBox1.Checked = " & CheckBox1.Checked
        End If
        LblTool1.Text = Trim(ListBox2.Text)
        If LblTool.Text = "TextBox" Then LblTool.Text = "Text"
    End Sub

    Private Sub ListBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox2.SelectedIndexChanged

    End Sub

    Private Sub ListBox1_Click(sender As Object, e As EventArgs) Handles ListBox1.Click
        If LblTool.Text = "HScrollBar" Then HScrollBar1.Visible = True
        If LblTool.Text = "Button" Then Button1.Visible = True
        If LblTool.Text = "Label" Then Label1.Visible = True
        If LblTool.Text = "Panel" Then Panel1.Visible = True
        If LblTool.Text = "RadioButton" Then RadioButton1.Visible = True
        If LblTool.Text = "CheckBox" Then CheckBox1.Visible = True
        If LblTool.Text = "PictureBox" Then PictureBox1.Visible = True
        If LblTool.Text = "Text" Then TextBox1.Visible = True
        If LblTool.Text = "HScrollBar" Then HScrollBar1.Enabled = True
        If LblTool.Text = "Button" Then Button1.Enabled = True
        If LblTool.Text = "Label" Then Label1.Enabled = True
        If LblTool.Text = "Panel" Then Panel1.Enabled = True
        If LblTool.Text = "RadioButton" Then RadioButton1.Enabled = True
        If LblTool.Text = "CheckBox" Then CheckBox1.Enabled = True
        If LblTool.Text = "PictureBox" Then PictureBox1.Enabled = True
        If LblTool.Text = "Text" Then TextBox1.Enabled = True
        If ListBox1.Text = "BackGroundImage = BtnImage.Image" Then
            Button1.BackgroundImage = BtnImage.Image
            RText.Text = " Button1.BackgroundImage = BtnImage.Image"
            sMsg = "'Add Background Image"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            bBtnImage = True
        End If
        If ListBox1.Text = "BackGroundImage = Nothing" Then
            Button1.BackgroundImage = Nothing
            RText.Text = "Button1.BackgroundImage = Nothing"
            sMsg = "'Remove Background Image"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            bBtnImage = False
        End If
        If Mid(ListBox1.Text, 1, 13) = "SmallChange 1" Then
            HScrollBar1.SmallChange = 1
            RText.Text = "HScrollBar1.SmallChange = 1"
            sMsg = "'SmallChange 1  Change value by 1"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 13) = "SmallChange 5" Then
            HScrollBar1.SmallChange = 5
            RText.Text = "HScrollBar1.SmallChange = 5"
            sMsg = "'SmallChange 5  Change value by 5"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 9) = "Checked F" Then
            If LblTool.Text = "RadioButton" Then
                RadioButton1.Checked = False
                RText.Text = "RadioButton1.Checked = False"
                sMsg = "'RadioButton1 Checked = False"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "CheckBox" Then
                CheckBox1.Checked = False
                RText.Text = "CheckBox1.Checked = False"
                sMsg = "'CheckBox1 Checked = False"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
        End If
        If Mid(ListBox1.Text, 1, 9) = "Checked T" Then
            If LblTool.Text = "RadioButton" Then
                RadioButton1.Checked = True
                RText.Text = "RadioButton1.Checked = True"
                sMsg = "'RadioButton1 Checked = True"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "CheckBox" Then
                CheckBox1.Checked = True
                RText.Text = "CheckBox1.Checked = True"
                sMsg = "'CheckBox1 Checked = True"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
        End If
        If Mid(ListBox1.Text, 1, 10) = "Visible  T" Then
            If LblTool.Text = "RadioButton" Then
                RadioButton1.Visible = True
                RText.Text = "RadioButton1.Visible = True"
                sMsg = "'RadioButton1 Visible	    Tool Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Text" Then
                TextBox1.Visible = True
                RText.Text = "TextBox1.Visible = True"
                sMsg = "'TextBox1 Visible	    Tool Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "HScrollBar" Then
                HScrollBar1.Visible = True
                RText.Text = "HScrollBar1.Visible = True"
                sMsg = "HScrollBar1 Visible	    Tool Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            '
            If LblTool.Text = "CheckBox" Then
                CheckBox1.Visible = True
                RText.Text = "CheckBox1.Visible = True"
                sMsg = "'CheckBox1 Visible	    Tool Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "PictureBox" Then
                PictureBox1.Visible = True
                RText.Text = "PictureBox1.Visible = True"
                sMsg = "PictureBox1 Visible	    Tool Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            '
            If LblTool.Text = "Button" Then
                Button1.Visible = True
                RText.Text = "Button1.Visible = True"
                sMsg = "'Button1 Visible	Tool Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Label" Then
                Label1.Visible = True
                RText.Text = "Label1.Visible = True"
                sMsg = "'Label1 Visible	 Tool Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Panel" Then
                Panel1.Visible = True
                RText.Text = "Panel1.Visible = True"
                sMsg = "'Panel1 Visible	 Tool Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 10) = "Visible  F" Then
            If LblTool.Text = "RadioButton" Then
                RadioButton1.Visible = False
                RText.Text = "RadioButton1.Visible = False"
                sMsg = "'RadioButton1 Visible	    Tool NOT Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Text" Then
                TextBox1.Visible = False
                RText.Text = "TextBox1.Visible = False"
                sMsg = "'TextBox1 Visible	    Tool NOT Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "HScrollBar" Then
                HScrollBar1.Visible = False
                RText.Text = "HScrollBar1.Visible = False"
                sMsg = "HScrollBar1 Visible	    Tool NOT Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            '
            If LblTool.Text = "CheckBox" Then
                CheckBox1.Visible = False
                RText.Text = "CheckBox1.Visible = False"
                sMsg = "'CheckBox1 Visible	    Tool NOT Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "PictureBox" Then
                PictureBox1.Visible = False
                RText.Text = "PictureBox1.Visible = False"
                sMsg = "PictureBox1 Visible	    Tool NOT Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            '
            If LblTool.Text = "Button" Then
                Button1.Visible = False
                RText.Text = "Button1.Visible = False"
                sMsg = "'Button1 Visible	    Tool NOT Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Label" Then
                Label1.Visible = False
                RText.Text = "Label1.Visible = False"
                sMsg = "'Label1 Visible	    Tool NOT Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Panel" Then
                Panel1.Visible = False
                RText.Text = "Panel1.Visible = False"
                sMsg = "'Panel1 Visible	    Tool NOT Visible"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            Exit Sub
        End If
        '
        If Mid(ListBox1.Text, 1, 5) = "Focus" Then
            If LblTool.Text = "Button" Then
                Button1.Focus()
                RText.Text = "Button1.Focus()"
                sMsg = "'Button1.Focus()  - Move Cursor to Button1"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Text" Then
                TextBox1.Focus()
                RText.Text = "TextBox1.Focus()"
                sMsg = "'TextBox1.Focus()  - Move Cursor to TextBox1"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 15) = "BorderStyle  (F" Then
            If LblTool.Text = "Label" Then
                Label1.BorderStyle = BorderStyle.Fixed3D
                RText.Text = " Label1.BorderStyle = BorderStyle.Fixed3D"
                sMsg = "'Label1  BorderStyle  (Fixed3D)"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Panel" Then
                Panel1.BorderStyle = BorderStyle.Fixed3D
                RText.Text = "Panel1.BorderStyle = BorderStyle.Fixed3D"
                sMsg = "'Panel1  BorderStyle  (Fixed3D)"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 15) = "BorderStyle  (N" Then
            If LblTool.Text = "Label" Then
                Label1.BorderStyle = BorderStyle.None
                RText.Text = " Label1.BorderStyle = BorderStyle.None"
                sMsg = "'Label1  BorderStyle  (None)"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Panel" Then
                Panel1.BorderStyle = BorderStyle.None
                RText.Text = "Panel1.BorderStyle = BorderStyle.None"
                sMsg = "'Panel1  BorderStyle  (None)"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 12) = "BackColor (Y" Then
            If LblTool.Text = "Text" Then
                TextBox1.BackColor = Color.Yellow
                RText.Text = "TextBox1.BackColor = Color.Yellow"
                sMsg = "'TextBox1  BackColor (Yellow)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "CheckBox" Then
                CheckBox1.BackColor = Color.Yellow
                RText.Text = "CheckBox1.BackColor = Color.Yellow"
                sMsg = "'CheckBox1  BackColor (Yellow)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "RadioButton" Then
                RadioButton1.BackColor = Color.Yellow
                RText.Text = "RadioButton1.BackColor = Color.Yellow"
                sMsg = "'RadioButton1  BackColor (Yellow)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Button" Then
                Button1.BackColor = Color.Yellow
                RText.Text = "Button1.BackColor = Color.Yellow"
                sMsg = "'Button1  BackColor (Yellow)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Label" Then
                Label1.BackColor = Color.Yellow
                RText.Text = "Label1.BackColor = Color.Yellow"
                sMsg = "'Label1  BackColor (Yellow)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Panel" Then
                Panel1.BackColor = Color.Yellow
                RText.Text = "Panel1.BackColor = Color.Yellow"
                sMsg = "'Panel1  BackColor (Yellow)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 12) = "BackColor (C" Then
            If LblTool.Text = "Text" Then
                TextBox1.BackColor = Color.Cyan
                RText.Text = "TextBox1.BackColor = Color.Cyan"
                sMsg = "'TextBox1 BackColor (Cyan)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "CheckBox" Then
                CheckBox1.BackColor = Color.Cyan
                RText.Text = "CheckBox1.BackColor = Color.Cyan"
                sMsg = "'CheckBox1 BackColor (Cyan)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "RadioButton" Then
                RadioButton1.BackColor = Color.Cyan
                RText.Text = "RadioButton1.BackColor = Color.Cyan"
                sMsg = "'RadioButton1 BackColor (Cyan)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Button" Then
                Button1.BackColor = Color.Cyan
                RText.Text = "Button1.BackColor = Color.Cyan"
                sMsg = "'Button1 BackColor (Cyan)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Label" Then
                Label1.BackColor = Color.Cyan
                RText.Text = "Label1.BackColor = Color.Cyan"
                sMsg = "'Label1 BackColor (Cyan)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Panel" Then
                Panel1.BackColor = Color.Cyan
                RText.Text = "Panel1.BackColor = Color.Cyan"
                sMsg = "'Panel1 BackColor (Cyan)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 12) = "ForeColor (R" Then
            If LblTool.Text = "Text" Then
                TextBox1.ForeColor = Color.Tomato
                RText.Text = "TextBox1.ForeColor =  Color.Tomato"
                sMsg = "'TextBox1 ForeColor (Red)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "CheckBox" Then
                CheckBox1.ForeColor = Color.Tomato
                RText.Text = "CheckBox1.ForeColor =  Color.Tomato"
                sMsg = "'CheckBox1 ForeColor (Red)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "RadioButton" Then
                RadioButton1.ForeColor = Color.Tomato
                RText.Text = "RadioButton1.ForeColor =  Color.Tomato"
                sMsg = "'RadioButton1 ForeColor (Red)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Button" Then
                Button1.ForeColor = Color.Tomato
                RText.Text = " Button1.ForeColor = Color.Tomato"
                sMsg = "'Button1 ForeColor (Red)	    Text color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Label" Then
                Label1.ForeColor = Color.Tomato
                RText.Text = "Label1.ForeColor = Color.Tomato"
                sMsg = "'Label1 ForeColor (Red)	    Text color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 12) = "ForeColor (G" Then
            If LblTool.Text = "Text" Then
                TextBox1.ForeColor = Color.Green
                RText.Text = "TextBox1.ForeColor =  Color.Green"
                sMsg = "'TextBox1 ForeColor (Green)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "CheckBox" Then
                CheckBox1.ForeColor = Color.Green
                RText.Text = "CheckBox1.ForeColor =  Color.Green"
                sMsg = "'CheckBox1 ForeColor (Green)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "RadioButton" Then
                RadioButton1.ForeColor = Color.Green
                RText.Text = "RadioButton1.ForeColor =  Color.Green"
                sMsg = "'RadioButton1 ForeColor (Green)  Background color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Button" Then
                Button1.ForeColor = Color.Green
                RText.Text = " Button1.ForeColor = Color.Green"
                sMsg = "'Button1 ForeColor (Green)	Text color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Label" Then
                Label1.ForeColor = Color.Green
                RText.Text = "Label1.ForeColor = Color.Green"
                sMsg = "'Label1 ForeColor (Green)	Text color"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 20) = "Enabled            T" Then
            If LblTool.Text = "RadioButton" Then
                RadioButton1.Enabled = True
                RText.Text = "RadioButton1.Enabled = True"
                sMsg = "'RadioButton1 Enabled	    True Can use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Text" Then
                TextBox1.Enabled = True
                RText.Text = "TextBox1.Enabled = True"
                sMsg = "'TextBox1 Enabled	    True Can use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "HScrollBar" Then
                HScrollBar1.Enabled = True
                RText.Text = "HScrollBar1.Enabled = True"
                sMsg = "HScrollBar1 Enabled	    True Can use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            '
            If LblTool.Text = "Text" Then
                TextBox1.Enabled = True
                RText.Text = "TextBox1.Enabled = True"
                sMsg = "'TextBox1 Enabled	    True Can use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "CheckBox" Then
                CheckBox1.Enabled = True
                RText.Text = "CheckBox1.Enabled = True"
                sMsg = "'CheckBox1 Enabled	    True Can use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "PictureBox" Then
                PictureBox1.Enabled = True
                RText.Text = "PictureBox1.Enabled = True"
                sMsg = "PictureBox1 Enabled	    True Can use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            '
            If LblTool.Text = "Button" Then
                Button1.Enabled = True
                RText.Text = "Button1.Enabled = True"
                sMsg = "'Button1 Enabled	True Can use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Label" Then
                Label1.Enabled = True
                RText.Text = "Label1.Enabled = True"
                sMsg = "'Label1 Enabled	True Can use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 20) = "Enabled            F" Then
            If LblTool.Text = "RadioButton" Then
                RadioButton1.Enabled = False
                RText.Text = "RadioButton1.Enabled = False"
                sMsg = "'RadioButton1 Enabled	    False Not able use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Text" Then
                TextBox1.Enabled = False
                RText.Text = "TextBox1.Enabled = False"
                sMsg = "'TextBox1 Enabled	    False Not able use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "HScrollBar" Then
                HScrollBar1.Enabled = False
                RText.Text = "HScrollBar1.Enabled = False"
                sMsg = "HScrollBar1 Enabled	    False Not able use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            '
            If LblTool.Text = "Text" Then
                TextBox1.Enabled = False
                RText.Text = "TextBox1.Enabled = False"
                sMsg = "'TextBox1 Enabled	    False Not able use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "CheckBox" Then
                CheckBox1.Enabled = False
                RText.Text = "CheckBox1.Enabled = False"
                sMsg = "'CheckBox1 Enabled	    False Not able use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "PictureBox" Then
                PictureBox1.Enabled = False
                RText.Text = "PictureBox1.Enabled = False"
                sMsg = "PictureBox1 Enabled	    False Not able use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            '
            If LblTool.Text = "Button" Then
                Button1.Enabled = False
                RText.Text = "Button1.Enabled = False"
                sMsg = "'Button1 Enabled	    False Not able use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            If LblTool.Text = "Label" Then
                Label1.Enabled = False
                RText.Text = "Label1.Enabled = False"
                sMsg = "'Label1 Enabled	    False Not able use"
                RText.Text = sMsg & "   " & vbCrLf & RText.Text
                RText.Select(0, Len(sMsg))
                RText.SelectionColor = Color.Green
            End If
            Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 4) = "Text" Then SetText()
        If Mid(ListBox1.Text, 1, 3) = "Tag" Then SetTag()
        ListTag()
        ListText()
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub
    Private Sub ListTag()
        ToolList()
        ListBox3.Items.Clear()
        If LblTool.Text = "HScrollBar" Then
            ListBox3.Items.Add("---HScrollBar---")
            ListBox3.Items.Add("(Name)    " & HScrollBar1.Name)
            ListBox3.Items.Add("Enabled   " & HScrollBar1.Enabled)
            ListBox3.Items.Add("Location (Top , Left) ")
            ListBox3.Items.Add("  Top     " & HScrollBar1.Top)
            ListBox3.Items.Add("  Left    " & HScrollBar1.Left)
            ListBox3.Items.Add("Maximum   " & HScrollBar1.Maximum)
            ListBox3.Items.Add("Minimum   " & HScrollBar1.Minimum)
            ListBox3.Items.Add("Tag       " & HScrollBar1.Tag)
            ListBox3.Items.Add("Text      " & HScrollBar1.Text)
            ListBox3.Items.Add("Size(Width,Height)      ")
            ListBox3.Items.Add("  Width   " & HScrollBar1.Width)
            ListBox3.Items.Add("  Height  " & HScrollBar1.Height)
            ListBox3.Items.Add("SmallChange   " & HScrollBar1.SmallChange)
            ListBox3.Items.Add("Visible   " & HScrollBar1.Visible)
            ListBox3.Items.Add("Value (Scroll Value)     " & HScrollBar1.Value)
            TxtTag.Text = HScrollBar1.Tag
        End If
        If LblTool.Text = "CheckBox" Then
            '  RText.Text = "CheckBox" & vbCrLf & sMsgC & vbCrLf & "CheckBox.Checked = " & CheckBox1.Checked
            ListBox3.Items.Add("---CheckBox---")
            ListBox3.Items.Add("(Name)    " & CheckBox1.Name)
            ListBox3.Items.Add("BackColor " & CheckBox1.BackColor.ToString)
            ListBox3.Items.Add("Checked   " & CheckBox1.Checked)
            ListBox3.Items.Add("Enabled   " & CheckBox1.Enabled)
            ListBox3.Items.Add("ForeColor " & CheckBox1.ForeColor.ToString)
            ListBox3.Items.Add("Location (Top , Left) ")
            ListBox3.Items.Add("  Top     " & CheckBox1.Top)
            ListBox3.Items.Add("  Left    " & CheckBox1.Left)
            ListBox3.Items.Add("Tag       " & CheckBox1.Tag)
            ListBox3.Items.Add("Text      " & CheckBox1.Text)
            ListBox3.Items.Add("Size(Width,Height)      ")
            ListBox3.Items.Add("  Width   " & CheckBox1.Width)
            ListBox3.Items.Add("  Height  " & CheckBox1.Height)
            ListBox3.Items.Add("Visible   " & CheckBox1.Visible)
            TxtTag.Text = CheckBox1.Tag
        End If
        If LblTool.Text = "RadioButton" Then
            ' RText.Text = "RadioButton" & vbCrLf & sMsgR & vbCrLf & "RadioButton.Checked = " & RadioButton1.Checked
            ListBox3.Items.Add("---RadioButton---")
            ListBox3.Items.Add("(Name)    " & RadioButton1.Name)
            ListBox3.Items.Add("BackColor " & RadioButton1.BackColor.ToString)
            ListBox3.Items.Add("Checked   " & RadioButton1.Checked)
            ListBox3.Items.Add("Enabled   " & RadioButton1.Enabled)
            ListBox3.Items.Add("ForeColor " & RadioButton1.ForeColor.ToString)
            ListBox3.Items.Add("Location (Top , Left) ")
            ListBox3.Items.Add("  Top     " & RadioButton1.Top)
            ListBox3.Items.Add("  Left    " & RadioButton1.Left)
            ListBox3.Items.Add("Tag       " & RadioButton1.Tag)
            ListBox3.Items.Add("Text      " & RadioButton1.Text)
            ListBox3.Items.Add("Size(Width,Height)      ")
            ListBox3.Items.Add("  Width   " & RadioButton1.Width)
            ListBox3.Items.Add("  Height  " & RadioButton1.Height)
            ListBox3.Items.Add("Visible   " & RadioButton1.Visible)
            TxtTag.Text = RadioButton1.Tag
        End If
        If LblTool.Text = "Text" Then
            ListBox3.Items.Add("---TextBox---")
            ListBox3.Items.Add("(Name)    " & TextBox1.Name)
            ListBox3.Items.Add("BackColor " & TextBox1.BackColor.ToString)
            ListBox3.Items.Add("Enabled   " & TextBox1.Enabled)
            ListBox3.Items.Add("ForeColor " & TextBox1.ForeColor.ToString)
            ListBox3.Items.Add("Location (Top , Left) ")
            ListBox3.Items.Add("  Top     " & TextBox1.Top)
            ListBox3.Items.Add("  Left    " & TextBox1.Left)
            ListBox3.Items.Add("Tag       " & TextBox1.Tag)
            ListBox3.Items.Add("Text      " & TextBox1.Text)
            ListBox3.Items.Add("Size(Width,Height)      ")
            ListBox3.Items.Add("  Width   " & TextBox1.Width)
            ListBox3.Items.Add("  Height  " & TextBox1.Height)
            ListBox3.Items.Add("Visible   " & TextBox1.Visible)
            If TextBox1.Enabled And TextBox1.Visible Then ListBox1.Items.Add("Focus  Move Cursor to TextBox1")
            TxtTag.Text = TextBox1.Tag
        End If
        If LblTool.Text = "Button" Then
            ListBox3.Items.Add("---Button---")
            ListBox3.Items.Add("(Name)    " & Button1.Name)
            ListBox3.Items.Add("BackColor " & Button1.BackColor.ToString)
            If bBtnImage Then
                ListBox3.Items.Add("BackGroundImage = BtnImage.Image")
            Else
                ListBox3.Items.Add("BackGroundImage = Nothing")
            End If
            ListBox3.Items.Add("BackgroundImageLayout = Stretch ")
            ListBox3.Items.Add("Enabled   " & Button1.Enabled)
            ListBox3.Items.Add("ForeColor " & Button1.ForeColor.ToString)  'BackgroundImage = Nothing
            ListBox3.Items.Add("Location (Top , Left) ")
            ListBox3.Items.Add("  Top     " & Button1.Top)
            ListBox3.Items.Add("  Left    " & Button1.Left)
            ListBox3.Items.Add("Tag       " & Button1.Tag)
            ListBox3.Items.Add("Text      " & Button1.Text)
            ListBox3.Items.Add("Size(Width,Height)      ")
            ListBox3.Items.Add("  Width   " & Button1.Width)
            ListBox3.Items.Add("  Height  " & Button1.Height)
            ListBox3.Items.Add("Visible   " & Button1.Visible)
            If Button1.Enabled And Button1.Visible Then ListBox1.Items.Add("Focus  -  Move Cursor to Button1")
            TxtTag.Text = Button1.Tag
        End If
        If LblTool.Text = "Label" Then
            TxtTag.Text = Label1.Tag
            ListBox3.Items.Add("---Label---")
            ListBox3.Items.Add("(Name)    " & Label1.Name)
            ListBox3.Items.Add("BackColor " & Label1.BackColor.ToString)
            ListBox3.Items.Add("BorderStyle " & Label1.BorderStyle.ToString)
            ListBox3.Items.Add("Enabled   " & Label1.Enabled)
            ListBox3.Items.Add("ForeColor " & Label1.ForeColor.ToString)
            ListBox3.Items.Add("Location (Top , Left) ")
            ListBox3.Items.Add("  Top     " & Label1.Top)
            ListBox3.Items.Add("  Left    " & Label1.Left)
            ListBox3.Items.Add("Tag       " & Label1.Tag)
            ListBox3.Items.Add("Text      " & Label1.Text)
            ListBox3.Items.Add("Size(Width,Height)      ")
            ListBox3.Items.Add("  Width   " & Label1.Width)
            ListBox3.Items.Add("  Height  " & Label1.Height)
            ListBox3.Items.Add("Visible   " & Label1.Visible)
        End If
        If LblTool.Text = "Panel" Then
            TxtTag.Text = Panel1.Tag
            ListBox3.Items.Add("---Panel---")
            ListBox3.Items.Add("(Name)    " & Panel1.Name)
            ListBox3.Items.Add("BackColor " & Panel1.BackColor.ToString)
            ListBox3.Items.Add("BorderStyle " & Panel1.BorderStyle.ToString)
            ListBox3.Items.Add("Enabled   " & Panel1.Enabled)
            ListBox3.Items.Add("Location (Top , Left) ")
            ListBox3.Items.Add("  Top     " & Panel1.Top)
            ListBox3.Items.Add("  Left    " & Panel1.Left)
            ListBox3.Items.Add("Tag       " & Panel1.Tag)
            ListBox3.Items.Add("Text      " & Panel1.Text)
            ListBox3.Items.Add("Size(Width,Height)      ")
            ListBox3.Items.Add("  Width   " & Panel1.Width)
            ListBox3.Items.Add("  Height  " & Panel1.Height)
            ListBox3.Items.Add("Visible   " & Panel1.Visible)
        End If
        If LblTool.Text = "Picture" Then
            TxtTag.Text = PictureBox1.Tag
            ListBox3.Items.Add("---PictureBox---")
            ListBox3.Items.Add("(Name)    " & PictureBox1.Name)
            ListBox3.Items.Add("BackColor " & PictureBox1.BackColor.ToString)
            ListBox3.Items.Add("Enabled   " & PictureBox1.Enabled)
            ListBox3.Items.Add("Image = PictureImage.Image")
            ListBox3.Items.Add("Location (Top , Left) ")
            ListBox3.Items.Add("  Top     " & PictureBox1.Top)
            ListBox3.Items.Add("  Left    " & PictureBox1.Left)
            ListBox3.Items.Add("Tag       " & PictureBox1.Tag)
            ListBox3.Items.Add("Size(Width,Height)      ")
            ListBox3.Items.Add("  Width   " & PictureBox1.Width)
            ListBox3.Items.Add("  Height  " & PictureBox1.Height)
            ListBox3.Items.Add("SizeMode = Stretch ")
            ListBox3.Items.Add("Visible   " & PictureBox1.Visible)
        End If
        ListText()
    End Sub
    Private Sub ListText()
        If LblTool.Text = "Button" Then
            TxtText.Text = Button1.Text
        End If
        If LblTool.Text = "Label" Then
            TxtText.Text = Label1.Text
        End If
        If LblTool.Text = "CheckBox" Then
            TxtText.Text = CheckBox1.Text
        End If
        If LblTool.Text = "RadioButton" Then
            TxtText.Text = RadioButton1.Text
        End If
        If LblTool.Text = "Text" Then
            TxtText.Text = TextBox1.Text
        End If
    End Sub
    Private Sub SetTag()
        If LblTool.Text = "Label" Then
            Label1.Tag = TxtTag.Text
            RText.Text = "Label1.Tag = TxtTag.Text"
            sMsg = "'Label1 Tag"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If LblTool.Text = "Panel" Then
            Panel1.Tag = TxtTag.Text
            RText.Text = "Panel1.Tag = TxtTag.Text"
            sMsg = "'Panel1 Tag"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If LblTool.Text = "Picture" Then
            PictureBox1.Tag = TxtTag.Text
            RText.Text = "PictureBox1.Tag = TxtTag.Text"
            sMsg = "'PictureBox1 Tag"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        '
        If LblTool.Text = "Button" Then
            Button1.Tag = TxtTag.Text
            RText.Text = "Button1.Tag = TxtTag.Text"
            sMsg = "'Button1 Tag"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        '
        If LblTool.Text = "RadioButton" Then
            RadioButton1.Tag = TxtTag.Text
            RText.Text = "RadioButton1.Tag = TxtTag.Text"
            sMsg = "'RadioButton1 Tag"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If LblTool.Text = "CheckBox" Then
            CheckBox1.Tag = TxtTag.Text
            RText.Text = "CheckBox1.Tag = TxtTag.Text"
            sMsg = "'CheckBox1 Tag"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If LblTool.Text = "Text" Then
            TextBox1.Tag = TxtTag.Text
            RText.Text = "TextBox1.Text = TxtTag.Text"
            sMsg = "'TextBox1 Tag"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If LblTool.Text = "HScrollBar" Then
            HScrollBar1.Tag = TxtTag.Text
            RText.Text = "HScrollBar1.Tag = TxtTag.Text"
            sMsg = "'HScrollBar1 Tag"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
    End Sub
    Private Sub SetText()
        If LblTool.Text = "Button" Then
            Button1.Text = TxtText.Text
            RText.Text = "Button1.Text = TxtText.Text"
            sMsg = "'Button1 Text"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If LblTool.Text = "Label" Then
            Label1.Text = TxtText.Text
            RText.Text = "Label1.Text = TxtText.Text"
            sMsg = "'Label1 Text"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If LblTool.Text = "Text" Then
            TextBox1.Text = TxtText.Text
            RText.Text = "TextBox1.Text = TxtText.Text"
            sMsg = "'TextBox1 Text"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If LblTool.Text = "RadioButton" Then
            RadioButton1.Text = TxtText.Text
            RText.Text = "RadioButton1.Text = TxtText.Text"
            sMsg = "'RadioButton1 Text"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            Exit Sub
        End If
        If LblTool.Text = "CheckBox" Then
            CheckBox1.Text = TxtText.Text
            RText.Text = "CheckBox1.Text = TxtText.Text"
            sMsg = "'CheckBox1 Text"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            Exit Sub
        End If
    End Sub
    Private Sub TxtB_TextChanged(sender As Object, e As EventArgs) Handles TxtTag.TextChanged

    End Sub

    Private Sub TxtText_KeyDown(sender As Object, e As KeyEventArgs) Handles TxtText.KeyDown
        If e.KeyCode = Keys.Enter Then
            SetText()
        End If
    End Sub

    Private Sub TxtText_TextChanged(sender As Object, e As EventArgs) Handles TxtText.TextChanged

    End Sub

    Private Sub TxtTag_KeyDown(sender As Object, e As KeyEventArgs) Handles TxtTag.KeyDown
        If e.KeyCode = Keys.Enter Then
            SetTag()
        End If
    End Sub

    Private Sub HScrollBar1_ValueChanged(sender As Object, e As EventArgs) Handles HScrollBar1.ValueChanged
        ListBox2.Text = "HScrollBar"
        LblTool.Text = "HScrollBar"
        ListTag()
    End Sub

    Private Sub HScrollBar1_Scroll(sender As Object, e As ScrollEventArgs) Handles HScrollBar1.Scroll

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        sMsg = "'Button1_Click"
        RText.Text = sMsg & "   " & vbCrLf & "Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click"
        RText.Text = RText.Text & vbCrLf & "End Sub"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        sMsg = "'Label1_Click"
        RText.Text = sMsg & "   " & vbCrLf & "Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Button1.Click"
        RText.Text = RText.Text & vbCrLf & "End Sub"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        sMsg = "'PictureBox1_Click"
        RText.Text = sMsg & "   " & vbCrLf & "Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles Button1.Click"
        RText.Text = RText.Text & vbCrLf & "End Sub"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub RadioButton1_Click(sender As Object, e As EventArgs) Handles RadioButton1.Click
        RText.Text = "RadioButton1" & vbCrLf & sMsgR & vbCrLf & "RadioButton1.Checked = " & RadioButton1.Checked
    End Sub

    Private Sub RadioButton2_Click(sender As Object, e As EventArgs) Handles RadioButton2.Click
        RText.Text = "RadioButton2" & vbCrLf & sMsgR & vbCrLf & "RadioButton2.Checked = " & RadioButton2.Checked
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged

    End Sub

    Private Sub CheckBox1_Click(sender As Object, e As EventArgs) Handles CheckBox1.Click
        RText.Text = "CheckBox1" & vbCrLf & sMsgC & vbCrLf & "CheckBox1
\.Checked = " & CheckBox1.Checked
    End Sub

    Private Sub CheckBox2_Click(sender As Object, e As EventArgs) Handles CheckBox2.Click
        RText.Text = "CheckBox2" & vbCrLf & sMsgC & vbCrLf & "CheckBox2.Checked = " & CheckBox2.Checked
    End Sub
End Class
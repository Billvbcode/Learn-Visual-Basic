﻿Public Class FrmClassvb
    Dim sFileName As String
    Dim colCar As Collection   ' Collection for all Cars
    Dim cCar As ClsCar         ' Class for one Car
    Dim sCar(200, 6) As String ' Array for a Car

    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub BtnClass_Click(sender As Object, e As EventArgs) Handles BtnClass.Click
        sFileName = "Class.txt"
        rFile()
        LblCode.Text = "Create Class"
        RText.Height = 520
        dGrid.Visible = False
        Dim i As Integer
        sCar(1, 1) = "Chevy"    ' X,1 = Mfg (Car1)
        sCar(1, 2) = "2014"     ' X,2 = Year
        sCar(1, 3) = "T"        ' X,3 = MoonRoof
        sCar(2, 1) = "Ford"     ' X,1 = Mfg (Car2)
        sCar(2, 2) = "2016"     ' X,4 = Year
        sCar(2, 3) = "F"        ' X,3 = MoonRoof
        '-----Create the collection--------------
        colCar = New Collection ' Initialize Collection
        For i = 1 To 2
            cCar = New ClsCar        ' Initialize class
            cCar.Mfg = sCar(i, 1)    'Car Mfg
            cCar.Year = sCar(i, 4)   'Car Year
            If sCar(1, 3) = "T" Then
                cCar.MoonRoof = True   'MoonRoof
            Else
                cCar.MoonRoof = False   'MoonRoof
            End If
            colCar.Add(cCar)         'Add Car to collection
        Next
    End Sub

    Private Sub FrmClassvb_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        sFileName = "ClassVsArray.txt"
        rFile()
        LblCode.Text = "What is a Class"
    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click
        sFileName = "AddClass.txt"
        rFile()
        LblCode.Text = "AddClass"
        RText.Height = 520
        dGrid.Visible = False
        Dim i As Integer
        sCar(1, 1) = "Chevy"    ' X,1 = Mfg (Car1)
        sCar(1, 2) = "2014"     ' X,2 = Year
        sCar(1, 3) = "T"        ' X,3 = MoonRoof
        sCar(2, 1) = "Ford"     ' X,1 = Mfg (Car2)
        sCar(2, 2) = "2016"     ' X,4 = Year
        sCar(2, 3) = "F"        ' X,3 = MoonRoof
        '-----Create the collection--------------
        colCar = New Collection ' Initialize Collection
        For i = 1 To 2
            cCar = New ClsCar        ' Initialize class
            cCar.Mfg = sCar(i, 1)    'Car Mfg
            cCar.Year = sCar(i, 2)   'Car Year
            If sCar(i, 3) = "T" Then
                cCar.MoonRoof = True   'MoonRoof
            Else
                cCar.MoonRoof = False   'MoonRoof
            End If
            colCar.Add(cCar)         'Add Car to collection
        Next
    End Sub

    Private Sub BtnView_Click(sender As Object, e As EventArgs) Handles BtnView.Click
        sFileName = "ViewClass.txt"
        rFile()
        LblCode.Text = "ViewClass"
        RText.Height = 420
        dGrid.Visible = True
        Dim i As Integer
        sCar(1, 1) = "Chevy"    ' X,1 = Mfg (Car1)
        sCar(1, 2) = "2014"     ' X,2 = Year
        sCar(1, 3) = "T"        ' X,3 = MoonRoof
        sCar(2, 1) = "Ford"     ' X,1 = Mfg (Car2)
        sCar(2, 2) = "2016"     ' X,4 = Year
        sCar(2, 3) = "F"        ' X,3 = MoonRoof
        '-----Create the collection--------------
        colCar = New Collection ' Initialize Collection
        For i = 1 To 2
            cCar = New ClsCar        ' Initialize class
            cCar.Mfg = sCar(i, 1)    'Car Mfg
            cCar.Year = sCar(i, 2)   'Car Year
            If sCar(i, 3) = "T" Then
                cCar.MoonRoof = True   'MoonRoof
            Else
                cCar.MoonRoof = False   'MoonRoof
            End If
            colCar.Add(cCar)         'Add Car to collection
        Next
        '-----Display the collection--------------
        i = 0
        dGrid.ColumnCount = 3
        dGrid.Columns(0).Name = "Mfg"
        dGrid.Columns(1).Name = "Year"
        dGrid.Columns(2).Name = "MoonRoof"
        For Each cCar In colCar
            dGrid.Rows.Insert(i, New String() {cCar.Mfg, cCar.Year, cCar.MoonRoof})
            i = i + 1
        Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        sFileName = "Classnew.txt"
        rFile()
        LblCode.Text = "Class with Default Value"
        RText.Height = 520
        dGrid.Visible = False
        Dim i As Integer
        sCar(1, 1) = "Chevy"    ' X,1 = Mfg (Car1)
        sCar(1, 2) = "2014"     ' X,2 = Year
        sCar(1, 3) = "T"        ' X,3 = MoonRoof
        sCar(2, 1) = "Ford"     ' X,1 = Mfg (Car2)
        sCar(2, 2) = "2016"     ' X,4 = Year
        sCar(2, 3) = "F"        ' X,3 = MoonRoof
        '-----Create the collection--------------
        colCar = New Collection ' Initialize Collection
        For i = 1 To 2
            cCar = New ClsCar        ' Initialize class
            cCar.Mfg = sCar(i, 1)    'Car Mfg
            cCar.Year = sCar(i, 4)   'Car Year
            If sCar(1, 3) = "T" Then
                cCar.MoonRoof = True   'MoonRoof
            Else
                cCar.MoonRoof = False   'MoonRoof
            End If
            colCar.Add(cCar)         'Add Car to collection
        Next
    End Sub

    Private Sub BtnDefault_Click(sender As Object, e As EventArgs) Handles BtnDefault.Click
        Dim i As Integer
        sFileName = "Default.txt"
        rFile()
        LblCode.Text = "View Default Class"
        RText.Height = 420
        dGrid.Visible = True
        '-----Create the collection--------------
        colCar = New Collection ' Initialize Collection
        cCar = New ClsCar        ' Initialize class
        colCar.Add(cCar)         'Add Car to collection
        i = 0
        dGrid.ColumnCount = 3
        dGrid.Columns(0).Name = "Mfg"
        dGrid.Columns(1).Name = "Year"
        dGrid.Columns(2).Name = "MoonRoof"
        For Each cCar In colCar
            dGrid.Rows.Insert(i, New String() {cCar.Mfg, cCar.Year, cCar.MoonRoof})
            i = i + 1
        Next
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        sFileName = "ClassVsArray.txt"
        rFile()
        LblCode.Text = "What is a Class"
    End Sub
End Class
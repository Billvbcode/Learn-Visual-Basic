﻿Public Class FrmMath
    Dim sMsg As String
    Dim sFileName As String
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub FrmMath_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox1.Items.Clear()
        ListBox1.Items.Add("+          Add")
        ListBox1.Items.Add("-          Subtract")
        ListBox1.Items.Add("*          Times")
        ListBox1.Items.Add("/          Divide")
        ListBox1.Items.Add("^          Power")
        ListBox1.Items.Add("Int        Integer Value")
        ListBox1.Items.Add("Mod        Remainder")
        ListBox1.Items.Add("Val(Text)  Value of text string ")
        ListBox1.Items.Add("Math.Abs   Absolute value")
        ListBox1.Items.Add("Random    Random value")
        'ListBox1.Items.Add("+  Add")
        Randomize() 'Random # seed
    End Sub

    Private Sub ListBox1_Click(sender As Object, e As EventArgs) Handles ListBox1.Click
        Dim si As Single
        Dim i As Integer
        Dim sMsg As String
        If Mid(ListBox1.Text, 1, 2) = "In" Then
            si = 1.5678
            LblCode.Text = si
            si = Int(si)
            LblResult.Text = si
            sMsg = "'Int        Integer Value"
            RText.Text = sMsg & vbCrLf & "Dim si As Single" & vbCrLf & "si = 1.5678" & vbCrLf
            RText.Text = RText.Text & "LblCode.Text = si" & vbCrLf
            RText.Text = RText.Text & "si = Int(si)" & vbCrLf & "LblResult.Text = si"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 2) = "Va" Then
            sMsg = "Val(Text)  Value of text string"
            sFileName = "value.txt"
            rFile()
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 2) = "Ra" Then
            i = 9000 * Rnd()
            LblCode.Text = "i = " & i
            i = i Mod 9
            LblResult.Text = i
            sMsg = "'Random    Random value  (0 - 8 )"
            sFileName = "random.txt"
            rFile()
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            'RText.Text = sMsg & vbCrLf & "Dim i As Integer" & vbCrLf & " i = 9000 * Rnd()" & vbCrLf
            'RText.Text = RText.Text & " i = i Mod 9" & vbCrLf & "LblResult.Text = i"
            'RText.Select(0, Len(sMsg))
            'RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 2) = "Mo" Then
            i = 9000 * Rnd()
            LblCode.Text = "i = " & i
            i = i Mod 9
            LblResult.Text = i
            sMsg = "'Mod        Remainder"
            RText.Text = sMsg & vbCrLf & "Dim i As Integer" & vbCrLf & " i = 9000 * Rnd()" & vbCrLf
            RText.Text = RText.Text & " i = i Mod 9" & vbCrLf & "LblResult.Text = i"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 2) = "Ma" Then
            i = -11
            i = Math.Abs(i)
            LblResult.Text = i
            sMsg = "'Math.Abs   Absolute value"
            RText.Text = sMsg & vbCrLf & "Dim i As Integer" & vbCrLf & "i = -11" & vbCrLf
            RText.Text = RText.Text & "i = Math.Abs(i)" & vbCrLf & "LblResult.Text = i"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 1) = "+" Then
            i = 1
            i += 5
            LblResult.Text = i
            sMsg = "'Add"
            RText.Text = sMsg & vbCrLf & "Dim i As Integer" & vbCrLf & "i = 1" & vbCrLf
            RText.Text = RText.Text & "i += 5" & vbCrLf & "LblResult.Text = i"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 1) = "-" Then
            i = 6
            i -= 2
            LblResult.Text = i
            sMsg = "'Subtract"
            RText.Text = sMsg & vbCrLf & "Dim i As Integer" & vbCrLf & "i = 6" & vbCrLf
            RText.Text = RText.Text & "i -= 2" & vbCrLf & "LblResult.Text = i"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 1) = "-" Then
            i = 6
            i -= 2
            LblResult.Text = i
            sMsg = "'Subtract"
            RText.Text = sMsg & vbCrLf & "Dim i As Integer" & vbCrLf & "i = 6" & vbCrLf
            RText.Text = RText.Text & "i -= 2" & vbCrLf & "LblResult.Text = i"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 1) = "*" Then
            i = 6
            i *= 2
            LblResult.Text = i
            sMsg = "'Times"
            RText.Text = sMsg & vbCrLf & "Dim i As Integer" & vbCrLf & "i = 6" & vbCrLf
            RText.Text = RText.Text & "i *= 2" & vbCrLf & "LblResult.Text = i"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 1) = "/" Then
            i = 6
            i = i / 2
            LblResult.Text = i
            sMsg = "'Divide"
            RText.Text = sMsg & vbCrLf & "Dim i As Integer" & vbCrLf & "i = 6" & vbCrLf
            RText.Text = RText.Text & "i = i / 2" & vbCrLf & "LblResult.Text = i"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 1) = "^" Then
            i = 6
            i = i ^ 2
            LblResult.Text = i
            sMsg = "'Power"
            RText.Text = sMsg & vbCrLf & "Dim i As Integer" & vbCrLf & "i = 6" & vbCrLf
            RText.Text = RText.Text & "i = i ^ 2" & vbCrLf & "LblResult.Text = i"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub
End Class
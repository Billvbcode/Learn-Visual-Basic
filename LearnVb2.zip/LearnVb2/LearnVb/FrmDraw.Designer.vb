﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmDraw
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.LblCode = New System.Windows.Forms.Label()
        Me.RText = New System.Windows.Forms.RichTextBox()
        Me.BtnHLine = New System.Windows.Forms.Button()
        Me.BtnVLine = New System.Windows.Forms.Button()
        Me.BtnRectangle = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BtnFillC = New System.Windows.Forms.Button()
        Me.BtnCircle = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'LblCode
        '
        Me.LblCode.AutoSize = True
        Me.LblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCode.Location = New System.Drawing.Point(21, 341)
        Me.LblCode.Name = "LblCode"
        Me.LblCode.Size = New System.Drawing.Size(51, 20)
        Me.LblCode.TabIndex = 58
        Me.LblCode.Text = "Code"
        '
        'RText
        '
        Me.RText.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RText.Location = New System.Drawing.Point(25, 364)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(811, 250)
        Me.RText.TabIndex = 57
        Me.RText.Text = ""
        '
        'BtnHLine
        '
        Me.BtnHLine.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnHLine.Location = New System.Drawing.Point(12, 35)
        Me.BtnHLine.Name = "BtnHLine"
        Me.BtnHLine.Size = New System.Drawing.Size(106, 46)
        Me.BtnHLine.TabIndex = 56
        Me.BtnHLine.Text = "HorLine"
        Me.BtnHLine.UseVisualStyleBackColor = True
        '
        'BtnVLine
        '
        Me.BtnVLine.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnVLine.Location = New System.Drawing.Point(153, 35)
        Me.BtnVLine.Name = "BtnVLine"
        Me.BtnVLine.Size = New System.Drawing.Size(106, 46)
        Me.BtnVLine.TabIndex = 71
        Me.BtnVLine.Text = "VertLine"
        Me.BtnVLine.UseVisualStyleBackColor = True
        '
        'BtnRectangle
        '
        Me.BtnRectangle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRectangle.Location = New System.Drawing.Point(287, 35)
        Me.BtnRectangle.Name = "BtnRectangle"
        Me.BtnRectangle.Size = New System.Drawing.Size(111, 46)
        Me.BtnRectangle.TabIndex = 72
        Me.BtnRectangle.Text = "Rectangle"
        Me.BtnRectangle.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(425, 35)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(106, 46)
        Me.Button1.TabIndex = 73
        Me.Button1.Text = "FillR"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BtnFillC
        '
        Me.BtnFillC.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFillC.Location = New System.Drawing.Point(700, 35)
        Me.BtnFillC.Name = "BtnFillC"
        Me.BtnFillC.Size = New System.Drawing.Size(106, 46)
        Me.BtnFillC.TabIndex = 75
        Me.BtnFillC.Text = "FillC"
        Me.BtnFillC.UseVisualStyleBackColor = True
        '
        'BtnCircle
        '
        Me.BtnCircle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCircle.Location = New System.Drawing.Point(562, 35)
        Me.BtnCircle.Name = "BtnCircle"
        Me.BtnCircle.Size = New System.Drawing.Size(111, 46)
        Me.BtnCircle.TabIndex = 74
        Me.BtnCircle.Text = "Circle"
        Me.BtnCircle.UseVisualStyleBackColor = True
        '
        'FrmDraw
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1035, 626)
        Me.Controls.Add(Me.BtnFillC)
        Me.Controls.Add(Me.BtnCircle)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.BtnRectangle)
        Me.Controls.Add(Me.BtnVLine)
        Me.Controls.Add(Me.LblCode)
        Me.Controls.Add(Me.RText)
        Me.Controls.Add(Me.BtnHLine)
        Me.Name = "FrmDraw"
        Me.Text = "FrmDraw"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LblCode As Label
    Friend WithEvents RText As RichTextBox
    Friend WithEvents BtnHLine As Button
    Friend WithEvents BtnVLine As Button
    Friend WithEvents BtnRectangle As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents BtnFillC As Button
    Friend WithEvents BtnCircle As Button
End Class

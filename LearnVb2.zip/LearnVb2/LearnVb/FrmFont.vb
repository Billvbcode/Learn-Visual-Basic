﻿Public Class FrmFont
    Dim sColorBack ' BackgroundColor
    Dim sColorFore ' ForeroundColor
    Dim sRBcode As String
    Dim sBordercode As String
    Dim sFontcode As String
    Dim sMsg As String
    Dim sFileName As String
    Dim sFont As String
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub FrmFont_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Set ChkAutosize to True
        ChkAuto.Checked = True
        'Set ChkEnabled to True
        ChkEnable.Checked = True
        'Set ChkVisible to True
        ChkVisible.Checked = True
        CB10.Checked = True
        'Set RadioRegular to True
        RBReg.Checked = True
        sFont = "FontStyle.Regular"
        'Make LblTest.BackColor Light Coral
        LblTest.BackColor = Color.LightCoral
        sColorFore = "LblTest.ForeColor = Color.Black"
        sColorBack = "LblTest.BackColor = DefaultBackColor"
        sFontcode = "LblTest.Font = New Font(" & Chr(34) & "Times New Roman" & Chr(34) & ", 10, FontStyle.Regular)"
        sBordercode = "LblTest.BorderStyle = BorderStyle.None"
        ShowCode() 'Show VB.Net Code
    End Sub
    Private Sub ChkAuto_CheckedChanged(sender As Object, e As EventArgs) Handles ChkAuto.CheckedChanged
        'Set LblTest.Width to 20
        LblTest.Width = 20
        'Set LblTest.Autosize to True or False
        LblTest.AutoSize = ChkAuto.Checked
        sMsg = "'AutoSize = True          the size will expand or contract" & vbCrLf
        sMsg = sMsg & "'AutoSize = False         the size is fixed"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green

    End Sub

    Private Sub ChkEnable_CheckedChanged(sender As Object, e As EventArgs) Handles ChkEnable.CheckedChanged
        LblTest.Enabled = ChkEnable.Checked
        'Set LblTest.Enabled to True or False
        'Enabled = True          Can use tool
        'Enabled = False         Can NOT use tool
        ShowCode() 'Show VB.Net Code
        sMsg = "'Enabled = True           Can use tool" & vbCrLf
        sMsg = sMsg & "'Enabled = False         Can NOT use tool"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub ChkVisible_CheckedChanged(sender As Object, e As EventArgs) Handles ChkVisible.CheckedChanged
        LblTest.Enabled = True
        LblTest.Visible = ChkVisible.Checked
        'Set LblTest.Visible to True or False
        'Visible = True          Tool in visible
        'Visible = False         Tool is NOT visible
        ShowCode() 'Show VB.Net Code
        sMsg = "'Visible = True         Tool in visible" & vbCrLf
        sMsg = sMsg & "'Visible = False        Tool is NOT visible"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub ChkBorder_CheckedChanged(sender As Object, e As EventArgs) Handles ChkBorder.CheckedChanged
        LblTest.Enabled = True
        LblTest.Visible = True
        If ChkBorder.Checked Then
            LblTest.BorderStyle = BorderStyle.FixedSingle
            sBordercode = " LblTest.BorderStyle = BorderStyle.FixedSingle"
            'Add Border to LblTest
            sMsg = "'Add Border to LblTest"
            ShowCode() 'Show VB.Net Code
            RText.Text = sMsg & "   " & vbCrLf & "LblTest.BorderStyle = BorderStyle.FixedSingle"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        Else
            LblTest.BorderStyle = BorderStyle.None
            sBordercode = "LblTest.BorderStyle = BorderStyle.None"
            'Remove Border from LblTest
            sMsg = "'Remove Border from LblTest"
            ShowCode() 'Show VB.Net Code
            RText.Text = sMsg & "   " & vbCrLf & "LblTest.BorderStyle = BorderStyle.None"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
    End Sub

    Private Sub RBReg_CheckedChanged(sender As Object, e As EventArgs) Handles RBReg.CheckedChanged
        LblTest.Font = New Font(LblTest.Font, FontStyle.Regular)
        'Set LblTest.Font to Regular
        sRBcode = "LblTest.Font = New Font(LblTest.Font, FontStyle.Regular)"
        ShowCode() 'Show VB.Net Code
        sMsg = "'FontStyle.Regular"
        sFont = "FontStyle.Regular"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub RBBold_CheckedChanged(sender As Object, e As EventArgs) Handles RBBold.CheckedChanged
        LblTest.Font = New Font(LblTest.Font, FontStyle.Bold)
        'Set LblTest.Font to Bold
        sRBcode = "LblTest.Font = New Font(LblTest.Font, FontStyle.Bold)"
        sMsg = "'FontStyle.Bold"
        sFont = "FontStyle.Bold"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub RBU_CheckedChanged(sender As Object, e As EventArgs) Handles RBU.CheckedChanged
        LblTest.Font = New Font(LblTest.Font, FontStyle.Underline)
        sRBcode = "LblTest.Font = New Font(LblTest.Font, FontStyle.Underline)"
        sMsg = "'FontStyle.Underline"
        sFont = "FontStyle.Underline"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
    Private Sub LblTest_MouseEnter(sender As Object, e As EventArgs) Handles LblTest.MouseEnter
        LblTest.BackColor = Color.LightGreen
        'Make LblTest.BackColor Light Green
        sMsg = "'MouseEnter"
        sFileName = "MouseEnter.txt"
        rFile()
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub LblTest_MouseLeave(sender As Object, e As EventArgs) Handles LblTest.MouseLeave
        LblTest.BackColor = Color.LightCoral
        'Make LblTest.BackColor Light Coral
        sMsg = "'MouseLeave"
        sFileName = "MouseLeave.txt"
        rFile()
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub RBBoldU_CheckedChanged(sender As Object, e As EventArgs) Handles RBBoldU.CheckedChanged
        LblTest.Font = New Font(LblTest.Font, FontStyle.Bold Or FontStyle.Underline)
        'Set LblTest.Font to Underline AND to Bold
        sRBcode = "LblTest.Font = New Font(LblTest.Font,  FontStyle.Bold Or FontStyle.Underline)"
        sMsg = "'FontStyle.Bold Or FontStyle.Underline"
        sFont = "FontStyle.Bold Or FontStyle.Underline"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub RB10_CheckedChanged(sender As Object, e As EventArgs)
        LblTest.Font = New Font("Times New Roman", 10, FontStyle.Regular)
        'Set LblTest.size to 10
    End Sub

    Private Sub TxtText_KeyDown(sender As Object, e As KeyEventArgs) Handles TxtText.KeyDown
        ' Look for enter key
        If e.KeyCode = Keys.Enter Then
            LblTest.Text = TxtText.Text 'Copy Text Box to label
            sMsg = "'Copy Text Box to label" & vbCrLf & "If e.KeyCode = Keys.Enter (Look for Enter key)"
            RText.Text = sMsg & "   " & vbCrLf ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
            RText.Text = RText.Text & "If e.KeyCode = Keys.Enter Then" & vbCrLf
            RText.Text = RText.Text & "      LblTest.Text = TxtText.Text" & vbCrLf
            RText.Text = RText.Text & "End if"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
    End Sub

    Private Sub BTNBAqua_Click(sender As Object, e As EventArgs) Handles BTNBAqua.Click
        LblTest.BackColor = Color.Aqua ' Backgroud Aqua
        sColorBack = "LblTest.BackColor = Color.Aqua"
        ShowCode() 'Show VB.Net Code
        sMsg = "'LblTest.BackColor = Color.Aqua"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BTNBBlue_Click(sender As Object, e As EventArgs) Handles BTNBBlue.Click
        LblTest.BackColor = Color.SteelBlue ' Backgroud Blue
        sColorBack = "LblTest.BackColor = Color.SteelBlue"
        ShowCode() 'Show VB.Net Code
        sMsg = "'LblTest.BackColor = Color.SteelBlue"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BTNBGreen_Click(sender As Object, e As EventArgs) Handles BTNBGreen.Click
        LblTest.BackColor = Color.LightGreen ' Backgroud Green
        sColorBack = "LblTest.BackColor = Color.LightGreen"
        ShowCode() 'Show VB.Net Code
        sMsg = "'LblTest.BackColor = Color.LightGreen"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BTNBOrange_Click(sender As Object, e As EventArgs) Handles BTNBOrange.Click
        LblTest.BackColor = Color.Orange ' Backgroud Orange
        sColorBack = "LblTest.BackColor = Color.Orange"
        ShowCode() 'Show VB.Net Code
        sMsg = "'LblTest.BackColor = Color.Orange"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BTNBRed_Click(sender As Object, e As EventArgs) Handles BTNBRed.Click
        LblTest.BackColor = Color.Red  ' Backgroud Red
        sColorBack = "LblTest.BackColor = Color.Red"
        ShowCode() 'Show VB.Net Code
        sMsg = "'LblTest.BackColor = Color.Red"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BTNFAqua_Click(sender As Object, e As EventArgs) Handles BTNFAqua.Click
        LblTest.ForeColor = Color.Aqua ' Foregroud Aqua (Text)
        sColorFore = "LblTest.ForeColor = Color.Aqua"
        ShowCode() 'Show VB.Net Code
        sMsg = "'LblTest.ForeColor = Color.Aqua   (Text)"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BTNFBlue_Click(sender As Object, e As EventArgs) Handles BTNFBlue.Click
        LblTest.ForeColor = Color.SteelBlue ' Foregroud Blue (Text)
        sColorFore = "LblTest.ForeColor = Color.SteelBlue"
        sMsg = "'LblTest.ForeColor = Color.SteelBlue   (Text)"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BTNFGreen_Click(sender As Object, e As EventArgs) Handles BTNFGreen.Click
        LblTest.ForeColor = Color.LightGreen ' Foregroud Green (Text)
        sColorFore = "LblTest.ForeColor = Color.LightGreen"
        sMsg = "'LblTest.ForeColor = Color.LightGreen   (Text)"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BTNFOrange_Click(sender As Object, e As EventArgs) Handles BTNFOrange.Click
        LblTest.ForeColor = Color.Orange ' Foregroud Orange (Text)
        sColorFore = "LblTest.ForeColor = Color.Orange"
        sMsg = "'LblTest.ForeColor = Color.Orange   (Text)"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BTNFRed_Click(sender As Object, e As EventArgs) Handles BTNFRed.Click
        LblTest.ForeColor = Color.Red ' Foregroud Red (Text)
        sColorFore = "LblTest.ForeColor = Color.Red"
        sMsg = "'LblTest.ForeColor = Color.Red   (Text)"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub RBItalic_CheckedChanged(sender As Object, e As EventArgs) Handles RBItalic.CheckedChanged
        LblTest.Font = New Font(LblTest.Font, FontStyle.Italic)
        'Set LblTest.Font to Italic
        sRBcode = "LblTest.Font = New Font(LblTest.Font, FontStyle.Italic)"
        sMsg = "'FontStyle.Italic"
        sFont = "FontStyle.Italic"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub RBStrike_CheckedChanged(sender As Object, e As EventArgs) Handles RBStrike.CheckedChanged
        LblTest.Font = New Font(LblTest.Font, FontStyle.Strikeout)
        'Set LblTest.Font to Strikeout
        sRBcode = "LblTest.Font = New Font(LblTest.Font, FontStyle.Strikeout)"
        sMsg = "'FontStyle.Strikeout"
        sFont = "FontStyle.Strikeout"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BTNBDefault_Click(sender As Object, e As EventArgs) Handles BTNBDefault.Click
        LblTest.BackColor = DefaultBackColor ' Backgroud Black (Text)
        sColorBack = "LblTest.BackColor = DefaultBackColor"
        ShowCode() 'Show VB.Net Code
        sMsg = "'LblTest.BackColor = DefaultBackColor"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BTNFBlack_Click(sender As Object, e As EventArgs) Handles BTNFBlack.Click
        LblTest.ForeColor = Color.Black ' Foregroud Black (Text)
        sColorFore = "LblTest.ForeColor = Color.Black"
        sMsg = "'LblTest.ForeColor = Color.Black   (Text)"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
    Private Sub ShowCode()
        '  Chr(34) = "
        ' 
        RText.Text = "LblTest.Text = " & Chr(34) & LblTest.Text & Chr(34) & vbCrLf
        RText.Text = RText.Text & "LblTest.AutoSize = " & ChkAuto.Checked & vbCrLf
        RText.Text = RText.Text & "LblTest.Enabled = " & ChkEnable.Checked & vbCrLf
        RText.Text = RText.Text & "LblTest.Visible = " & ChkEnable.Visible & vbCrLf
        RText.Text = RText.Text & sBordercode & vbCrLf
        If CB14.Checked Then
            sFontcode = "LblTest.Font = New Font(" & Chr(34) & "Times New Roman" & Chr(34) & ", 14, " & sFont & ")"
        Else
            sFontcode = "LblTest.Font = New Font(" & Chr(34) & "Times New Roman" & Chr(34) & ", 10, " & sFont & ")"
        End If
        RText.Text = RText.Text & sFontcode & vbCrLf
        ' RText.Text = RText.Text & sRBcode & vbCrLf & sColorBack & vbCrLf
        RText.Text = RText.Text & sColorBack & vbCrLf
        RText.Text = RText.Text & sColorFore
    End Sub

    Private Sub CB10_CheckedChanged(sender As Object, e As EventArgs) Handles CB10.CheckedChanged
        'Set LblTest.size to 10
        If CB10.Checked Then
            CB14.Checked = False
            LblTest.Font = New Font("Times New Roman", 10, FontStyle.Regular)
            sMsg = "'Font = 10"
        Else
            CB14.Checked = True
            LblTest.Font = New Font("Times New Roman", 14, FontStyle.Regular)
            sMsg = "'Font = 14"
        End If
        ShowCode() 'Show VB.Net Code

        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub CB14_CheckedChanged(sender As Object, e As EventArgs) Handles CB14.CheckedChanged
        'Set LblTest.size to 14
        If CB14.Checked Then
            CB10.Checked = False
            LblTest.Font = New Font("Times New Roman", 14, FontStyle.Regular)
            sMsg = "'Font = 14"
        Else
            CB10.Checked = True
            LblTest.Font = New Font("Times New Roman", 10, FontStyle.Regular)
            sMsg = "'Font = 10"
        End If
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub RText_TextChanged(sender As Object, e As EventArgs) Handles RText.TextChanged

    End Sub

    Private Sub LblTest_Click(sender As Object, e As EventArgs) Handles LblTest.Click

    End Sub

    Private Sub RBReg_Click(sender As Object, e As EventArgs) Handles RBReg.Click
        LblTest.Font = New Font(LblTest.Font, FontStyle.Regular)
        'Set LblTest.Font to Regular
        sRBcode = "LblTest.Font = New Font(LblTest.Font, FontStyle.Regular)"
        ShowCode() 'Show VB.Net Code
        sMsg = "'FontStyle.Regular"
        ShowCode() 'Show VB.Net Code
        RText.Text = sMsg & "   " & vbCrLf & RText.Text ' & vbCrLf & sMsg2 & vbCrLf & "FrmSelect.ShowDialog()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
End Class
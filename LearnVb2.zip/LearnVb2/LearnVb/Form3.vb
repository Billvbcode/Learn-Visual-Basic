﻿Public Class Form3
    Dim sFolder As String ' Folder Name
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        pCoin.Parent = Me
        pCoin.BackColor = Color.Transparent
        Dim sMsg As String
        RText.Text = "Me.Hide  "
        sMsg = "'Make Transparent  (Form must have a background)" & vbCrLf
        sMsg = sMsg & "'Can be downloaded from the internet  www.animatedimages.org" & vbCrLf
        sMsg = sMsg & "'pCoin.Parent = Me (Assign the form as the parent)"
        RText.Text = sMsg & "   " & vbCrLf & "pCoin.Parent = Me" & vbCrLf & "pCoin.BackColor = Color.Transparent"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
    Private Sub GetFiles()
        Dim value As String = My.Application.Info.DirectoryPath & "\" & sFolder & "\"
        Dim di As IO.DirectoryInfo = New IO.DirectoryInfo(value)
        '
        ' Read all Jpgs
        '
        ListBox1.Items.Clear()  'Clear ListBox
        Dim diar1 As IO.FileInfo() = di.GetFiles("*.gif")
        Dim dra As IO.FileInfo
        'list the names of all files in the specified directory
        For Each dra In diar1
            ListBox1.Items.Add(dra)
        Next
    End Sub
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim value2 As String = My.Application.Info.DirectoryPath & "\back.jpg"
        Me.BackgroundImage = Image.FromFile(value2)
        sFolder = "gif"
        Dim value As String = My.Application.Info.DirectoryPath & "\" & sFolder & "\"
        pCoin.Image = Image.FromFile(value & "coin.gif")
        PictureBox2.Image = Image.FromFile(value & "coin.gif")
        GetFiles()
    End Sub

    Private Sub ListBox1_Click(sender As Object, e As EventArgs) Handles ListBox1.Click
        'Load Picture from file
        Dim value As String = My.Application.Info.DirectoryPath & "\" & sFolder & "\"
        pCoin.Image = Image.FromFile(value & ListBox1.Text)
        PictureBox2.Image = Image.FromFile(value & ListBox1.Text)
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub
End Class
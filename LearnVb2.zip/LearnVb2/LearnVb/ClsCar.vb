﻿Public Class ClsCar
    Dim strMfg As String
    Dim IntYear As Integer
    Dim bMoonRoof As Boolean
    Public Property MoonRoof() As Boolean     'Store Car MoonRoof
        Get
            Return bMoonRoof
        End Get
        Set(ByVal Value As Boolean)
            bMoonRoof = Value
        End Set
    End Property
    Public Property Year() As Integer     'Store Car Year
        Get
            Return IntYear
        End Get
        Set(ByVal Value As Integer)
            IntYear = Value
        End Set
    End Property
    Public Property Mfg() As String     'Store Car Mfg
        Get
            Return strMfg
        End Get
        Set(ByVal Value As String)
            strMfg = Value
        End Set
    End Property
    ' Set default values
    Public Sub New()
        bMoonRoof = False
        strMfg = "Default"
        Year = "2012"
    End Sub
End Class

﻿Public Class Form2
    Dim sMsg As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        PicHog.BringToFront()
        sMsg = "'Bring hog to Front"
        RText.Text = sMsg & "   " & vbCrLf & " PicHog.BringToFront()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        PicHog.SendToBack()
        sMsg = "'Send hog to Back"
        RText.Text = sMsg & "   " & vbCrLf & "PicHog.SendToBack()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
End Class
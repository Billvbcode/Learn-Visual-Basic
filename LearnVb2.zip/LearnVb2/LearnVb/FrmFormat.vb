﻿Public Class FrmFormat
    Dim iDat As Date
    Dim sMsg As String
    Private Sub FrmFormat_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox1.Items.Clear()
        ListBox1.Items.Add("Format(1872.253, " & Chr(34) & "General Number" & Chr(34) & ") No separators. ")
        ListBox1.Items.Add("Format(1872.263, " & Chr(34) & "Fixed" & Chr(34) & ") No separators & rounds to two decimal places. ")
        ListBox1.Items.Add("Format(1872.273, " & Chr(34) & "Standard" & Chr(34) & ") Has separators & rounds to two decimal places. ")
        ListBox1.Items.Add("Format(1425.25, " & Chr(34) & "Currency" & Chr(34) & ") $ and Has separators & rounds to two decimal places.")
        ListBox1.Items.Add("Format(0.56, " & Chr(34) & "Percent" & Chr(34) & ") Converts to the percentage and displays a % sign ")
        '  ListBox1.Items.Add("Format(872.2, " & Chr(34) & "Standard" & Chr(34) & ") Has separators & rounds to two decimal places. ")
        '  ListBox1.Items.Add("Format(872.2, " & Chr(34) & "Fixed" & Chr(34) & ") No separators & rounds to two decimal places.")
        '
        ListBox1.Items.Add("NOTE: use # as a place holder for spaces of digits  ")
        ListBox1.Items.Add("NOTE: use 0 to add leading zeros ")
        ListBox1.Items.Add("Format(72.234, " & Chr(34) & "0" & Chr(34) & ") No separators Rounds to Whole #. ")
        ListBox1.Items.Add("Format(72.234, " & Chr(34) & "0000" & Chr(34) & ") Add Leading Zeros No separators Rounds to Whole #. ")
        ListBox1.Items.Add("Format(167972.234, " & Chr(34) & "#,###,##0" & Chr(34) & ") Has separators Rounds to Whole #. ")
        ListBox1.Items.Add("Format(167972.234, " & Chr(34) & "#,###,##0.00" & Chr(34) & ") Has separators & rounds to two decimal places. ")
        ListBox1.Items.Add("Format(1425.25, " & Chr(34) & "$##,##0.00" & Chr(34) & ") $ and Has separators & rounds to two decimal places.")
        ListBox1.Items.Add("Format(Now , " & Chr(34) & "General Date" & Chr(34) & ") 23/10/2014  11:38:45 ")
        ListBox1.Items.Add("Format(Now , " & Chr(34) & "Long Date" & Chr(34) & ") Tuesday, July 28, 2020 ")
        ListBox1.Items.Add("Format(Now , " & Chr(34) & "Short Date" & Chr(34) & ") 23/10/2014 ")
        ''
        '  ListBox1.Items.Add("Format(Now , " & Chr(34) & "M" & Chr(34) & ") month and day")
        ListBox1.Items.Add("NOTE: Upper case M is month  ")
        ListBox1.Items.Add("NOTE: Lower case m is minute  ")
        ListBox1.Items.Add("Format(Now , " & Chr(34) & "MM" & Chr(34) & ") 2 digit month ")
        ListBox1.Items.Add("Format(Now , " & Chr(34) & "MMM" & Chr(34) & ") 3 letter month ")
        ListBox1.Items.Add("Format(Now , " & Chr(34) & "MMMM" & Chr(34) & ") Spell month")
        ListBox1.Items.Add("Format(Now , " & Chr(34) & "MM/dd/yyyy" & Chr(34) & ") Mth Day Year ")
        ListBox1.Items.Add("Format(Now , " & Chr(34) & "MM/dd/yy" & Chr(34) & ") Mth Day 2 digit Year ")
        ListBox1.Items.Add("Format(Now , " & Chr(34) & "MMM/dd/yy" & Chr(34) & ") 3 letter Mth Day 2 digit Year ")
        ListBox1.Items.Add("Format(Now , " & Chr(34) & "MMM dd yy" & Chr(34) & ") NoSlash 3 letter Mth Day 2 digit Year ")
        ListBox1.Items.Add("Format(Now , " & Chr(34) & "h:mm:ss" & Chr(34) & ") Hrs Min Sec ")
        ListBox1.Items.Add("Format(Now , " & Chr(34) & "h:mm:ss.ffff" & Chr(34) & ") Hrs Min Sec Miliseconds ")
        LblResult.Text = ""
    End Sub

    Private Sub ListBox1_Click(sender As Object, e As EventArgs) Handles ListBox1.Click
        Dim i As Integer
        i = InStr(1, ListBox1.Text, "NOTE")
        If i > 0 Then Exit Sub
        i = InStr(1, ListBox1.Text, "MMM dd yy")
        If i > 0 Then
            LblResult.Text = Format(Now, "MMM dd yy")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "MMM dd yy" & Chr(34) & ")  "
            sMsg = "'Format(Now , " & Chr(34) & "MMM dd yy" & Chr(34) & ") NoSlash 3 letter Mth Day 2 digit Year"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, "MMM/dd/yy")
        If i > 0 Then
            LblResult.Text = Format(Now, "MMM/dd/yy")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "MMM/dd/yy" & Chr(34) & ")  "
            sMsg = "'Format(Now , " & Chr(34) & "MMM/dd/yy" & Chr(34) & ") 3 letter Mth Day 2 digit Year"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, "Percent")
        If i > 0 Then
            LblResult.Text = Format(0.56, "Percent")
            RText.Text = "LblResult.Text = Format(0.56 , " & Chr(34) & "Percent" & Chr(34) & ")  "
            sMsg = "'Format(0.56, " & Chr(34) & "Percent" & Chr(34) & ") Converts to the percentage and displays a % sign."
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, "Currency")
        If i > 0 Then
            LblResult.Text = Format(1425.25, "Currency")
            RText.Text = "LblResult.Text = Format(1425.25 , " & Chr(34) & "Currency" & Chr(34) & ")  "
            sMsg = "'Format(1425.25, " & Chr(34) & "$##,##0.00" & Chr(34) & ") $ and Has separators & rounds to two decimal places."
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, "$##,##0.00")
        If i > 0 Then
            LblResult.Text = Format(1425.25, "$##,##0.00")
            RText.Text = "LblResult.Text = Format(1425.25 , " & Chr(34) & "$##,##0.00" & Chr(34) & ")  "
            sMsg = "'Format(1425.25, " & Chr(34) & "$##,##0.00" & Chr(34) & ") $ and Has separators & rounds to two decimal places."
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If

        i = InStr(1, ListBox1.Text, "#,###,##0.00")
        If i > 0 Then
            LblResult.Text = Format(167972.234, "#,###,##0.00")
            RText.Text = "LblResult.Text = Format(167972.234 , " & Chr(34) & "#,###,##0.00" & Chr(34) & ")  "
            sMsg = "'Format(167972.234 , " & Chr(34) & "0000" & Chr(34) & ") Has separators & rounds to two decimal places."
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, "#,###,##0")
        If i > 0 Then
            LblResult.Text = Format(167972.234, "#,###,##0")
            RText.Text = "LblResult.Text = Format(167972.234 , " & Chr(34) & "#,###,##0" & Chr(34) & ")  "
            sMsg = "'Format(167972.234 , " & Chr(34) & "0000" & Chr(34) & ") Has separators Rounds to Whole #."
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, "0000")
        If i > 0 Then
            LblResult.Text = Format(72.234, "0000")
            RText.Text = "LblResult.Text = Format(72.234 , " & Chr(34) & "0000" & Chr(34) & ")  "
            sMsg = "'Format(72.25 , " & Chr(34) & "0000" & Chr(34) & ") Add Leading Zeros  No separators & rounds to two decimal places."
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, Chr(34) & "0" & Chr(34))
        If i > 0 Then
            LblResult.Text = Format(72.234, "0")
            RText.Text = "LblResult.Text = Format(72.234 , " & Chr(34) & "0" & Chr(34) & ")  "
            sMsg = "'Format(72.234 , " & Chr(34) & "0" & Chr(34) & ") No separators Rounds to Whole #."
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        i = InStr(1, ListBox1.Text, "NOTE")
        If i > 0 Then Exit Sub
        i = InStr(1, ListBox1.Text, "Fixed")
        If i > 0 Then
            LblResult.Text = Format(1872.253, "Fixed")
            RText.Text = "LblResult.Text = Format(1872.253 , " & Chr(34) & "Fixed" & Chr(34) & ")  "
            sMsg = "'Format(1872.253 , " & Chr(34) & "Fixed" & Chr(34) & ") No separators & rounds to two decimal places."
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, "Standard")
        If i > 0 Then
            LblResult.Text = Format(1872.253, "Standard")
            RText.Text = "LblResult.Text = Format(1872.253 , " & Chr(34) & "Standard" & Chr(34) & ")  "
            sMsg = "'Format(1872.253 , " & Chr(34) & "Standard" & Chr(34) & ") Has separators & rounds to two decimal places. "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, "General Number")
        If i > 0 Then
            LblResult.Text = Format(1872.253, "General Number")
            RText.Text = "LblResult.Text = Format(1872.253 , " & Chr(34) & "General Number" & Chr(34) & ")  "
            sMsg = "'Format(1872.253 , " & Chr(34) & "General Number" & Chr(34) & ") No separators."
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, "h:mm:ss.ff")
        If i > 0 Then
            LblResult.Text = Format(Now, "h:mm:ss.ffff")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "h:mm:ss.ffff" & Chr(34) & ")  "
            sMsg = "'Format(Now , " & Chr(34) & "h:mm:ss.ffff" & Chr(34) & ") Hrs Min Sec    Lower case m is minute "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, "h:mm:ss")
        If i > 0 Then
            LblResult.Text = Format(Now, "h:mm:ss")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "h:mm:ss" & Chr(34) & ")  "
            sMsg = "'Format(Now , " & Chr(34) & "h:mm:ss" & Chr(34) & ") Hrs Min Sec    Lower case m is minute "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, "MM/dd/yyyy")
        If i > 0 Then
            LblResult.Text = Format(Now, "MM/dd/yyyy")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "MM/dd/yyyy" & Chr(34) & ")  "
            sMsg = "'Format(Now , " & Chr(34) & "MM/dd/yyyy" & Chr(34) & ") Mth Day Year"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, "MM/dd/yy")
        If i > 0 Then
            LblResult.Text = Format(Now, "MM/dd/yy")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "MM/dd/yy" & Chr(34) & ")  "
            sMsg = "'Format(Now , " & Chr(34) & "MM/dd/yy" & Chr(34) & ") Mth Day 2 digit Year"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If

        i = InStr(1, ListBox1.Text, Chr(34) & "MMMM" & Chr(34))
        If i > 0 Then
            LblResult.Text = Format(Now, "MMMM")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "MMMM" & Chr(34) & ")  "
            sMsg = "'Format(Now , " & Chr(34) & "MMMM" & Chr(34) & ") Spell Month   Upper case M is month"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, Chr(34) & "MM" & Chr(34))
        If i > 0 Then
            LblResult.Text = Format(Now, "MM")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "MM" & Chr(34) & ")  "
            sMsg = "'Format(Now , " & Chr(34) & "MM" & Chr(34) & ") 2 digit month   Upper case M is month"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        i = InStr(1, ListBox1.Text, Chr(34) & "MMM" & Chr(34))
        If i > 0 Then
            LblResult.Text = Format(Now, "MMM")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "MMM" & Chr(34) & ")  "
            sMsg = "'Format(Now , " & Chr(34) & "MMM" & Chr(34) & ") Short month   Upper case M is month "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            TextBox1.Text = LblResult.Text
            Exit Sub
        End If
        i = InStr(1, ListBox1.Text, Chr(34) & "M" & Chr(34))
        If i > 0 Then
            LblResult.Text = Format(Now, "M")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "M" & Chr(34) & ")  "
            sMsg = "'Format(Now , " & Chr(34) & "M" & Chr(34) & ") month "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        i = InStr(1, ListBox1.Text, "General Date")
        If i > 0 Then
            LblResult.Text = Format(Now, "General Date")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "General Date" & Chr(34) & ")  "
            sMsg = "'Format(Now , " & Chr(34) & "General Date" & Chr(34) & ") 23/10/2014  11:38:45"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        i = InStr(1, ListBox1.Text, "Long")
        If i > 0 Then
            LblResult.Text = Format(Now, "Long Date")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "Long Date" & Chr(34) & ")  "
            sMsg = "'Format(Now , " & Chr(34) & "Long Date" & Chr(34) & ") Tuesday, July 28, 2020 "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        i = InStr(1, ListBox1.Text, "Short")
        If i > 0 Then
            LblResult.Text = Format(Now, "Short Date")
            RText.Text = "LblResult.Text = Format(Now , " & Chr(34) & "Short Date" & Chr(34) & ") 23/10/2014 "
            sMsg = "'Format(Now , " & Chr(34) & "Short Date" & Chr(34) & ")  "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        TextBox1.Text = LblResult.Text
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub RText_TextChanged(sender As Object, e As EventArgs) Handles RText.TextChanged

    End Sub


End Class
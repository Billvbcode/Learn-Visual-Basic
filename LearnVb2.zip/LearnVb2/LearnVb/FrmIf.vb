﻿Public Class FrmIf
    Dim sFileName As String
    Dim sMsg As String

    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub FrmIf_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox1.Items.Clear()
        ListBox1.Items.Add("A = B     Equal  ")
        ListBox1.Items.Add("A = D     Equal  ")
        ListBox1.Items.Add("B = C     Equal  ")
        ListBox1.Items.Add("C = D     Equal  ")
        ListBox1.Items.Add("C <> D    Not Equal	")
        ListBox1.Items.Add("C <> B    Not Equal	")
        ListBox1.Items.Add("A > B     Greater Than  ")
        ListBox1.Items.Add("C > D     Greater Than  ")
        ListBox1.Items.Add("A < B     Less Than      ")
        ListBox1.Items.Add("C < D     Less Than      ")
        ListBox1.Items.Add("A >= B    Greater Than or Equal	")
        ListBox1.Items.Add("C >= D    Greater Than or Equal	")
        ListBox1.Items.Add("A <= B    Less Than or Equal ")
        ListBox1.Items.Add("C <= D    Less Than or Equal ")
        ListBox1.Items.Add("AND 1    Both True ")
        ListBox1.Items.Add("AND 2    Both True ")
        ListBox1.Items.Add("OR 1    One or Other true    ")
        ListBox1.Items.Add("OR 2    One or Other true    ")
        ListBox2.Items.Clear()
        ListBox2.Items.Add("NOTE: Both the Select and ")
        ListBox2.Items.Add("NOTE: ElseIf give the same results")
        ListBox2.Items.Add("Select A")
        ListBox2.Items.Add("Select C")
        ListBox2.Items.Add("Select E")
        ListBox2.Items.Add("ElseIf A")
        ListBox2.Items.Add("ElseIf C")
        ListBox2.Items.Add("ElseIf E")
        TxtA.Text = 3
        TxtB.Text = 5
        TxtC.Text = 5
        TxtD.Text = 3
        TxtE.Text = 6
    End Sub

    Private Sub ListBox1_Click(sender As Object, e As EventArgs) Handles ListBox1.Click
        If Mid(ListBox1.Text, 1, 4) = "OR 2" Then
            LblCode2.Text = "If " & TxtA.Text & " =  " & TxtB.Text
            LblCode2.Text = LblCode2.Text & " Or " & TxtC.Text & " =  " & TxtD.Text
            If Val(TxtA.Text) = Val(TxtB.Text) _
                Or Val(TxtC.Text) = Val(TxtD.Text) Then
                LblResult.Text = "One or Both True"
            Else
                LblResult.Text = "Both False"
            End If
            RText.Text = " If Val(TxtA.Text) = Val(TxtB.Text) _" & vbCrLf
            RText.Text = RText.Text & "  Or Val(TxtC.Text) = Val(TxtD.Text) Then" & Chr(34) & " Or " & Chr(34) & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "One or Both True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "Both False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 5) = "AND 1" Then
            LblCode2.Text = "If " & TxtA.Text & " =  " & TxtB.Text
            LblCode2.Text = LblCode2.Text & " And " & TxtA.Text & " =  " & TxtD.Text
            If Val(TxtA.Text) = Val(TxtB.Text) _
                And Val(TxtA.Text) = Val(TxtD.Text) Then
                LblResult.Text = "Both True"
            Else
                LblResult.Text = "Both False"
            End If
            RText.Text = "If Val(TxtA.Text) = Val(TxtB.Text) _" & vbCrLf
            RText.Text = RText.Text & "   And Val(TxtA.Text) = Val(TxtD.Text) Then" & vbCrLf '& " Both True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "Both True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "One or Other or Both False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 5) = "AND 2" Then
            LblCode2.Text = "If " & TxtB.Text & " =  " & TxtC.Text
            LblCode2.Text = LblCode2.Text & " And " & TxtA.Text & " =  " & TxtD.Text
            If Val(TxtB.Text) = Val(TxtC.Text) _
                And Val(TxtA.Text) = Val(TxtD.Text) Then
                LblResult.Text = "Both True"
            Else
                LblResult.Text = "Both False"
            End If
            RText.Text = "If Val(TxtB.Text) = Val(TxtC.Text) _" & vbCrLf
            RText.Text = RText.Text & "   And Val(TxtA.Text) = Val(TxtD.Text) Then" & vbCrLf '& " Both True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "Both True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "One or Other or Both False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 4) = "OR 1" Then
            LblCode2.Text = "If " & TxtA.Text & " =  " & TxtB.Text
            LblCode2.Text = LblCode2.Text & " Or " & TxtA.Text & " =  " & TxtD.Text
            If Val(TxtA.Text) = Val(TxtB.Text) _
                Or Val(TxtA.Text) = Val(TxtD.Text) Then
                LblResult.Text = "One or Both True"
            Else
                LblResult.Text = "Both False"
            End If
            RText.Text = " If Val(TxtA.Text) = Val(TxtB.Text) _" & vbCrLf
            RText.Text = RText.Text & "   Or Val(TxtA.Text) = Val(TxtD.Text) Then" & Chr(34) & " Or " & Chr(34) & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "One or Both True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "Both False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 6) = "C <= D" Then
            LblCode2.Text = "If " & TxtC.Text & " <=  " & TxtD.Text
            If Val(TxtC.Text) <= Val(TxtD.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtC.Text) <= Val(TxtD.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 6) = "A <= B" Then
            LblCode2.Text = "If " & TxtA.Text & " <=  " & TxtB.Text
            If Val(TxtA.Text) <= Val(TxtB.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtA.Text) <= Val(TxtB.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        '
        If Mid(ListBox1.Text, 1, 6) = "C >= D" Then
            LblCode2.Text = "If " & TxtC.Text & " >=  " & TxtD.Text
            If Val(TxtC.Text) >= Val(TxtD.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtC.Text) >= Val(TxtD.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 6) = "A >= B" Then
            LblCode2.Text = "If " & TxtA.Text & " >=  " & TxtB.Text
            If Val(TxtA.Text) >= Val(TxtB.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtA.Text) >= Val(TxtB.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 5) = "A < B" Then
            LblCode2.Text = "If " & TxtA.Text & " <  " & TxtB.Text
            If Val(TxtA.Text) < Val(TxtB.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtA.Text) < Val(TxtB.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 5) = "C < D" Then
            LblCode2.Text = "If " & TxtC.Text & " <  " & TxtD.Text
            If Val(TxtC.Text) < Val(TxtD.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtC.Text) > Val(TxtD.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 5) = "A > B" Then
            LblCode2.Text = "If " & TxtA.Text & " >  " & TxtB.Text
            If Val(TxtA.Text) > Val(TxtB.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtA.Text) > Val(TxtB.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 5) = "C > D" Then
            LblCode2.Text = "If " & TxtC.Text & " >  " & TxtD.Text
            If Val(TxtC.Text) > Val(TxtD.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtC.Text) > Val(TxtD.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 5) = "C = D" Then
            LblCode2.Text = "If " & TxtC.Text & " =  " & TxtD.Text
            If Val(TxtC.Text) = Val(TxtD.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtC.Text) = Val(TxtD.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If

        '
        If Mid(ListBox1.Text, 1, 5) = "A = B" Then
            LblCode2.Text = "If " & TxtA.Text & " =  " & TxtB.Text
            If Val(TxtA.Text) = Val(TxtB.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtA.Text) = Val(TxtB.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 5) = "B = C" Then
            LblCode2.Text = "If " & TxtB.Text & " =  " & TxtC.Text
            If Val(TxtB.Text) = Val(TxtC.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtB.Text) = Val(TxtC.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 5) = "A = D" Then
            LblCode2.Text = "If " & TxtA.Text & " =  " & TxtD.Text
            If Val(TxtA.Text) = Val(TxtD.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtA.Text) = Val(TxtD.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 6) = "C <> D" Then
            LblCode2.Text = "If " & TxtC.Text & " <>  " & TxtD.Text
            If Val(TxtC.Text) <> Val(TxtD.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtC.Text) <> Val(TxtD.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
        If Mid(ListBox1.Text, 1, 6) = "C <> B" Then
            LblCode2.Text = "If " & TxtC.Text & " <>  " & TxtB.Text
            If Val(TxtC.Text) <> Val(TxtB.Text) Then
                LblResult.Text = "True"
            Else
                LblResult.Text = "False"
            End If
            RText.Text = "If Val(TxtC.Text) <> Val(TxtB.Text) Then" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "True" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "Else" & vbCrLf
            RText.Text = RText.Text & "    LblLenR.Text = " & Chr(34) & "False" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "End If"
        End If
    End Sub

    Private Sub ListBox2_Click(sender As Object, e As EventArgs) Handles ListBox2.Click
        LblCode2.Text = ""
        If ListBox2.Text = "Select A" Then
            Select Case Val(TxtA.Text)
                Case 3
                    LblResult.Text = "A = 3"
                Case 5
                    LblResult.Text = "A = 5"
                Case Else
                    LblResult.Text = "A = Case Else"
            End Select
            sFileName = "selecta.txt"
            rFile()
        End If
        If ListBox2.Text = "Select C" Then
            Select Case Val(TxtC.Text)
                Case 3
                    LblResult.Text = "C = 3"
                Case 5
                    LblResult.Text = "C = 5"
                Case Else
                    LblResult.Text = "C = Case Else"
            End Select
            sFileName = "selectc.txt"
            rFile()
        End If
        If ListBox2.Text = "Select E" Then
            Select Case Val(TxtE.Text)
                Case 3
                    LblResult.Text = "E = 3"
                Case 5
                    LblResult.Text = "E = 5"
                Case Else
                    LblResult.Text = "E = Case Else"
            End Select
            sFileName = "selectE.txt"
            rFile()
        End If
        '
        If ListBox2.Text = "ElseIf A" Then
            If Val(TxtA.Text) = 3 Then
                LblResult.Text = "A = 3"
            ElseIf Val(TxtA.Text) = 5 Then
                LblResult.Text = "A = 5"
            Else
                LblResult.Text = "A = Case Else"
            End If
            sFileName = "ElseIfa.txt"
            rFile()
        End If
        '
        If ListBox2.Text = "ElseIf C" Then
            If Val(TxtC.Text) = 3 Then
                LblResult.Text = "C = 3"
            ElseIf Val(Txtc.Text) = 5 Then
                LblResult.Text = "C = 5"
            Else
                LblResult.Text = "C = Case Else"
            End If
            sFileName = "ElseIfC.txt"
            rFile()
        End If
        If ListBox2.Text = "ElseIf E" Then
            If Val(TxtE.Text) = 3 Then
                LblResult.Text = "E = 3"
            ElseIf Val(TxtE.Text) = 5 Then
                LblResult.Text = "E = 5"
            Else
                LblResult.Text = "E = Case Else"
            End If
            sFileName = "ElseIfE.txt"
            rFile()
        End If
    End Sub

    Private Sub ListBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox2.SelectedIndexChanged

    End Sub
End Class
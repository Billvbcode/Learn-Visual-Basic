﻿Public Class FrmFile
    Dim sFileName As String
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub FrmFile_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '
        ' Read Drive Names
        '
        For Each di As IO.DriveInfo In IO.DriveInfo.GetDrives
            DriveList.Items.Add(di)
        Next
        Button1.Enabled = False
        sFileName = "search.txt"
        rFile()
    End Sub

    Private Sub FolderList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles FolderList.SelectedIndexChanged
        ' FolderList.Items.Clear()

    End Sub

    Private Sub DriveList_Click(sender As Object, e As EventArgs) Handles DriveList.Click
        Dim drive As IO.DriveInfo
        FolderList.Items.Clear()
        drive = DirectCast(DriveList.SelectedItem, IO.DriveInfo)
        '
        ' Read Directory Names
        '
        Try
            For Each dirInfo As IO.DirectoryInfo In drive.RootDirectory.GetDirectories
                If UCase(Mid(dirInfo.ToString, 1, 1)) >= "A" Then FolderList.Items.Add(dirInfo)
            Next
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FolderList_Click(sender As Object, e As EventArgs) Handles FolderList.Click
        Dim sMsg As String
        sMsg = DriveList.Text & FolderList.Text '""
        'Next
        Dim di As IO.DirectoryInfo = New IO.DirectoryInfo(DriveList.Text & FolderList.Text)
        '
        ' Read all the Files
        '
        FileList.Items.Clear() 'Clear ListBox
        Dim diar1 As IO.FileInfo() = di.GetFiles()
        Dim dra As IO.FileInfo
        'list the names of all files in the specified directory
        For Each dra In diar1
            FileList.Items.Add(dra)
        Next
        '
        ' Read all the Directories
        '
        SubFolderList.Items.Clear()
        Dim dra2 As IO.DirectoryInfo
        'list the names of all files in the specified directory
        For Each dra2 In di.GetDirectories
            SubFolderList.Items.Add(dra2)
        Next
        LblSubFolders.Text = DriveList.Text & FolderList.Text
        LblFile.Text = DriveList.Text & FolderList.Text
        Button1.Enabled = False
    End Sub

    Private Sub FileList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles FileList.SelectedIndexChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim di As IO.DirectoryInfo = New IO.DirectoryInfo(DriveList.Text & FolderList.Text)
        '
        ' Read all the Files
        '
        FileList.Items.Clear() 'Clear ListBox
        Dim diar1 As IO.FileInfo() = di.GetFiles()
        Dim dra As IO.FileInfo
        'list the names of all files in the specified directory
        For Each dra In diar1
            FileList.Items.Add(dra)
        Next
        '
        ' Read all the Directories
        '
        SubFolderList.Items.Clear()
        Dim dra2 As IO.DirectoryInfo
        'list the names of all files in the specified directory
        For Each dra2 In di.GetDirectories
            SubFolderList.Items.Add(dra2)
        Next
        LblSubFolders.Text = DriveList.Text & FolderList.Text
        LblFile.Text = DriveList.Text & FolderList.Text
        Button1.Enabled = False
    End Sub

    Private Sub SubFolderList_Click(sender As Object, e As EventArgs) Handles SubFolderList.Click
        ' 
        ' File Sub Directory
        '
        LblSubFolders.Text = LblSubFolders.Text & "\" & SubFolderList.Text
        Dim di As IO.DirectoryInfo = New IO.DirectoryInfo(LblSubFolders.Text)
        '
        ' Read all the Files
        '
        FileList.Items.Clear() 'Clear ListBox
        Dim diar1 As IO.FileInfo() = di.GetFiles()
        Dim dra As IO.FileInfo
        'list the names of all files in the specified directory
        For Each dra In diar1
            FileList.Items.Add(dra)
        Next
        '
        ' Read all the Directories
        '
        SubFolderList.Items.Clear()
        Dim dra2 As IO.DirectoryInfo
        'list the names of all files in the specified directory
        For Each dra2 In di.GetDirectories
            SubFolderList.Items.Add(dra2)
        Next
        ' LblSubFolders.Text = DriveList.Text & FolderList.Text
        LblFile.Text = LblSubFolders.Text
        Button1.Enabled = True
    End Sub

End Class
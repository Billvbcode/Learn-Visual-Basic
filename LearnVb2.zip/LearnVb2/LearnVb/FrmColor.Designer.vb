﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmColor
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.HSRed = New System.Windows.Forms.HScrollBar()
        Me.HSGreen = New System.Windows.Forms.HScrollBar()
        Me.HSBlue = New System.Windows.Forms.HScrollBar()
        Me.LblRed = New System.Windows.Forms.Label()
        Me.LblGreen = New System.Windows.Forms.Label()
        Me.LblBlue = New System.Windows.Forms.Label()
        Me.LblColor = New System.Windows.Forms.Label()
        Me.BtnSignL = New System.Windows.Forms.Button()
        Me.LblMarquee = New System.Windows.Forms.Label()
        Me.TimSign = New System.Windows.Forms.Timer(Me.components)
        Me.RText = New System.Windows.Forms.RichTextBox()
        Me.LblCode = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'HSRed
        '
        Me.HSRed.Location = New System.Drawing.Point(21, 56)
        Me.HSRed.Maximum = 264
        Me.HSRed.Name = "HSRed"
        Me.HSRed.Size = New System.Drawing.Size(307, 45)
        Me.HSRed.TabIndex = 1
        '
        'HSGreen
        '
        Me.HSGreen.Location = New System.Drawing.Point(21, 131)
        Me.HSGreen.Maximum = 264
        Me.HSGreen.Name = "HSGreen"
        Me.HSGreen.Size = New System.Drawing.Size(307, 45)
        Me.HSGreen.TabIndex = 2
        '
        'HSBlue
        '
        Me.HSBlue.Location = New System.Drawing.Point(21, 204)
        Me.HSBlue.Maximum = 264
        Me.HSBlue.Name = "HSBlue"
        Me.HSBlue.Size = New System.Drawing.Size(307, 45)
        Me.HSBlue.TabIndex = 3
        '
        'LblRed
        '
        Me.LblRed.AutoSize = True
        Me.LblRed.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblRed.Location = New System.Drawing.Point(390, 68)
        Me.LblRed.Name = "LblRed"
        Me.LblRed.Size = New System.Drawing.Size(19, 20)
        Me.LblRed.TabIndex = 4
        Me.LblRed.Text = "0"
        '
        'LblGreen
        '
        Me.LblGreen.AutoSize = True
        Me.LblGreen.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblGreen.Location = New System.Drawing.Point(390, 150)
        Me.LblGreen.Name = "LblGreen"
        Me.LblGreen.Size = New System.Drawing.Size(19, 20)
        Me.LblGreen.TabIndex = 5
        Me.LblGreen.Text = "0"
        '
        'LblBlue
        '
        Me.LblBlue.AutoSize = True
        Me.LblBlue.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblBlue.Location = New System.Drawing.Point(390, 217)
        Me.LblBlue.Name = "LblBlue"
        Me.LblBlue.Size = New System.Drawing.Size(19, 20)
        Me.LblBlue.TabIndex = 6
        Me.LblBlue.Text = "0"
        '
        'LblColor
        '
        Me.LblColor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblColor.Location = New System.Drawing.Point(572, 97)
        Me.LblColor.Name = "LblColor"
        Me.LblColor.Size = New System.Drawing.Size(129, 133)
        Me.LblColor.TabIndex = 7
        Me.LblColor.Text = "Color"
        '
        'BtnSignL
        '
        Me.BtnSignL.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSignL.Location = New System.Drawing.Point(39, 277)
        Me.BtnSignL.Name = "BtnSignL"
        Me.BtnSignL.Size = New System.Drawing.Size(192, 34)
        Me.BtnSignL.TabIndex = 9
        Me.BtnSignL.Text = "Marquee"
        Me.BtnSignL.UseVisualStyleBackColor = True
        '
        'LblMarquee
        '
        Me.LblMarquee.AutoSize = True
        Me.LblMarquee.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblMarquee.Location = New System.Drawing.Point(306, 284)
        Me.LblMarquee.Name = "LblMarquee"
        Me.LblMarquee.Size = New System.Drawing.Size(235, 20)
        Me.LblMarquee.TabIndex = 10
        Me.LblMarquee.Text = "Hope you have a great day…."
        '
        'TimSign
        '
        Me.TimSign.Interval = 200
        '
        'RText
        '
        Me.RText.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RText.Location = New System.Drawing.Point(12, 372)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(741, 234)
        Me.RText.TabIndex = 11
        Me.RText.Text = ""
        '
        'LblCode
        '
        Me.LblCode.AutoSize = True
        Me.LblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCode.Location = New System.Drawing.Point(46, 338)
        Me.LblCode.Name = "LblCode"
        Me.LblCode.Size = New System.Drawing.Size(51, 20)
        Me.LblCode.TabIndex = 32
        Me.LblCode.Text = "Code"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(243, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(243, 20)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Mouse Over To Change Color"
        '
        'FrmColor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 605)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.LblCode)
        Me.Controls.Add(Me.RText)
        Me.Controls.Add(Me.LblMarquee)
        Me.Controls.Add(Me.BtnSignL)
        Me.Controls.Add(Me.LblColor)
        Me.Controls.Add(Me.LblBlue)
        Me.Controls.Add(Me.LblGreen)
        Me.Controls.Add(Me.LblRed)
        Me.Controls.Add(Me.HSBlue)
        Me.Controls.Add(Me.HSGreen)
        Me.Controls.Add(Me.HSRed)
        Me.Name = "FrmColor"
        Me.Text = "Color"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents HSRed As HScrollBar
    Friend WithEvents HSGreen As HScrollBar
    Friend WithEvents HSBlue As HScrollBar
    Friend WithEvents LblRed As Label
    Friend WithEvents LblGreen As Label
    Friend WithEvents LblBlue As Label
    Friend WithEvents LblColor As Label
    Friend WithEvents BtnSignL As Button
    Friend WithEvents LblMarquee As Label
    Friend WithEvents TimSign As Timer
    Friend WithEvents RText As RichTextBox
    Friend WithEvents LblCode As Label
    Friend WithEvents Label1 As Label
End Class

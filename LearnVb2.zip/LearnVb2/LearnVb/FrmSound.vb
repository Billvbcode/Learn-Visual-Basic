﻿Imports System.Speech
Imports System.Speech.Synthesis

Public Class FrmSound
    Dim sFileName As String
    Dim sMsg As String
    Dim speaker As New SpeechSynthesizer

    Private Sub FrmSound_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub

    Private Sub BtnTextToSpeech_Click(sender As Object, e As EventArgs) Handles BtnTextToSpeech.Click
        RText.Width = 680
        sFileName = "TextToSpeech.txt"
        rFile()
        Lblname.Text = "TextToSpeech"
        speaker.SpeakAsync(TxtSay.Text) 'Talk
        sMsg = "'1.	Click on PROJECT and then ADD REFERENCE" & vbCrLf
        sMsg = sMsg & "'2.	Under ASSEMBLY Click on FRAMEWORK" & vbCrLf
        sMsg = sMsg & "'3.  Check SYSTEM SPEECH" & vbCrLf
        sMsg = sMsg & "'4.  Then Press OK"

        RText.Text = sMsg & "     " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        'Load Picture from file
        Dim value As String = My.Application.Info.DirectoryPath & "\"
        PictureBox1.Visible = True
        PictureBox1.Image = Image.FromFile(value & "a1.jpg")
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
    End Sub

    Private Sub FrmSound_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        speaker.Dispose()  ' Dispose upon exit
    End Sub

    Private Sub BtnConsole_Click(sender As Object, e As EventArgs) Handles BtnConsole.Click
        Console.Beep(600, 600) 'Low sound 600 msec
        sMsg = "'Console.Beep(frequency, duration)"
        RText.Text = sMsg & vbCrLf & "Console.Beep(600, 600)"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        PictureBox1.Visible = False
    End Sub

    Private Sub BtnConsole2_Click(sender As Object, e As EventArgs) Handles BtnConsole2.Click
        Console.Beep(500, 600) 'Low sound 600 msec
        sMsg = "'Console.Beep(frequency, duration)"
        RText.Text = sMsg & vbCrLf & "Console.Beep(500, 600)"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        PictureBox1.Visible = False
    End Sub

    Private Sub BntConsole3_Click(sender As Object, e As EventArgs) Handles BntConsole3.Click
        Console.Beep(300, 600) 'Low sound 600 msec
        sMsg = "'Console.Beep(frequency, duration)"
        RText.Text = sMsg & vbCrLf & "Console.Beep(300, 600)"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        PictureBox1.Visible = False
    End Sub

    Private Sub BtnWave_Click(sender As Object, e As EventArgs) Handles BtnWave.Click
        Dim sFile As String
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        RText.Width = 880
        sFile = value & "Plane.WAV"
        My.Computer.Audio.Play(sFile, AudioPlayMode.WaitToComplete)
        sFileName = "sound.txt"
        rFile()
        sMsg = "'Can only play WAV files" & vbCrLf
        sMsg = sMsg & "'AudioPlayMode.Background         Plays in the background & code continues " & vbCrLf
        sMsg = sMsg & "'AudioPlayMode.BackgroundLoop     Plays until Stop Is called. " & vbCrLf
        sMsg = sMsg & "'AudioPlayMode.WaitToComplete     The calling code Waits for song."
        RText.Text = sMsg & "     " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        PictureBox1.Visible = False
        Lblname.Text = "Sound"
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim sFile As String
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        RText.Width = 880
        sFile = value & "jepor3.WAV"
        My.Computer.Audio.Play(sFile, AudioPlayMode.BackgroundLoop)
        sFileName = "sound2.txt"
        rFile()
        sMsg = "'Can only play WAV files" & vbCrLf
        sMsg = sMsg & "'AudioPlayMode.Background         Plays in the background & code continues " & vbCrLf
        sMsg = sMsg & "'AudioPlayMode.BackgroundLoop     Plays until Stop Is called. " & vbCrLf
        sMsg = sMsg & "'AudioPlayMode.WaitToComplete     The calling code Waits for song."
        RText.Text = sMsg & "     " & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
        PictureBox1.Visible = False
        Lblname.Text = "Sound"
    End Sub

    Private Sub BtnWaveStop_Click(sender As Object, e As EventArgs) Handles BtnWaveStop.Click
        My.Computer.Audio.Stop()
        sMsg = "'Stop Wav"
        RText.Text = sMsg & "     " & vbCrLf & "My.Computer.Audio.Stop()"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
End Class
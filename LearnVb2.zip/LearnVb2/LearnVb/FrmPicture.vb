﻿Public Class FrmPicture
    Dim sFolder As String ' Folder Name
    Dim sMsg As String
    Dim sFileName As String
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub PickSpot()
        Dim top As Integer = Integer.Parse(TxtTop.Text)
        Dim left As Integer = Integer.Parse(TxtLeft.Text)
        Dim width As Integer = Integer.Parse(TxtWidth.Text)
        Dim height As Integer = Integer.Parse(TxtHeight.Text)
        picResult.Width = TxtWidth.Text
        picResult.Height = TxtHeight.Text
        ' Make a Bitmap to hold the result.
        Dim bm As New Bitmap(width, height)
        ' Associate a Graphics object with the Bitmap
        Using gr As Graphics = Graphics.FromImage(bm)
            ' Define source and destination rectangles.
            Dim src_rect As New Rectangle(left, top, width,
            height)
            Dim dst_rect As New Rectangle(0, 0, width, height)

            ' Copy that part of the image.
            gr.DrawImage(PictureBox1.Image, dst_rect, src_rect,
            GraphicsUnit.Pixel)
        End Using
        ' Display the result.
        picResult.Image = bm
    End Sub
    Private Sub GetFiles()
        Dim value As String = My.Application.Info.DirectoryPath & "\" & sFolder & "\"
        Dim di As IO.DirectoryInfo = New IO.DirectoryInfo(value)
        '
        ' Read all Jpgs
        '
        ListBox1.Items.Clear()  'Clear ListBox
        Dim diar1 As IO.FileInfo() = di.GetFiles("*.jpg")
        Dim dra As IO.FileInfo
        'list the names of all files in the specified directory
        For Each dra In diar1
            ListBox1.Items.Add(dra)
        Next
    End Sub

    Private Sub FrmPicture_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Load Picture from file
        Dim value As String = My.Application.Info.DirectoryPath & "\jpg\"
        sFolder = "jpg" 'Folder Name
        GetFiles()
        PictureBox1.Image = Image.FromFile(value & "apple.jpg")
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        LblPicture.Text = "apple.jpg"
        PictureBox1.Top = 80
        PictureBox1.Left = 40
        PictureBox1.Width = 120
        PictureBox1.Height = 120
        RText.Text = "Dim sFolder As String  " & vbCrLf & "sFolder = " & Chr(34) & "jpg" & Chr(34) & vbCrLf
        RText.Text = RText.Text & "Dim value As String = My.Application.Info.DirectoryPath &" &
        Chr(34) & "\" & Chr(34) & " & sFolder &" & Chr(34) & "\" & Chr(34)
        RText.Text = RText.Text & vbCrLf & "PictureBox1.Image = Image.FromFile(value & " & Chr(34) & "apple.jpg" & Chr(34) & ")" & vbCrLf
        RText.Text = RText.Text & "PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage" & vbCrLf
        RText.Text = RText.Text & "LblPicture.Text = " & Chr(34) & "apple.jpg" & Chr(34)
    End Sub
    Private Sub ListBox1_Click(sender As Object, e As EventArgs) Handles ListBox1.Click
        'Load Picture from file
        Dim value As String = My.Application.Info.DirectoryPath & "\" & sFolder & "\"
        PictureBox1.Image = Image.FromFile(value & ListBox1.Text)
        LblPicture.Text = ListBox1.Text ' Name of Picture
        RText.Text = "Dim sFolder As String  " & vbCrLf & "sFolder = " & Chr(34) & "jpg" & Chr(34) & vbCrLf
        RText.Text = RText.Text & "Dim value As String = My.Application.Info.DirectoryPath &" &
         Chr(34) & "\" & Chr(34) & " & sFolder &" & Chr(34) & "\" & Chr(34)
        RText.Text = RText.Text & vbCrLf & "PictureBox1.Image = Image.FromFile(value & " & Chr(34) & ListBox1.Text & Chr(34) & ")  " & vbCrLf
        RText.Text = RText.Text & "PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage" & vbCrLf
        RText.Text = RText.Text & "LblPicture.Text =  " & Chr(34) & ListBox1.Text & Chr(34)
        'Reset Picture
        PictureBox1.Top = 80
        PictureBox1.Left = 40
        PictureBox1.Width = 120
        PictureBox1.Height = 120
    End Sub

    Private Sub BtnUp_Click(sender As Object, e As EventArgs) Handles BtnUp.Click
        Dim i As Integer
        'Move Picture Up
        PictureBox1.Top -= 10
        sMsg = "'Move Up"
        RText.Text = "PictureBox1.Top -= 10  "
        i = Len(RText.Text)
        RText.Text = RText.Text & sMsg
        RText.Select(i, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnDown_Click(sender As Object, e As EventArgs) Handles BtnDown.Click
        Dim i As Integer
        'Move Picture Down
        PictureBox1.Top += 10
        sMsg = "'Move Down"
        RText.Text = "PictureBox1.Top += 10  "
        i = Len(RText.Text)
        RText.Text = RText.Text & sMsg
        RText.Select(i, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnLeft_Click(sender As Object, e As EventArgs) Handles BtnLeft.Click
        Dim i As Integer
        'Move Picture Left
        PictureBox1.Left -= 10
        sMsg = "'Move Left"
        RText.Text = "PictureBox1.Left -= 10  "
        i = Len(RText.Text)
        RText.Text = RText.Text & sMsg
        RText.Select(i, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnRight_Click(sender As Object, e As EventArgs) Handles BtnRight.Click
        Dim i As Integer
        'Move Picture Right
        PictureBox1.Left += 10
        sMsg = "'Move Right"
        RText.Text = "PictureBox1.Left += 10  "
        i = Len(RText.Text)
        RText.Text = RText.Text & sMsg
        RText.Select(i, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub BtnLarge_Click(sender As Object, e As EventArgs) Handles BtnLarge.Click
        'Picture Large
        PictureBox1.Width = 250
        PictureBox1.Height = 250
        sMsg = "'Picture Large"
        RText.Text = sMsg & vbCrLf & "PictureBox1.Width = 250  " & vbCrLf & "PictureBox1.Height = 250"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnSmall_Click(sender As Object, e As EventArgs) Handles BtnSmall.Click
        'Picture Small
        PictureBox1.Width = 120
        PictureBox1.Height = 120
        sMsg = "'Picture Small"
        RText.Text = sMsg & vbCrLf & "PictureBox1.Width = 120  " & vbCrLf & "PictureBox1.Height = 120"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles BtnReset.Click
        'Reset Picture
        Dim value As String = My.Application.Info.DirectoryPath & "\jpg\"
        sFolder = "jpg" 'Folder Name
        GetFiles()
        PictureBox1.Image = Image.FromFile(value & "apple.jpg")
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        LblPicture.Text = "apple.jpg"
        PictureBox1.Top = 80
        PictureBox1.Left = 40
        PictureBox1.Width = 120
        PictureBox1.Height = 120
        sMsg = "'Reset Picture"
        'RText.Text = sMsg & vbCrLf & "PictureBox1.Top = 80  " & vbCrLf & "PictureBox1.Left = 40" & vbCrLf
        'RText.Text = RText.Text & "PictureBox1.Width = 120  " & vbCrLf & "PictureBox1.Height = 120"
        'RText.Select(0, Len(sMsg))
        'RText.SelectionColor = Color.Green
        RText.Text = sMsg & vbCrLf & "Dim sFolder As String  " & vbCrLf & "sFolder = " & Chr(34) & "jpg" & Chr(34) & vbCrLf
        RText.Text = RText.Text & "Dim value As String = My.Application.Info.DirectoryPath &" &
        Chr(34) & "\" & Chr(34) & " & sFolder &" & Chr(34) & "\" & Chr(34)
        RText.Text = RText.Text & vbCrLf & "PictureBox1.Image = Image.FromFile(value & " & Chr(34) & "apple.jpg" & Chr(34) & ")" & vbCrLf
        RText.Text = RText.Text & "PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage" & vbCrLf
        RText.Text = RText.Text & "LblPicture.Text = " & Chr(34) & "apple.jpg" & Chr(34)
        RText.Text = RText.Text & vbCrLf & "PictureBox1.Top = 80  " & vbCrLf & "PictureBox1.Left = 40" & vbCrLf
        RText.Text = RText.Text & "PictureBox1.Width = 120  " & vbCrLf & "PictureBox1.Height = 120"
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub

    Private Sub BtnSection_Click(sender As Object, e As EventArgs) Handles BtnSection.Click
        PickSpot()
        sFileName = "PickSpot.txt"
        rFile()
        sMsg = "'Cut a section of the picture"
        RText.Text = sMsg & vbCrLf & RText.Text
        RText.Select(0, Len(sMsg))
        RText.SelectionColor = Color.Green
    End Sub
End Class
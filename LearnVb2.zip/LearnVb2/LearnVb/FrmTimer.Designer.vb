﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmTimer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmTimer))
        Me.LblCode = New System.Windows.Forms.Label()
        Me.RText = New System.Windows.Forms.RichTextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.LblTimer = New System.Windows.Forms.Label()
        Me.BtnTimerOn = New System.Windows.Forms.Button()
        Me.BtnTimerOn2 = New System.Windows.Forms.Button()
        Me.BtnTimerOff2 = New System.Windows.Forms.Button()
        Me.BtnTimerOff = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BtnFast = New System.Windows.Forms.Button()
        Me.BtnSlow = New System.Windows.Forms.Button()
        Me.CheckTimer = New System.Windows.Forms.Button()
        Me.LblCheck = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.LblHit = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LblCode
        '
        Me.LblCode.AutoSize = True
        Me.LblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCode.Location = New System.Drawing.Point(23, 258)
        Me.LblCode.Name = "LblCode"
        Me.LblCode.Size = New System.Drawing.Size(51, 20)
        Me.LblCode.TabIndex = 34
        Me.LblCode.Text = "Code"
        '
        'RText
        '
        Me.RText.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RText.Location = New System.Drawing.Point(12, 281)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(682, 292)
        Me.RText.TabIndex = 33
        Me.RText.Text = ""
        '
        'Timer1
        '
        Me.Timer1.Interval = 200
        '
        'LblTimer
        '
        Me.LblTimer.AutoSize = True
        Me.LblTimer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTimer.Location = New System.Drawing.Point(23, 6)
        Me.LblTimer.Name = "LblTimer"
        Me.LblTimer.Size = New System.Drawing.Size(53, 20)
        Me.LblTimer.TabIndex = 35
        Me.LblTimer.Text = "Timer"
        '
        'BtnTimerOn
        '
        Me.BtnTimerOn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTimerOn.Location = New System.Drawing.Point(33, 154)
        Me.BtnTimerOn.Name = "BtnTimerOn"
        Me.BtnTimerOn.Size = New System.Drawing.Size(152, 41)
        Me.BtnTimerOn.TabIndex = 36
        Me.BtnTimerOn.Text = "   Start" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Timer1.Start() "
        Me.BtnTimerOn.UseVisualStyleBackColor = True
        '
        'BtnTimerOn2
        '
        Me.BtnTimerOn2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTimerOn2.Location = New System.Drawing.Point(30, 201)
        Me.BtnTimerOn2.Name = "BtnTimerOn2"
        Me.BtnTimerOn2.Size = New System.Drawing.Size(155, 54)
        Me.BtnTimerOn2.TabIndex = 37
        Me.BtnTimerOn2.Text = "   Start" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Timer1.Enable=True"
        Me.BtnTimerOn2.UseVisualStyleBackColor = True
        '
        'BtnTimerOff2
        '
        Me.BtnTimerOff2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTimerOff2.Location = New System.Drawing.Point(204, 201)
        Me.BtnTimerOff2.Name = "BtnTimerOff2"
        Me.BtnTimerOff2.Size = New System.Drawing.Size(158, 54)
        Me.BtnTimerOff2.TabIndex = 39
        Me.BtnTimerOff2.Text = "   Stop" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Timer1.Enable=False"
        Me.BtnTimerOff2.UseVisualStyleBackColor = True
        '
        'BtnTimerOff
        '
        Me.BtnTimerOff.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTimerOff.Location = New System.Drawing.Point(207, 154)
        Me.BtnTimerOff.Name = "BtnTimerOff"
        Me.BtnTimerOff.Size = New System.Drawing.Size(155, 41)
        Me.BtnTimerOff.TabIndex = 38
        Me.BtnTimerOff.Text = "Stop" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Timer1.Stop() "
        Me.BtnTimerOff.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(33, 57)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(62, 64)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 40
        Me.PictureBox1.TabStop = False
        '
        'BtnFast
        '
        Me.BtnFast.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFast.Location = New System.Drawing.Point(378, 154)
        Me.BtnFast.Name = "BtnFast"
        Me.BtnFast.Size = New System.Drawing.Size(131, 41)
        Me.BtnFast.TabIndex = 41
        Me.BtnFast.Text = "Fast"
        Me.BtnFast.UseVisualStyleBackColor = True
        '
        'BtnSlow
        '
        Me.BtnSlow.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSlow.Location = New System.Drawing.Point(378, 209)
        Me.BtnSlow.Name = "BtnSlow"
        Me.BtnSlow.Size = New System.Drawing.Size(131, 41)
        Me.BtnSlow.TabIndex = 42
        Me.BtnSlow.Text = "Slow"
        Me.BtnSlow.UseVisualStyleBackColor = True
        '
        'CheckTimer
        '
        Me.CheckTimer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckTimer.Location = New System.Drawing.Point(551, 188)
        Me.CheckTimer.Name = "CheckTimer"
        Me.CheckTimer.Size = New System.Drawing.Size(131, 41)
        Me.CheckTimer.TabIndex = 43
        Me.CheckTimer.Text = "Check Timer"
        Me.CheckTimer.UseVisualStyleBackColor = True
        '
        'LblCheck
        '
        Me.LblCheck.AutoSize = True
        Me.LblCheck.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCheck.Location = New System.Drawing.Point(586, 154)
        Me.LblCheck.Name = "LblCheck"
        Me.LblCheck.Size = New System.Drawing.Size(53, 20)
        Me.LblCheck.TabIndex = 44
        Me.LblCheck.Text = "Timer"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(447, 57)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(62, 64)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 45
        Me.PictureBox2.TabStop = False
        '
        'LblHit
        '
        Me.LblHit.AutoSize = True
        Me.LblHit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHit.Location = New System.Drawing.Point(443, 9)
        Me.LblHit.Name = "LblHit"
        Me.LblHit.Size = New System.Drawing.Size(32, 20)
        Me.LblHit.TabIndex = 46
        Me.LblHit.Text = "Hit"
        '
        'FrmTimer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(734, 585)
        Me.Controls.Add(Me.LblHit)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.LblCheck)
        Me.Controls.Add(Me.CheckTimer)
        Me.Controls.Add(Me.BtnSlow)
        Me.Controls.Add(Me.BtnFast)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.BtnTimerOff2)
        Me.Controls.Add(Me.BtnTimerOff)
        Me.Controls.Add(Me.BtnTimerOn2)
        Me.Controls.Add(Me.BtnTimerOn)
        Me.Controls.Add(Me.LblTimer)
        Me.Controls.Add(Me.LblCode)
        Me.Controls.Add(Me.RText)
        Me.Name = "FrmTimer"
        Me.Text = "FrmTimer"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LblCode As Label
    Friend WithEvents RText As RichTextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents LblTimer As Label
    Friend WithEvents BtnTimerOn As Button
    Friend WithEvents BtnTimerOn2 As Button
    Friend WithEvents BtnTimerOff2 As Button
    Friend WithEvents BtnTimerOff As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents BtnFast As Button
    Friend WithEvents BtnSlow As Button
    Friend WithEvents CheckTimer As Button
    Friend WithEvents LblCheck As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents LblHit As Label
End Class

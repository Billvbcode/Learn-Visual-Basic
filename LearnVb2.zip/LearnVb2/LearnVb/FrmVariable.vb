﻿Public Class FrmVariable
    Dim sMsg As String
    Dim sCar(200, 6) As String ' Array for a Car
    Dim sFileName As String
    Public Sub rFile()
        Dim value As String = My.Application.Info.DirectoryPath & "\”
        Dim srFileReader As System.IO.StreamReader
        Dim sInputLine As String
        RText.Text = ""
        sFileName = value & sFileName
        srFileReader = System.IO.File.OpenText(sFileName)
        sInputLine = srFileReader.ReadLine()
        RText.Text = sInputLine
        Do Until sInputLine Is Nothing
            sInputLine = srFileReader.ReadLine()
            RText.Text = RText.Text & vbCrLf & sInputLine
        Loop
        srFileReader.Close() 'Close Reader
    End Sub
    Private Sub FrmVariable_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox1.Items.Clear()
        ListBox1.Items.Add("Boolean                       True or False  ")
        ListBox1.Items.Add("Byte                          0 to 255  ")
        ListBox1.Items.Add("Integer                       +/-2147483640 ")
        ListBox1.Items.Add("Long                          +/- 18 Digits  ")
        ListBox1.Items.Add("Short                         +/- 32,768")
        ListBox1.Items.Add("Decimal                       +/- 28 Digits  (Has Decimal) ")
        ListBox1.Items.Add("Double                        +/- 14 Digits  (Has Decimal)")
        ListBox1.Items.Add("Single                        +/- 7 Digits   (Has Decimal)  ")
        ListBox1.Items.Add("Date                          Any Date       ")
        ListBox1.Items.Add("String                        2 billion characters")
        ListBox1.Items.Add("Now                           Date and time")
        ListBox1.Items.Add("Date.Now.ToShortTimeString    Short Time")
        ListBox1.Items.Add("Date.Now.ToLongDateString     Long Date")
        ListBox1.Items.Add("Date.Now.ToShortDateString    Short Date")
        ListBox1.Items.Add("Date.Today                     Date")
        ListBox1.Items.Add("Array")
    End Sub

    Private Sub ListBox1_Click(sender As Object, e As EventArgs) Handles ListBox1.Click
        Dim bVar As Boolean
        Dim iby As Byte
        Dim i As Integer
        Dim j As Integer
        Dim iLng As Long
        Dim iSrt As Short
        Dim iDec As Decimal
        Dim iDou As Double
        Dim iSing As Single
        Dim iDat As Date
        Dim sStr As String
        If ListBox1.Text = "Array" Then
            sCar(1, 1) = "Chevy"    ' X,1 = Mfg (Car1)
            sCar(1, 2) = "2014"     ' X,2 = Year
            sCar(1, 3) = "T"        ' X,3 = MoonRoof
            sCar(2, 1) = "Ford"     ' X,1 = Mfg (Car2)
            sCar(2, 2) = "2016"     ' X,4 = Year
            sCar(2, 3) = "F"        ' X,3 = MoonRoof    
            ListBox2.Items.Clear()
            For j = 1 To 2
                For i = 1 To 3
                    ListBox2.Items.Add("I= " & i _
                      & " J= " & j & " " & sCar(j, i))
                Next
            Next
            sFileName = "Array.txt"
            rFile()
            sMsg = "'Array"
            RText.Text = sMsg & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        i = InStr(ListBox1.Text, "ToShortTime")
        If i > 0 Then
            LblResult.Text = Date.Now.ToShortTimeString
            sMsg = "'Date.Now.ToShortTimeString    Short Time  "
            RText.Text = sMsg & "   " & vbCrLf & " LblResult.Text = Date.Now.ToShortTimeString"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            Exit Sub
        End If
        i = InStr(ListBox1.Text, "ToShortDate")
        If i > 0 Then
            LblResult.Text = Date.Now.ToShortDateString
            sMsg = "'Date.Now.ToShortDateString    Short Date  "
            RText.Text = sMsg & "   " & vbCrLf & " LblResult.Text = Date.Now.ToShortDateString"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            Exit Sub
        End If
        i = InStr(ListBox1.Text, "ToLongDate")
        If i > 0 Then
            LblResult.Text = Date.Now.ToLongDateString
            sMsg = "'Date.Now.ToLongDateString     Long Date  "
            RText.Text = sMsg & "   " & vbCrLf & " LblResult.Text = Date.Now.ToLongDateString"
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
            Exit Sub
        End If
        If Mid(ListBox1.Text, 1, 3) = "Str" Then
            sStr = "Abc#4?"
            LblResult.Text = sStr
            RText.Text = "Dim iDat As Date" & vbCrLf
            RText.Text = RText.Text & "sStr = " & Chr(34) & "Abc#4?" & Chr(34) & vbCrLf
            RText.Text = RText.Text & "LblResult.Text = sStr"
            sMsg = "'String     2 billion characters   "
                    RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 5) = "Date " Then
            iDat = Now
            LblResult.Text = iDat
            RText.Text = "Dim iDat As Date" & vbCrLf
            RText.Text = RText.Text & "iDat = Now" & vbCrLf
            RText.Text = RText.Text & "LblResult.Text = iDat"
            sMsg = "'Date       Any Date   "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 3) = "Now" Then
            iDat = Now
            LblResult.Text = iDat
            RText.Text = "Dim iDat As Date" & vbCrLf
            RText.Text = RText.Text & "iDat = Now" & vbCrLf
            RText.Text = RText.Text & "LblResult.Text = iDat"
            sMsg = "'Now       Date and time   "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 5) = "Date." Then
            iDat = Date.Today
            LblResult.Text = iDat
            RText.Text = "Dim iDat As Date" & vbCrLf
            RText.Text = RText.Text & "iDat = Date.Today" & vbCrLf
            RText.Text = RText.Text & "LblResult.Text = iDat"
            sMsg = "'Now       Date and time   "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 3) = "Sin" Then
            iSing = 12.8234
            LblResult.Text = iSing
            RText.Text = "Dim iSing As Single" & vbCrLf
            RText.Text = RText.Text & "iSing = 12.8234" & vbCrLf
            RText.Text = RText.Text & "LblResult.Text = iDou"
            sMsg = "'Single     +/- 7 Digits   (Has Decimal) "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 3) = "Dou" Then
            iDou = 75.6534
            LblResult.Text = iDou
            RText.Text = "Dim iDou As Double" & vbCrLf
            RText.Text = RText.Text & "iDou = 75.6534" & vbCrLf
            RText.Text = RText.Text & "LblResult.Text = iDou"
            sMsg = "'Double     +/- 14 Digits  (Has Decimal) "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 3) = "Dec" Then
            iDec = 88.1234
            LblResult.Text = iDec
            RText.Text = "Dim iDec As Decimal" & vbCrLf
            RText.Text = RText.Text & "iDec = 88.1234" & vbCrLf
            RText.Text = RText.Text & "LblResult.Text = iDec"
            sMsg = "'Decimal    +/- 28 Digits  (Has Decimal) "
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 3) = "Sho" Then
            iSrt = 62
            LblResult.Text = iSrt
            RText.Text = "Dim iSrt As Short" & vbCrLf
            RText.Text = RText.Text & "iSrt = 62" & vbCrLf
            RText.Text = RText.Text & "LblResult.Text = iSrt"
            sMsg = "'Short      +/- 32,768"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 3) = "Lon" Then
            iLng = 2200
            LblResult.Text = iLng
            RText.Text = "Dim iLng As Long" & vbCrLf
            RText.Text = RText.Text & "iLng = 2200" & vbCrLf
            RText.Text = RText.Text & "LblResult.Text = iLng"
            sMsg = "'Long       +/- 18 Digits"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 3) = "Int" Then
            i = 220
            LblResult.Text = i
            RText.Text = "Dim i As Integer" & vbCrLf
            RText.Text = RText.Text & "i = 220" & vbCrLf
            RText.Text = RText.Text & "LblResult.Text = i"
            sMsg = "'Integer    +/-2147483640"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 3) = "Boo" Then
            bVar = True
            bVar = False
            LblResult.Text = bVar
            RText.Text = "Dim bVar As Boolean" & vbCrLf
            RText.Text = RText.Text & "bVar = True" & vbCrLf
            RText.Text = RText.Text & "bVar = False" & vbCrLf
            RText.Text = RText.Text & "LblResult.Text = bVar"
            sMsg = "'Boolean    True or False"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
        If Mid(ListBox1.Text, 1, 3) = "Byt" Then
            iby = 22
            LblResult.Text = iby
            RText.Text = "Dim iby As Byte" & vbCrLf
            RText.Text = RText.Text & "iby = 22" & vbCrLf
            RText.Text = RText.Text & "LblResult.Text = iby"
            sMsg = "'Byte       0 to 255"
            RText.Text = sMsg & "   " & vbCrLf & RText.Text
            RText.Select(0, Len(sMsg))
            RText.SelectionColor = Color.Green
        End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub ListBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox2.SelectedIndexChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        LblResult.Text = Date.Now.TimeOfDay.ToString
        LblResult.Text = Date.Now.ToShortTimeString
        LblResult.Text = Date.Now.ToLongDateString
        LblResult.Text = Date.Now.ToShortDateString
    End Sub
End Class
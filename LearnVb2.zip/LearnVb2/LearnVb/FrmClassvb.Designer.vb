﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmClassvb
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LblName = New System.Windows.Forms.Label()
        Me.BtnView = New System.Windows.Forms.Button()
        Me.BtnAdd = New System.Windows.Forms.Button()
        Me.BtnClass = New System.Windows.Forms.Button()
        Me.LblCode = New System.Windows.Forms.Label()
        Me.RText = New System.Windows.Forms.RichTextBox()
        Me.dGrid = New System.Windows.Forms.DataGridView()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BtnDefault = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        CType(Me.dGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LblName
        '
        Me.LblName.AutoSize = True
        Me.LblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblName.Location = New System.Drawing.Point(26, 45)
        Me.LblName.Name = "LblName"
        Me.LblName.Size = New System.Drawing.Size(0, 20)
        Me.LblName.TabIndex = 53
        '
        'BtnView
        '
        Me.BtnView.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnView.Location = New System.Drawing.Point(385, 15)
        Me.BtnView.Name = "BtnView"
        Me.BtnView.Size = New System.Drawing.Size(117, 45)
        Me.BtnView.TabIndex = 50
        Me.BtnView.Text = "ViewClass"
        Me.BtnView.UseVisualStyleBackColor = True
        '
        'BtnAdd
        '
        Me.BtnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAdd.Location = New System.Drawing.Point(263, 15)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.Size = New System.Drawing.Size(105, 45)
        Me.BtnAdd.TabIndex = 49
        Me.BtnAdd.Text = "AddClass"
        Me.BtnAdd.UseVisualStyleBackColor = True
        '
        'BtnClass
        '
        Me.BtnClass.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClass.Location = New System.Drawing.Point(135, 15)
        Me.BtnClass.Name = "BtnClass"
        Me.BtnClass.Size = New System.Drawing.Size(122, 45)
        Me.BtnClass.TabIndex = 48
        Me.BtnClass.Text = "CreateClass"
        Me.BtnClass.UseVisualStyleBackColor = True
        '
        'LblCode
        '
        Me.LblCode.AutoSize = True
        Me.LblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCode.Location = New System.Drawing.Point(12, 76)
        Me.LblCode.Name = "LblCode"
        Me.LblCode.Size = New System.Drawing.Size(49, 16)
        Me.LblCode.TabIndex = 47
        Me.LblCode.Text = " Code"
        '
        'RText
        '
        Me.RText.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RText.Location = New System.Drawing.Point(12, 95)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(706, 421)
        Me.RText.TabIndex = 46
        Me.RText.Text = ""
        '
        'dGrid
        '
        Me.dGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dGrid.Location = New System.Drawing.Point(12, 537)
        Me.dGrid.Name = "dGrid"
        Me.dGrid.Size = New System.Drawing.Size(578, 112)
        Me.dGrid.TabIndex = 54
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(528, 7)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(135, 53)
        Me.Button1.TabIndex = 55
        Me.Button1.Text = "Class with Default Values"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BtnDefault
        '
        Me.BtnDefault.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnDefault.Location = New System.Drawing.Point(687, 12)
        Me.BtnDefault.Name = "BtnDefault"
        Me.BtnDefault.Size = New System.Drawing.Size(135, 53)
        Me.BtnDefault.TabIndex = 57
        Me.BtnDefault.Text = "View Default Values"
        Me.BtnDefault.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(7, 12)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(122, 48)
        Me.Button2.TabIndex = 58
        Me.Button2.Text = "What Is A Class"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'FrmClassvb
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(834, 642)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.BtnDefault)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.dGrid)
        Me.Controls.Add(Me.LblName)
        Me.Controls.Add(Me.BtnView)
        Me.Controls.Add(Me.BtnAdd)
        Me.Controls.Add(Me.BtnClass)
        Me.Controls.Add(Me.LblCode)
        Me.Controls.Add(Me.RText)
        Me.Name = "FrmClassvb"
        Me.Text = "FrmClass"
        CType(Me.dGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LblName As Label
    Friend WithEvents BtnView As Button
    Friend WithEvents BtnAdd As Button
    Friend WithEvents BtnClass As Button
    Friend WithEvents LblCode As Label
    Friend WithEvents RText As RichTextBox
    Friend WithEvents dGrid As DataGridView
    Friend WithEvents Button1 As Button
    Friend WithEvents BtnDefault As Button
    Friend WithEvents Button2 As Button
End Class

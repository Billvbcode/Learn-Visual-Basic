﻿Module Module1
    Public bBtnImage As Boolean
    Public bPicImage As Boolean
    Public sForm As String
End Module

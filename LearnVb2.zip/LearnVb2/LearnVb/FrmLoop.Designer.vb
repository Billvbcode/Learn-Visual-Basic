﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLoop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LblCode = New System.Windows.Forms.Label()
        Me.RText = New System.Windows.Forms.RichTextBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.LblTimer = New System.Windows.Forms.Label()
        Me.BtnFor = New System.Windows.Forms.Button()
        Me.BtnStep2 = New System.Windows.Forms.Button()
        Me.BtnStep4 = New System.Windows.Forms.Button()
        Me.BtnStep8 = New System.Windows.Forms.Button()
        Me.BtnLabel = New System.Windows.Forms.Button()
        Me.BtnTxt = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'LblCode
        '
        Me.LblCode.AutoSize = True
        Me.LblCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblCode.Location = New System.Drawing.Point(14, 306)
        Me.LblCode.Name = "LblCode"
        Me.LblCode.Size = New System.Drawing.Size(51, 20)
        Me.LblCode.TabIndex = 35
        Me.LblCode.Text = "Code"
        '
        'RText
        '
        Me.RText.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RText.Location = New System.Drawing.Point(12, 329)
        Me.RText.Name = "RText"
        Me.RText.Size = New System.Drawing.Size(811, 232)
        Me.RText.TabIndex = 34
        Me.RText.Text = ""
        '
        'ListBox1
        '
        Me.ListBox1.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 14
        Me.ListBox1.Location = New System.Drawing.Point(712, 23)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(111, 270)
        Me.ListBox1.TabIndex = 36
        '
        'LblTimer
        '
        Me.LblTimer.AutoSize = True
        Me.LblTimer.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblTimer.Location = New System.Drawing.Point(14, 9)
        Me.LblTimer.Name = "LblTimer"
        Me.LblTimer.Size = New System.Drawing.Size(49, 20)
        Me.LblTimer.TabIndex = 37
        Me.LblTimer.Text = "Loop"
        '
        'BtnFor
        '
        Me.BtnFor.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnFor.Location = New System.Drawing.Point(3, 75)
        Me.BtnFor.Name = "BtnFor"
        Me.BtnFor.Size = New System.Drawing.Size(130, 63)
        Me.BtnFor.TabIndex = 38
        Me.BtnFor.Text = "For i=0 to 8"
        Me.BtnFor.UseVisualStyleBackColor = True
        '
        'BtnStep2
        '
        Me.BtnStep2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnStep2.Location = New System.Drawing.Point(3, 171)
        Me.BtnStep2.Name = "BtnStep2"
        Me.BtnStep2.Size = New System.Drawing.Size(130, 63)
        Me.BtnStep2.TabIndex = 39
        Me.BtnStep2.Text = "Step 2"
        Me.BtnStep2.UseVisualStyleBackColor = True
        '
        'BtnStep4
        '
        Me.BtnStep4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnStep4.Location = New System.Drawing.Point(155, 75)
        Me.BtnStep4.Name = "BtnStep4"
        Me.BtnStep4.Size = New System.Drawing.Size(130, 63)
        Me.BtnStep4.TabIndex = 40
        Me.BtnStep4.Text = "Step 4"
        Me.BtnStep4.UseVisualStyleBackColor = True
        '
        'BtnStep8
        '
        Me.BtnStep8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnStep8.Location = New System.Drawing.Point(155, 171)
        Me.BtnStep8.Name = "BtnStep8"
        Me.BtnStep8.Size = New System.Drawing.Size(130, 63)
        Me.BtnStep8.TabIndex = 41
        Me.BtnStep8.Text = "Step 8"
        Me.BtnStep8.UseVisualStyleBackColor = True
        '
        'BtnLabel
        '
        Me.BtnLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnLabel.Location = New System.Drawing.Point(356, 75)
        Me.BtnLabel.Name = "BtnLabel"
        Me.BtnLabel.Size = New System.Drawing.Size(130, 63)
        Me.BtnLabel.TabIndex = 42
        Me.BtnLabel.Text = "Label"
        Me.BtnLabel.UseVisualStyleBackColor = True
        '
        'BtnTxt
        '
        Me.BtnTxt.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnTxt.Location = New System.Drawing.Point(510, 75)
        Me.BtnTxt.Name = "BtnTxt"
        Me.BtnTxt.Size = New System.Drawing.Size(130, 63)
        Me.BtnTxt.TabIndex = 43
        Me.BtnTxt.Text = "TextBox"
        Me.BtnTxt.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(380, 171)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 16)
        Me.Label1.TabIndex = 44
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(380, 218)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 16)
        Me.Label2.TabIndex = 45
        Me.Label2.Text = "Label2"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(520, 167)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 22)
        Me.TextBox1.TabIndex = 46
        Me.TextBox1.Text = "TextBox1"
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(520, 215)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 22)
        Me.TextBox2.TabIndex = 47
        Me.TextBox2.Text = "TextBox2"
        '
        'FrmLoop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(858, 573)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnTxt)
        Me.Controls.Add(Me.BtnLabel)
        Me.Controls.Add(Me.BtnStep8)
        Me.Controls.Add(Me.BtnStep4)
        Me.Controls.Add(Me.BtnStep2)
        Me.Controls.Add(Me.BtnFor)
        Me.Controls.Add(Me.LblTimer)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.LblCode)
        Me.Controls.Add(Me.RText)
        Me.Name = "FrmLoop"
        Me.Text = "FrmLoop"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LblCode As Label
    Friend WithEvents RText As RichTextBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents LblTimer As Label
    Friend WithEvents BtnFor As Button
    Friend WithEvents BtnStep2 As Button
    Friend WithEvents BtnStep4 As Button
    Friend WithEvents BtnStep8 As Button
    Friend WithEvents BtnLabel As Button
    Friend WithEvents BtnTxt As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
End Class
